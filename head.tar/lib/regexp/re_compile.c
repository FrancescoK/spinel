/*
** re_compile.c - regexp pattern compiler
**
** Compiles a regular expression pattern string into bytecode
** for the NFA execution engine.
**
** See Copyright Notice in mruby.h
*/

#include "re_internal.h"
#include <mruby/error.h>
#include <mruby/internal.h>
#include <mruby/string.h>
#include <string.h>

#ifdef RE_UNICODE_CTYPE
#include "re_prop.h"
#endif

/* Class IDs are stored in re_inst.a (uint8_t), so at most 256 distinct
   character classes can be encoded.  Without this cap, class_capa
   (uint16_t) overflows on doubling past 32768 (8 -> 16 -> ... -> 32768
   -> 0), mrb_realloc with size 0 returns NULL, and the next memset
   crashes; even before that, the (uint8_t)id cast at emit sites would
   silently alias different classes. */
#define RE_MAX_CLASSES 256

/* What opened a nesting level of the parse; see re_level. */
enum {
  RE_LEVEL_PATTERN,     /* the pattern itself, the level the parse begins in */
  RE_LEVEL_GROUP,       /* (...), (?:...), (?<name>...) and (?'name'...) */
  RE_LEVEL_LOOKAHEAD,   /* (?=...) and (?!...) */
  RE_LEVEL_LOOKBEHIND,  /* (?<=...) and (?<!...) */
  RE_LEVEL_ATOMIC,      /* (?>...) */
  RE_LEVEL_ABSENT,      /* (?~...) */
  RE_LEVEL_OPTION,      /* (?imx:...) */
  RE_LEVEL_TOGGLE,      /* (?imx), whose scope is the rest of the group it stands in */
  RE_LEVEL_COND         /* (?(cond)yes|no) */
};

/* One nesting level the parse has open: what the construct that opened it
   needs at its close, and what the level it stands in needs back once the
   close is done. The levels are a stack the parse keeps on the heap rather
   than frames it keeps on the C stack, so what a deep pattern costs is an
   allocation the code reads and answers, at any depth, on any stack; see
   compile_levels(). */
typedef struct {
  uint8_t kind;         /* RE_LEVEL_* */
  uint8_t state;        /* GROUP: it captures; LOOKAHEAD, LOOKBEHIND: it is
                           negated; COND: the `no` body is being read */
  uint16_t num;         /* GROUP: the capture index; LOOKAHEAD, LOOKBEHIND,
                           ATOMIC: the cut number; see RE_ATOMIC */
  uint32_t flags;       /* the options in effect when the level opened, which
                           its close restores: an inline toggle inside a group
                           does not leak past the group's ')' */
  uint32_t head;        /* LOOKAHEAD, LOOKBEHIND, ABSENT, COND: the
                           instruction that opened the level, whose offset the
                           close patches to the code after it */
  uint32_t aux;         /* LOOKBEHIND: where the body's code begins; COND:
                           the RE_JMP that carries `yes` past `no` */
  uint32_t begin;       /* code_len before the level's opener: what a
                           quantifier after the close binds to */
  uint32_t atom_start;  /* c->atom_start as the enclosing level had it */
  uint32_t alt_start;   /* code_len where the level's first branch began */
  uint32_t branches;    /* how many `|` the level has read so far */
} re_level;

/* Levels the compiler keeps inline before it spills to the heap. A written
   pattern nests a handful deep, so this is every pattern anyone writes
   compiling with no allocation for its levels; what the array costs is one
   frame's worth of C stack once, not per level. */
#define RE_LEVELS_INLINE 8

/* What ended the operand of a character class parse_class_operand() was
   reading. The ']' and the '&&' are consumed there; the '[' is left standing,
   since what follows it is read as a level of its own. */
enum {
  RE_CLASS_END,    /* the ']' that closes the class */
  RE_CLASS_MORE,   /* the '&&' that stands before the next operand */
  RE_CLASS_NEST    /* the '[' of a class written inside this one */
};

/* One character class the parse has open: the class a '[' began, the operand
   of it being read, and what its ']' closes with. A class written inside a
   class is one of these too, so what a pattern nests is a stack the parse
   keeps of its own rather than frames on the C stack, as the levels the
   pattern itself nests are; see parse_class_levels(). */
typedef struct {
  uint16_t id;       /* the class the body is read into: the operands come to
                        an intersection here, and this is what joins the level
                        below once the class closes */
  uint16_t cur_id;   /* the class the operand being read goes into: `id` for
                        the first, there being nothing yet to intersect it
                        with, and one of its own after each `&&` */
  mrb_bool negated;  /* the '[^' of a nest opened the level, so what joins the
                        level below is the complement of what it holds. The
                        outermost class carries its own negation in the class
                        (RE_NCLASS) instead */
  mrb_bool first;    /* the operand opens the class and nothing has been read
                        into it, where a ']' is a member rather than the
                        close; only the first operand does, so [a&&]a] is the
                        empty class followed by the two characters `a]` */
  uint8_t cross[RE_CLASS_BITMAP_SIZE];  /* the ASCII members the class holds
                        in its own right, as against the ones an ASCII-only
                        set brought, narrowed by each operand in step; see
                        close_class_operand() */
  re_charclass ascii_set;  /* the operand's ASCII-only sets, held beside the
                        class until the operand ends; see compile_charclass()
                        for what is held there and why */
} re_class_level;

/* Class levels the compiler keeps inline before it spills to the heap: a
   class takes one and a class written inside it the other, which is as deep
   as a written pattern goes. What the array costs is one frame's worth of C
   stack once, not per level, and a class deeper than this pays an allocation
   rather than the stack it used to descend. */
#define RE_CLASS_LEVELS_INLINE 2

/* Compiler state.

   Everything the compile allocates and the finished pattern goes on owning
   hangs off `pat`, which mrb_re_compile()'s caller has already handed to a
   Regexp. That is what makes the buffers survivable: raising is how this
   compiler reports a bad pattern and how mrb_realloc() reports a refused
   allocation, and either longjmps past this frame, which nothing then
   unwinds. Held here instead, the buffers would go with the frame.

   What is left here is the parse's own state: the cursor, the capacities the
   pattern does not record, and the counts that reach `pat` at the end. */
typedef struct {
  mrb_state *mrb;
  mrb_regexp_pattern *pat;  /* the pattern being built; owns code/classes/names */
  const char *src;     /* pattern source, preprocessed (see preprocess_pattern) */
  const char *src_end;
  const char *orig;    /* pattern as written, for error messages */
  const char *orig_end;
  const char *p;       /* current position */
  uint32_t code_len;
  uint32_t code_capa;
  uint16_t class_capa;
  uint16_t num_captures;
  uint32_t flags;
  uint32_t orig_flags;  /* flags as passed to mrb_re_compile(), for error
                            messages: unlike `flags`, an inline option such as
                            `(?i)` does not change this (re_compile.c:1667) */
  uint16_t num_named;
  mrb_bool has_backref;
  mrb_bool needs_backtrack;
  mrb_bool binary;      /* the pattern string is byte-indexed: its bytes
                            spell no characters (see mrb_re_compile()) */
  mrb_bool dont_capture;    /* pattern declares a named group: plain (...) does not capture */
  uint16_t max_backref;     /* the largest group number the pattern refers
                               back to, whichever of `\NN` and `\k<n>` spelled
                               it, checked against the group count once the
                               whole pattern is read: CRuby takes a reference
                               to a group written later, `\1(a)` and
                               `\k<1>(a)` alike, so the count it compares with
                               is the pattern's, not the one standing where
                               the reference is */
  uint16_t num_groups;      /* groups opened so far, counting the plain ones a
                               named pattern demotes: what decides whether
                               `\NN` is a backreference or an octal escape */
  uint32_t num_cuts;        /* atomic groups and lookarounds numbered so far,
                               the possessive repeats among them: each takes
                               the next number, so no two that nest share one;
                               see RE_ATOMIC and RE_LOOK_END */
  uint32_t atom_start;      /* where the atom a quantifier binds to begins;
                               compile_levels() sets it to the position
                               before the atom, and a `\u{...}` list moves it
                               forward so the quantifier repeats the last
                               codepoint alone */
  uint32_t literal_cp[RE_MAX_CLASSES];  /* by class id: the codepoint whose
                               /i literal the class stands for, 0 for a class
                               made by anything else; see literal_class() */
  uint32_t depth;           /* nesting levels open at the parse point: the
                               levels on the stack below and the character
                               classes open inside one another; bounded by
                               MRB_REGEXP_PARSE_DEPTH_LIMIT */
  /* The levels the parse has open, innermost last; see re_level. They
     start in `levels_inline` and move to a String the GC arena keeps for
     the compile once they outgrow it, as pending_calls is kept: a raise
     unwinds nothing here, and the arena drops the String with the frame. */
  re_level *levels;
  uint32_t level_count;
  uint32_t level_capa;
  mrb_value level_store;    /* nil while the levels are inline */
  re_level levels_inline[RE_LEVELS_INLINE];
  /* The character classes the parse has open, innermost last; see
     re_class_level. They are held as the levels above are, and are the same
     answer to the same question: a class written inside a class is a level
     rather than a descent, so no pattern's classes reach the C stack. The
     stack is empty between one class and the next, so a pattern pays for the
     deepest class it writes and not for the sum of them. */
  re_class_level *class_levels;
  uint32_t class_level_count;
  uint32_t class_level_capa;
  mrb_value class_level_store;  /* nil while the class levels are inline */
  re_class_level class_levels_inline[RE_CLASS_LEVELS_INLINE];
  /* The alternation that finished last, as the span it covers and how many
     branches it has. The lookbehind arm reads it to tell a body that *is*
     an alternation from one that merely holds one: only the first may give
     each branch a rewind of its own, which is CRuby's line too. The record
     is cleared when a lookbehind body begins, so what it holds is that
     body's own; the alternation spanning the whole body is the last inside
     it to finish. Where each branch begins is read off the SPLIT chain the
     span starts with; see close_alternation() for its layout.

     These are positions, so anything that moves or drops code ends the
     record rather than adjusting it: insert_insts() clears it, and so does
     every rollback in compile_quantifiers(). Without that, `(?:a|b){0}`
     would leave the record of an alternation whose code is gone, pointing
     at whatever was emitted in its place. */
  uint32_t alt_count;       /* 0 when no alternation has been compiled */
  uint32_t alt_from;        /* code index of the alternation's first SPLIT */
  uint32_t alt_to;          /* code index just past its last branch */
  mrb_bool has_call;        /* a \g call was emitted: resolve_calls() runs */
  mrb_bool has_keep;        /* a \K was emitted, as an RE_SAVE to
                               RE_KEEP_PENDING until the groups are counted */
  mrb_value pending_calls;  /* the \g references the parse could not resolve,
                               as re_pending_call records in a String the GC
                               arena keeps for the compile; nil until the
                               first one */
  uint16_t num_pending;
} re_compiler;

/* Take the message as a String rather than as a C string, for the messages
   that quote a group name: the name is a length-counted slice of the pattern
   and may hold a NUL, which a C string would cut short. Callers with a fixed
   message use compile_error() below. */
static void
compile_error_str(re_compiler *c, mrb_value msg)
{
  /* Quote c->orig, the pattern as written: when the pattern is preprocessed
     c->src points at the buffer preprocess_pattern() returned, so quoting it
     would drop the comments and the (?#...) groups from the message. c->orig
     is the caller's buffer, which outlives the compile. It is not
     NUL-terminated, so use %l with the explicit length from c->orig_end. The
     flag suffix uses c->orig_flags, not c->flags: an inline option such as
     `(?i)` mutates the latter partway through the parse, where CRuby's
     message (and Regexp#inspect) reports the flags the pattern was compiled
     with. */
  mrb_value emsg = mrb_format(c->mrb, "%v: /%l/",
                              msg, c->orig, (size_t)(c->orig_end - c->orig));
  mrb_re_flags_cat(c->mrb, emsg, c->orig_flags);

  mrb_exc_raise(c->mrb,
    mrb_exc_new_str(c->mrb, mrb_exc_get_id(c->mrb, MRB_SYM(RegexpError)), emsg));
}

static void
compile_error(re_compiler *c, const char *msg)
{
  compile_error_str(c, mrb_str_new_cstr(c->mrb, msg));
}

/* Maximum number of instructions in a compiled pattern. Every jump target
   lives in re_inst.offset (uint16_t) and a target may be one past the last
   instruction, so the whole program has to be addressable by that field.
   Without the cap the targets wrap on the way in and the engine jumps to an
   unrelated instruction: no exception, no memory error, just a pattern that
   stops matching text it describes. The check sits in emit(), the one place
   code_len grows, so it covers every producer including insert_inst(). */
#define RE_MAX_CODE_LEN 0xffff

/* The slot a \K's RE_SAVE carries until the groups are counted and its own
   pair is known; no group's slot is this high (RE_MAX_CAPTURES). */
#define RE_KEEP_PENDING 0xffff

static uint32_t
emit(re_compiler *c, uint8_t op, uint8_t a, uint16_t offset)
{
  if (c->code_len >= RE_MAX_CODE_LEN) compile_error(c, "regexp too large");
  if (c->code_len >= c->code_capa) {
    c->code_capa = c->code_capa ? c->code_capa * 2 : 64;
    c->pat->code = (re_inst*)mrb_realloc(c->mrb, c->pat->code, sizeof(re_inst) * c->code_capa);
  }
  uint32_t pos = c->code_len++;
  c->pat->code[pos].op = op;
  c->pat->code[pos].a = a;
  c->pat->code[pos].offset = offset;
  return pos;
}

static void
patch(re_compiler *c, uint32_t pos, uint16_t offset)
{
  c->pat->code[pos].offset = offset;
}

/* True for the opcodes whose `offset` field holds an absolute code index, so
   that relocating code has to carry it along. The jumps are the obvious ones;
   the four lookarounds hold the end of their sub-pattern there
   (re_internal.h), which is a code index just as much as a jump target and is
   just as wrong when the code it names moves. Every relocator asks this one
   question, because the two that used to carry their own list disagreed with
   each other and with the opcode set: both relocated the jumps alone, and a
   lookaround inside a quantified, repeated or alternated group kept an offset
   pointing at whatever the shift left in its place.
   RE_LB_WIDTH is not here: it carries a pair of widths in `offset`, and
   RE_SAVE and RE_BACKREF put a slot number and a case-fold flag there rather
   than an index. RE_CALL is not here either, deliberately: while the parse
   runs, its `offset` is a pending-reference index that relocation would
   corrupt, and by the time resolve_calls() writes a code index into it, the
   last insertion has already happened. */
static mrb_bool
op_holds_code_index(uint8_t op)
{
  switch (op) {
  case RE_JMP: case RE_SPLIT: case RE_SPLITNG:
  case RE_LOOKAHEAD: case RE_NEG_LOOKAHEAD:
  case RE_LOOKBEHIND: case RE_NEG_LOOKBEHIND:
  case RE_ABSENT: case RE_COND:
    return TRUE;
  default:
    return FALSE;
  }
}

/* Open `count` slots at position `pos` by shifting the code once, and leave
   RE_JMP placeholders in them for the caller to fill. Adjusts code indices
   so they still point at the same instructions. An alternation reserves its
   whole SPLIT chain here in one call: the shift and the fixup below each walk
   the code, so a reservation per branch would walk it once per branch. */
static void
insert_insts(re_compiler *c, uint32_t pos, uint32_t count)
{
  /* The alternation record is positions this does not adjust, so an insertion
     is the end of it; see the record in re_compiler. The alternation that
     writes one does so after its own insertions, and the lookbehind arm has
     read what it needs of the record before it inserts anything, so nothing
     that needs the record loses it here. */
  c->alt_count = 0;
  for (uint32_t i = 0; i < count; i++) {
    emit(c, RE_JMP, 0, 0);  /* grow array */
  }
  uint32_t len = c->code_len - count - pos;
  memmove(&c->pat->code[pos + count], &c->pat->code[pos], sizeof(re_inst) * len);
  for (uint32_t i = 0; i < count; i++) {
    c->pat->code[pos + i].op = RE_JMP;
    c->pat->code[pos + i].a = 0;
    c->pat->code[pos + i].offset = 0;
  }

  /* Fix code indices across the insertion. An index past `pos` shifts down by
     `count`. An index equal to `pos` is ambiguous:
     - code that moved (i >= pos + count) is a backward jump -- e.g. the SPLIT
       that loops `\d+` back to its class -- and meant the instruction now at
       pos+count, so it must follow.
     - code before the insertion (i < pos) is a forward "skip to here"
       reference that should stay on the first newly inserted instruction. A
       lookaround is always that second case, since the end of its sub-pattern
       lies ahead of it: leaving the end at `pos` puts the inserted
       instruction after the sub-pattern rather than inside it, which is what
       the quantifier wrapping the whole group wants. */
  for (uint32_t i = 0; i < c->code_len; i++) {
    if (i >= pos && i < pos + count) continue;
    if (op_holds_code_index(c->pat->code[i].op) &&
        (c->pat->code[i].offset > pos || (c->pat->code[i].offset == pos && i >= pos + count))) {
      c->pat->code[i].offset = (uint16_t)(c->pat->code[i].offset + count);
    }
  }
}

/* Insert one instruction at position `pos`; see insert_insts(). */
static void
insert_inst(re_compiler *c, uint32_t pos, uint8_t op, uint8_t a, uint16_t offset)
{
  insert_insts(c, pos, 1);
  c->pat->code[pos].op = op;
  c->pat->code[pos].a = a;
  c->pat->code[pos].offset = offset;
}

static int
peek(re_compiler *c)
{
  if (c->p >= c->src_end) return -1;
  return (uint8_t)*c->p;
}

static int
next_char(re_compiler *c)
{
  if (c->p >= c->src_end) return -1;
  return (uint8_t)*c->p++;
}

/* Under /x, step over the whitespace between two tokens. Called where one
   token ends and the next may begin, in compile_levels() and before the
   quantifier in compile_quantifiers(), and nowhere else: whitespace inside a
   token is the token's own, so `a{1, 2}` is not an interval and `(?<a b>x)`
   names the group "a b", as in CRuby, whose tokenizer skips whitespace only
   where it fetches a token. The bytes are the five Onigmo skips; a vertical
   tab is a literal under /x there, and here.

   `#` comments are not skipped here: preprocess_pattern() removes them, as
   CRuby's own pre-pass does before it tokenizes, which is what lets a removed
   comment join `\1` to the `0` after it. */
static mrb_bool
extended_space(int ch)
{
  return ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r' || ch == '\f';
}

static void
skip_extended_space(re_compiler *c)
{
  if (!(c->flags & RE_FLAG_EXTENDED)) return;
  while (extended_space(peek(c))) next_char(c);
}

static uint16_t
add_class(re_compiler *c)
{
  if (c->pat->num_classes >= RE_MAX_CLASSES) {
    compile_error(c, "too many character classes");
  }
  if (c->pat->num_classes >= c->class_capa) {
    c->class_capa = c->class_capa ? c->class_capa * 2 : 8;
    c->pat->classes = (re_charclass*)mrb_realloc(c->mrb, c->pat->classes, sizeof(re_charclass) * c->class_capa);
  }
  /* num_classes counts the entries mrb_re_free() reads a `ranges` pointer
     out of, so the slot is cleared before it is counted rather than after. */
  uint16_t id = c->pat->num_classes;
  memset(&c->pat->classes[id], 0, sizeof(re_charclass));
  c->pat->num_classes = id + 1;
  return id;
}

/* Give back the class added last, once what it held has been merged into
   another. Only the last one can go: an id below it may already stand in an
   emitted instruction, and num_classes is what mrb_re_free() walks. The
   literal record goes with it, since the id is handed out again and an entry
   left behind would let literal_class() take the next class for the /i
   literal this one stood for. */
static void
drop_class(re_compiler *c, uint16_t id)
{
  mrb_assert(id + 1 == c->pat->num_classes);
  mrb_free(c->mrb, c->pat->classes[id].ranges);
  memset(&c->pat->classes[id], 0, sizeof(re_charclass));
  c->literal_cp[id] = 0;
  c->pat->num_classes = id;
}

/* The class a /i literal for `cp` compiles to, whether it exists yet or not.

   The class holds `cp` and its case counterparts, and nothing else reaches it:
   not the flags in force, not the pattern around it, and no writer once the
   emitter that made it has returned. What it holds is a function of `cp`, so
   the second occurrence of a codepoint can name the class the first one made
   rather than make another. Each occurrence used to make its own, and a class
   id is a uint8_t, so a phrase of a few hundred letters under /i ran out of
   ids and was refused as having too many character classes, where the
   classes it needed were as many as its distinct letters.

   Every class is recorded by id, which keeps the record the size of the id
   space and lets it be searched to `num_classes` alone. It sits in the
   compiler's own frame rather than behind `pat`, since nothing outlives the
   compile that would want it. Zero marks a class that stands for no literal:
   it cannot be mistaken for one, since U+0000 has no case and neither caller
   folds it. Only the id is handed back, and it is for the caller to fill a
   class that is new, so that a class this function made is never taken for
   one it found. */
static uint16_t
literal_class(re_compiler *c, uint32_t cp, mrb_bool *found)
{
  for (uint16_t id = 0; id < c->pat->num_classes; id++) {
    if (c->literal_cp[id] == cp) {
      *found = TRUE;
      return id;
    }
  }
  uint16_t id = add_class(c);
  c->literal_cp[id] = cp;
  *found = FALSE;
  return id;
}

static void
bitmap_set(uint8_t *bits, uint8_t ch)
{
  if (ch < 128) {
    bits[ch >> 3] |= (1 << (ch & 7));
  }
}

static void
class_set_bit(re_charclass *cc, uint8_t ch)
{
  bitmap_set(cc->bitmap, ch);
}

static mrb_bool
bitmap_get(const uint8_t *bits, uint8_t ch)
{
  if (ch >= 128) return FALSE;
  return (bits[ch >> 3] >> (ch & 7)) & 1;
}

static mrb_bool
class_get_bit(const re_charclass *cc, uint8_t ch)
{
  return bitmap_get(cc->bitmap, ch);
}

/* Add a non-ASCII codepoint range [lo, hi]. Both bounds must be >= 128.

   The list is held sorted by `lo`, with no two entries that overlap or touch.
   A range the class already covers then costs nothing to add again: the
   search below finds the entry holding it and widens that one where it has
   to, rather than appending a second entry naming what the first already
   accepts. Merging with the entry appended last left that to scan order, and
   closing a class under folding has none: the folds of [U+0080-U+2FFF] land
   inside the range that was written, and each of them appended an entry that
   range already covered, 527 of them for that class alone.

   Sorting them is the same answer at match time, where class_match() reads
   the list through, and at emit time, where every entry is bytecode.

   A byte range carries RE_CLASS_BYTE in both bounds, which is the top bit, so
   the tagged entries sort above every codepoint and no gap of one can close
   between the two kinds. */
static void
class_add_range(re_compiler *c, re_charclass *cc, uint32_t lo, uint32_t hi)
{
  uint32_t n = cc->num_ranges;

  /* Within one walk the ranges arrive ascending, so the entry standing
     highest is usually the one the next range joins. Nothing stands above it
     to close a gap to, which is what lets it be widened where it is. */
  if (n > 0) {
    uint32_t *last = &cc->ranges[2 * (n - 1)];
    if (lo >= last[0] && lo <= last[1] + 1) {
      if (hi > last[1]) last[1] = hi;
      return;
    }
  }

  /* The first entry that reaches [lo, hi] or begins after it: everything
     before it ends more than one below `lo` and cannot join. */
  uint32_t i = 0, j = n;
  while (i < j) {
    uint32_t mid = i + (j - i) / 2;
    if (cc->ranges[2 * mid + 1] + 1 < lo) i = mid + 1;
    else j = mid;
  }

  if (i < n && cc->ranges[2 * i] <= hi + 1) {
    /* It joins entry i. Widening it can close the gap to the entries above,
       so they are swallowed and what is left of the list is closed up. */
    uint32_t *r = &cc->ranges[2 * i];
    if (lo < r[0]) r[0] = lo;
    if (hi > r[1]) r[1] = hi;
    uint32_t k = i + 1;
    while (k < n && cc->ranges[2 * k] <= r[1] + 1) {
      if (cc->ranges[2 * k + 1] > r[1]) r[1] = cc->ranges[2 * k + 1];
      k++;
    }
    if (k > i + 1) {
      memmove(&cc->ranges[2 * (i + 1)], &cc->ranges[2 * k],
              sizeof(uint32_t) * 2 * (n - k));
      cc->num_ranges = n - (k - i - 1);
    }
    return;
  }

  if (n >= cc->range_capa) {
    /* range_capa/num_ranges are uint32_t: doubling from 32768 no longer
       wraps to 0 (which fed a size-0 realloc and a write through NULL). */
    uint32_t new_capa = cc->range_capa ? cc->range_capa * 2 : 4;
    cc->ranges = (uint32_t*)mrb_realloc(c->mrb, cc->ranges, sizeof(uint32_t) * 2 * new_capa);
    cc->range_capa = new_capa;
  }
  memmove(&cc->ranges[2 * (i + 1)], &cc->ranges[2 * i],
          sizeof(uint32_t) * 2 * (n - i));
  cc->ranges[2 * i] = lo;
  cc->ranges[2 * i + 1] = hi;
  cc->num_ranges = n + 1;
}

/* Add a single non-ASCII codepoint to the class. */
static void
class_add_codepoint(re_compiler *c, re_charclass *cc, uint32_t cp)
{
  class_add_range(c, cc, cp, cp);
}

static void
class_set_range(re_charclass *cc, uint8_t lo, uint8_t hi)
{
  for (int i = lo; i <= hi; i++) {
    class_set_bit(cc, (uint8_t)i);
  }
}

/* Add the case counterparts of an ASCII letter to a class that already holds
   both of its ASCII cases. Used for the single-literal paths, where the class
   exists only to express the choice between one character and its other
   cases. Only 'k' and 's' have a counterpart outside ASCII, which is why a
   build without the Unicode table still has something to do here: folding
   half of their equivalence classes is what makes [^k] under /i accept
   U+212A. */
static void
class_add_fold_counterparts(re_compiler *c, uint16_t id, uint32_t cp)
{
#ifdef RE_UNICODE_CASE
  uint32_t alt[MRB_UNI_MAX_UNFOLD];
  int n = mrb_uni_case_unfold(cp, alt, MRB_UNI_MAX_UNFOLD);
  for (int i = 0; i < n; i++) {
    if (alt[i] < 128) class_set_bit(&c->pat->classes[id], (uint8_t)alt[i]);
    else class_add_codepoint(c, &c->pat->classes[id], alt[i]);
  }
#else
  if (cp == 'k' || cp == 'K') class_add_codepoint(c, &c->pat->classes[id], RE_FOLD_KELVIN);
  else if (cp == 's' || cp == 'S') class_add_codepoint(c, &c->pat->classes[id], RE_FOLD_LONG_S);
#endif
}

#ifdef RE_UNICODE_CASE
/* The part of the class at or above `cp`, as the first range holding a member
   that high. FALSE where the class holds none. The list is sorted, so this is
   a search rather than a scan, and it answers against the list as it stands
   rather than against a position taken before it moved. */
static mrb_bool
class_next_range(const re_charclass *cc, uint32_t cp, uint32_t *lo, uint32_t *hi)
{
  uint32_t n = cc->num_ranges, i = 0, j = n;
  while (i < j) {
    uint32_t mid = i + (j - i) / 2;
    if (cc->ranges[2 * mid + 1] < cp) i = mid + 1;
    else j = mid;
  }
  if (i >= n) return FALSE;
  *lo = cc->ranges[2 * i] > cp ? cc->ranges[2 * i] : cp;
  *hi = cc->ranges[2 * i + 1];
  return TRUE;
}

/* Closure for the range walks, which report counterpart spans one at a time.
   A span can straddle 128 (U+017F folds to 's'), so it is split the same way
   a written range is. */
typedef struct {
  re_compiler *c;
  re_charclass *cc;
} class_fold_sink;

static void
class_fold_add(void *user, uint32_t lo, uint32_t hi)
{
  class_fold_sink *s = (class_fold_sink*)user;
  if (lo < 128) {
    class_set_range(s->cc, (uint8_t)lo, (uint8_t)(hi < 128 ? hi : 127));
  }
  if (hi >= 128) {
    class_add_range(s->c, s->cc, lo < 128 ? 128 : lo, hi);
  }
}
#endif

static void
class_add_shorthand(re_charclass *cc, int ch)
{
  switch (ch) {
  case 'd':
    class_set_range(cc, '0', '9');
    break;
  case 'D':
    class_set_range(cc, 0, '0'-1);
    class_set_range(cc, '9'+1, 127);
    cc->utf8_any = TRUE;
    break;
  case 'w':
    class_set_range(cc, 'a', 'z');
    class_set_range(cc, 'A', 'Z');
    class_set_range(cc, '0', '9');
    class_set_bit(cc, '_');
    break;
  case 'W':
    for (int i = 0; i < 128; i++) {
      if (!mrb_re_is_word_char(i)) class_set_bit(cc, (uint8_t)i);
    }
    cc->utf8_any = TRUE;
    break;
  case 's':
    class_set_bit(cc, ' ');
    class_set_bit(cc, '\t');
    class_set_bit(cc, '\n');
    class_set_bit(cc, '\r');
    class_set_bit(cc, '\f');
    class_set_bit(cc, '\v');
    break;
  case 'S':
    for (int i = 0; i < 128; i++) {
      if (i != ' ' && i != '\t' && i != '\n' && i != '\r' && i != '\f' && i != '\v')
        class_set_bit(cc, (uint8_t)i);
    }
    cc->utf8_any = TRUE;
    break;
  case 'h':
    /* hex digit: [0-9a-fA-F] */
    class_set_range(cc, '0', '9');
    class_set_range(cc, 'a', 'f');
    class_set_range(cc, 'A', 'F');
    break;
  case 'H':
    /* non-hex-digit: complement of [0-9a-fA-F]. Built as an explicit
       positive set so the top-level dispatcher can emit it as RE_CLASS
       and the `[...]` path can add it directly -- both contexts need the
       complement bits present (the uppercase->RE_NCLASS auto-route used
       by \D/\W/\S is deliberately bypassed for \H). */
    for (int i = 0; i < 128; i++) {
      mrb_bool is_hex = (i >= '0' && i <= '9') ||
                        (i >= 'a' && i <= 'f') ||
                        (i >= 'A' && i <= 'F');
      if (!is_hex) class_set_bit(cc, (uint8_t)i);
    }
    cc->utf8_any = TRUE;
    break;
  }
}

/* Everything `src` holds joins `dst`. class_match() reads a class as one OR
   -- the bitmap and the range list each answer for a side of 128, and
   utf8_any and the bracket types answer above it -- so the union of two is a
   merge field by field. The ranges go through class_add_range() rather than
   being appended, since the list is held sorted and src's entries interleave
   with dst's. */
static void
class_union(re_compiler *c, re_charclass *dst, const re_charclass *src)
{
  for (int i = 0; i < RE_CLASS_BITMAP_SIZE; i++) dst->bitmap[i] |= src->bitmap[i];
  for (uint32_t i = 0; i < src->num_ranges; i++) {
    class_add_range(c, dst, src->ranges[2 * i], src->ranges[2 * i + 1]);
  }
  if (src->utf8_any) dst->utf8_any = TRUE;
#ifdef RE_UNICODE_CTYPE
  /* Two brackets joined are a character with a type either of them admits,
     which the pair spells and the masks of an intersection do not: a class
     that has to have every bit of one mask cannot also stand for a character
     that has none of them. One side asking nothing about the type is what
     lets the other's answer through whole. */
  if (RE_CLASS_HAS_CTYPE(src)) {
    if (!RE_CLASS_HAS_CTYPE(dst)) {
      dst->ctype_yes = src->ctype_yes;
      dst->ctype_no = src->ctype_no;
      dst->ctype_all = src->ctype_all;
      dst->ctype_none = src->ctype_none;
    }
    else if ((dst->ctype_all | dst->ctype_none | src->ctype_all | src->ctype_none) != 0) {
      compile_error(c, "this character class union is not supported");
    }
    else {
      dst->ctype_yes |= src->ctype_yes;
      dst->ctype_no |= src->ctype_no;
    }
  }
#endif
}

/* The spans both lists hold, into `out`. Each is sorted and holds no two
   entries that overlap or touch, so one walk down the pair answers: the
   entries facing each other overlap in at most one span, and the one ending
   first is the one that can meet nothing further along. The byte ranges carry
   RE_CLASS_BYTE, which sorts them above every codepoint in both lists, so the
   walk keeps the two spaces apart without knowing they are there. */
static void
ranges_intersect(re_compiler *c, re_charclass *out,
                 const uint32_t *a, uint32_t na, const uint32_t *b, uint32_t nb)
{
  uint32_t i = 0, j = 0;
  while (i < na && j < nb) {
    uint32_t lo = a[2 * i] > b[2 * j] ? a[2 * i] : b[2 * j];
    uint32_t hi = a[2 * i + 1] < b[2 * j + 1] ? a[2 * i + 1] : b[2 * j + 1];
    if (lo <= hi) class_add_range(c, out, lo, hi);
    if (a[2 * i + 1] < b[2 * j + 1]) i++;
    else j++;
  }
}

#ifdef RE_UNICODE_CTYPE
/* How many bits a mask has set, which is how many separate things it says
   about a character's type. */
static int
count_bits(uint16_t v)
{
  int n = 0;
  while (v) { v &= (uint16_t)(v - 1); n++; }
  return n;
}

/* A bracket read on its own leaves the class asking for one type either way,
   which is a disjunction of one and so a conjunct like any other: [[:alpha:]]
   is a character whose type has RE_CTYPE_ALPHA and [[:^alpha:]] one whose
   type has not. Moving it to the masks is what leaves the pair free for the
   side of an intersection that needs it, so that [[:alpha:][:digit:]&&[:^lower:]]
   keeps the one disjunction it is written with. */
static void
class_ctype_to_masks(re_charclass *cc)
{
  uint16_t yes = cc->ctype_yes, no = cc->ctype_no;
  if (yes && !no && (yes & (yes - 1)) == 0) {
    cc->ctype_all |= yes;
    cc->ctype_yes = 0;
  }
  else if (no && !yes && (no & (no - 1)) == 0) {
    cc->ctype_none |= no;
    cc->ctype_no = 0;
  }
}

/* The part of a range list that the brackets of `by` hold, into `out`. This
   is the one place a bracket is written out as members: an intersection has
   to say which characters of a range are letters, where a class that merely
   holds [[:alpha:]] can leave the question to match time. What it writes is
   bounded by the table's runs rather than by the length of the range. */
static void
ranges_filter_ctype(re_compiler *c, re_charclass *out,
                    const uint32_t *r, uint32_t n, const re_charclass *by)
{
  for (uint32_t i = 0; i < n; i++) {
    uint32_t lo = r[2 * i], hi = r[2 * i + 1];
    if (lo & RE_CLASS_BYTE) {
      /* A byte spells no character and has no type, so a bracket holds it
         only in the negative. The whole run of them is one answer. */
      if (mrb_re_class_ctype_match(by, lo)) class_add_range(c, out, lo, hi);
      continue;
    }
    while (lo <= hi) {
      mrb_bool in;
      uint32_t end = mrb_re_ctype_span(by, lo, hi, &in);
      if (in) class_add_range(c, out, lo, end);
      lo = end + 1;
    }
  }
}
#endif

/* Everything both classes hold, into the first of them. `&&` is what asks for
   this, and the two are read the way class_match() reads one: a bitmap for
   ASCII, and above it a range list, the brackets and the utf8_any catch-all,
   any of which can answer for a character on its own.

   An OR of terms on each side makes their intersection a product of sums, and
   what keeps it from growing into one is that utf8_any is the whole of the
   space above ASCII: a side that has it leaves the other side's answer to
   stand. With neither of them holding it, what is left above ASCII is the
   spans the two share and the spans of each that the other's brackets hold.
   Both are written out as ranges. What the brackets are left saying is what
   both sides said about the type, which is a conjunction: the class carries
   it as the masks class_ctype_to_masks() moves a bracket into, and refuses
   the one shape they cannot hold, a disjunction of brackets on either side of
   the `&&`. */
static void
class_intersect(re_compiler *c, uint16_t dst_id, uint16_t src_id)
{
  {
    re_charclass *dst = &c->pat->classes[dst_id];
    re_charclass *src = &c->pat->classes[src_id];
    for (int i = 0; i < RE_CLASS_BITMAP_SIZE; i++) dst->bitmap[i] &= src->bitmap[i];

    /* src holds every character and every byte above ASCII, so dst keeps
       what it holds there. */
    if (src->utf8_any) return;

    if (dst->utf8_any) {
      /* The same the other way, which takes a copy rather than nothing: what
         dst holds above ASCII becomes what src holds. */
      mrb_free(c->mrb, dst->ranges);
      dst->ranges = NULL;
      dst->num_ranges = dst->range_capa = 0;
      dst->utf8_any = FALSE;
#ifdef RE_UNICODE_CTYPE
      dst->ctype_yes = src->ctype_yes;
      dst->ctype_no = src->ctype_no;
      dst->ctype_all = src->ctype_all;
      dst->ctype_none = src->ctype_none;
#endif
      for (uint32_t i = 0; i < src->num_ranges; i++) {
        class_add_range(c, dst, src->ranges[2 * i], src->ranges[2 * i + 1]);
      }
      return;
    }

#ifdef RE_UNICODE_CTYPE
    class_ctype_to_masks(dst);
    class_ctype_to_masks(src);
    if ((dst->ctype_yes | dst->ctype_no) && (src->ctype_yes | src->ctype_no)) {
      /* Two disjunctions, where the class has room for one. */
      compile_error(c, "this character class intersection is not supported");
    }
#endif
  }

  /* The result is built beside the two rather than over dst, whose entries
     are still being read. It goes in the table so that an allocation failing
     part way through leaves it for mrb_re_free() rather than for nobody, and
     the table can move, so every pointer into it is taken after this. */
  uint16_t out_id = add_class(c);
  {
    re_charclass *out = &c->pat->classes[out_id];
    re_charclass *dst = &c->pat->classes[dst_id];
    const re_charclass *src = &c->pat->classes[src_id];
    ranges_intersect(c, out, dst->ranges, dst->num_ranges, src->ranges, src->num_ranges);
#ifdef RE_UNICODE_CTYPE
    /* Each side's ranges are asked of the other's brackets before the two
       questions become one, since what is written out here is what a bracket
       held on its own and the conjunction holds neither list. */
    if (RE_CLASS_HAS_CTYPE(src)) {
      ranges_filter_ctype(c, out, dst->ranges, dst->num_ranges, src);
    }
    if (RE_CLASS_HAS_CTYPE(dst)) {
      ranges_filter_ctype(c, out, src->ranges, src->num_ranges, dst);
    }
    if (RE_CLASS_HAS_CTYPE(dst) && RE_CLASS_HAS_CTYPE(src)) {
      dst->ctype_yes |= src->ctype_yes;
      dst->ctype_no |= src->ctype_no;
      dst->ctype_all |= src->ctype_all;
      dst->ctype_none |= src->ctype_none;
    }
    else {
      /* One side saying nothing about the type leaves the class saying
         nothing: a character the other held that way is here only where this
         one had it too, and that is a range now. */
      dst->ctype_yes = dst->ctype_no = dst->ctype_all = dst->ctype_none = 0;
    }
#endif
    mrb_free(c->mrb, dst->ranges);
    dst->ranges = out->ranges;
    dst->num_ranges = out->num_ranges;
    dst->range_capa = out->range_capa;
    out->ranges = NULL;
    out->num_ranges = out->range_capa = 0;
  }
  drop_class(c, out_id);
}

/* The two spaces the range list keeps apart, as the bounds of each: the
   characters above ASCII, and the bytes that spell none, which carry
   RE_CLASS_BYTE. A complement is taken over each of them separately, since a
   member of one is no member of the other and the gap between them belongs
   to neither. */
static const uint32_t class_spaces[2][2] = {
  { 128, 0x10ffff },
  { RE_CLASS_BYTE | 0x80, RE_CLASS_BYTE | 0xff },
};

/* Turn the class into the set of everything it does not hold. A negated
   class nested in another one is what needs this: [[^a]b] is a union, and a
   set can only join a union once it is written out as members.

   class_match() reads a class as an OR of terms, so a complement is an AND
   of their negations, and this structure holds no AND. What saves it is that
   at most one term is ever there to negate:

   - The bitmap stands alone, ASCII being a space of its own. It inverts.
   - utf8_any holds every byte above ASCII and every character whatever the
     other terms say, so its negation holds none of either and leaves them
     nothing to say.
   - A bracket type, with no range beside it, negates by changing polarity:
     ctype_yes is the type a character has and ctype_no the type it lacks,
     and mrb_re_class_ctype_match() reads a byte as having none. One bit is
     the bound the swap holds at, since [[:alpha:][:digit:]] is a character
     that is a letter *or* a digit and its complement one that is neither,
     which no single polarity spells. A mask the pair moved into negates the
     same way, into the polarity it left, and the conjunction an intersection
     wrote is a term apiece: two of them are two to negate, and their
     complement is the OR this cannot write either.
   - With no type in the class the ranges stand alone, and their gaps are the
     complement.

   A type beside a range, or two of them, is the AND this cannot write, and
   is refused rather than answered with a set the pattern did not ask for. */
static void
class_complement(re_compiler *c, re_charclass *cc)
{
  for (int i = 0; i < RE_CLASS_BITMAP_SIZE; i++) {
    cc->bitmap[i] = (uint8_t)~cc->bitmap[i];
  }

  if (cc->utf8_any) {
    cc->utf8_any = FALSE;
    cc->num_ranges = 0;
#ifdef RE_UNICODE_CTYPE
    cc->ctype_yes = cc->ctype_no = cc->ctype_all = cc->ctype_none = 0;
#endif
    return;
  }

#ifdef RE_UNICODE_CTYPE
  if (RE_CLASS_HAS_CTYPE(cc)) {
    uint16_t type = cc->ctype_yes | cc->ctype_no;
    /* What the class asks about the type has to come to one term for there to
       be a single one to negate: the pair is one of them, and each bit of a
       mask is another. */
    int terms = (type != 0) + count_bits(cc->ctype_all) + count_bits(cc->ctype_none);
    if (cc->num_ranges != 0 || terms != 1 ||
        (cc->ctype_yes && cc->ctype_no) || (type & (type - 1)) != 0) {
      compile_error(c, "this negated nested character class is not supported");
    }
    uint16_t yes = cc->ctype_yes;
    cc->ctype_yes = cc->ctype_no | cc->ctype_none;
    cc->ctype_no = yes | cc->ctype_all;
    cc->ctype_all = cc->ctype_none = 0;
    return;
  }
#endif

  /* With nothing above ASCII in the class, the complement holds everything
     there, and utf8_any says so in one field. Spelling it out as the two
     full spans instead would put a range across the cased characters into
     every such class, and a build without the folding tables refuses one
     under /i: [[^a]x] would be refused for a fold with nothing to add, the
     span already holding every counterpart it could reach. */
  if (cc->num_ranges == 0) {
    cc->utf8_any = TRUE;
    return;
  }

  /* The gaps of a sorted list whose entries neither overlap nor touch, read
     off in one walk per space. A space with k entries in it has at most k+1
     gaps, so the two together fit in num_ranges + 2. */
  uint32_t capa = cc->num_ranges + 2;
  uint32_t *comp = (uint32_t*)mrb_malloc(c->mrb, sizeof(uint32_t) * 2 * capa);
  uint32_t n = 0;
  for (int s = 0; s < 2; s++) {
    uint32_t next = class_spaces[s][0];
    for (uint32_t i = 0; i < cc->num_ranges; i++) {
      uint32_t lo = cc->ranges[2 * i], hi = cc->ranges[2 * i + 1];
      if (lo < class_spaces[s][0] || lo > class_spaces[s][1]) continue;
      if (lo > next) {
        comp[2 * n] = next;
        comp[2 * n + 1] = lo - 1;
        n++;
      }
      if (hi + 1 > next) next = hi + 1;
    }
    if (next <= class_spaces[s][1]) {
      comp[2 * n] = next;
      comp[2 * n + 1] = class_spaces[s][1];
      n++;
    }
  }
  mrb_free(c->mrb, cc->ranges);
  cc->ranges = comp;
  cc->num_ranges = n;
  cc->range_capa = capa;
}

/* The byte UTF-8 begins the character `cp` with. */
static uint32_t
utf8_lead_byte(uint32_t cp)
{
  if (cp < 0x80) return cp;
  if (cp < 0x800) return 0xC0 | (cp >> 6);
  if (cp < 0x10000) return 0xE0 | (cp >> 12);
  return 0xF0 | (cp >> 18);
}

/* Set ASCII bits for a POSIX class name (e.g. "alpha") into a 128-bit map.
   Returns FALSE for an unknown name. What the name holds above ASCII is
   answered separately, by the re_ctype bit written to *ctype: a build with
   the table reads the rest of the type off it, and one without has ASCII and
   nothing more, like this gem's \w/\d shorthands, so it writes nothing there
   and the caller does not read. [:xdigit:] and [:ascii:] are sets ASCII
   defines, so they hold nothing above it on any build and have no bit.

   *ascii_set is TRUE for a name whose ASCII set is one ASCII defines, [:word:]
   and [:ascii:], as opposed to one ASCII merely bounds here; the distinction
   is what compile_charclass() folds by. */
static mrb_bool
posix_class_bits(uint8_t *bits, const char *name, size_t len, mrb_bool *ascii_set,
                 uint16_t *ctype)
{
#define NAME_IS(s) (len == sizeof(s) - 1 && memcmp(name, s, len) == 0)
#define BSET(ch)   (bits[(ch) >> 3] |= (uint8_t)(1u << ((ch) & 7)))
#define BRANGE(lo, hi) do { for (int i = (lo); i <= (hi); i++) BSET(i); } while (0)
#ifdef RE_UNICODE_CTYPE
#define TYPE(t)    (*ctype = (t))
#else
#define TYPE(t)    ((void)0)
#endif
  *ascii_set = NAME_IS("word") || NAME_IS("ascii");
  TYPE(0);
  if (NAME_IS("alpha")) { BRANGE('a','z'); BRANGE('A','Z'); TYPE(RE_CTYPE_ALPHA); }
  else if (NAME_IS("digit")) { BRANGE('0','9'); TYPE(RE_CTYPE_DIGIT); }
  else if (NAME_IS("alnum")) { BRANGE('a','z'); BRANGE('A','Z'); BRANGE('0','9'); TYPE(RE_CTYPE_ALNUM); }
  else if (NAME_IS("upper")) { BRANGE('A','Z'); TYPE(RE_CTYPE_UPPER); }
  else if (NAME_IS("lower")) { BRANGE('a','z'); TYPE(RE_CTYPE_LOWER); }
  else if (NAME_IS("space")) { BSET(' '); BRANGE('\t','\r'); TYPE(RE_CTYPE_SPACE); }
  else if (NAME_IS("blank")) { BSET(' '); BSET('\t'); TYPE(RE_CTYPE_BLANK); }
  else if (NAME_IS("xdigit")) { BRANGE('0','9'); BRANGE('a','f'); BRANGE('A','F'); }
  else if (NAME_IS("word")) { BRANGE('a','z'); BRANGE('A','Z'); BRANGE('0','9'); BSET('_'); TYPE(RE_CTYPE_WORD); }
  else if (NAME_IS("cntrl")) { BRANGE(0, 0x1f); BSET(0x7f); TYPE(RE_CTYPE_CNTRL); }
  else if (NAME_IS("print")) { BRANGE(0x20, 0x7e); TYPE(RE_CTYPE_PRINT); }
  else if (NAME_IS("graph")) { BRANGE(0x21, 0x7e); TYPE(RE_CTYPE_GRAPH); }
  else if (NAME_IS("ascii")) { BRANGE(0, 0x7f); }
  else if (NAME_IS("punct")) {
    for (int i = 0x21; i <= 0x7e; i++) {
      mrb_bool alnum = (i >= 'a' && i <= 'z') || (i >= 'A' && i <= 'Z') ||
                       (i >= '0' && i <= '9');
      if (!alnum) BSET(i);
    }
    TYPE(RE_CTYPE_PUNCT);
  }
  else return FALSE;
  return TRUE;
#undef NAME_IS
#undef BSET
#undef BRANGE
#undef TYPE
}

/* Value of one hex digit, or -1 for anything else (including the -1 that
   peek() returns at the end of the pattern). */
static int
hex_value(int ch)
{
  if (ch >= '0' && ch <= '9') return ch - '0';
  if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
  if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
  return -1;
}

static int parse_escape(re_compiler *c);
static void emit_codepoint(re_compiler *c, uint32_t cp);

/* Read the character a control escape names and return the control character
   it stands for. `\cX` and `\C-X` name the same one, and a `\` in the X
   position opens an escape of its own, so `\c\n` is a control newline.

   The mask is the one this build's own lexer uses for a string, which is what
   a regexp literal is read by: /\cA/ reaches the engine as the byte already.
   Only Regexp.new() with a written-out backslash arrives here, and the two
   spellings have to name the same character. That settles `\c?`, where CRuby
   disagrees with itself: its lexer answers DEL and Onig answers 0x1f, so
   /\c?/ and Regexp.new("\\c?") are two different patterns there. Following
   the lexer keeps the pair together here. */
static int
parse_control_escape(re_compiler *c)
{
  int ch = next_char(c);

  if (ch < 0) compile_error(c, "too short control escape");
  if (ch == '\\') ch = parse_escape(c);
  if (ch == '?') return 0x7f;
  return ch & 0x1f;
}

static int
parse_escape(re_compiler *c)
{
  int ch = next_char(c);
  if (ch < 0) compile_error(c, "too short escape sequence");
  switch (ch) {
  case 'c':
    return parse_control_escape(c);
  case 'C':
    /* Only the `\C-X` spelling names a control character; a `\C` with
       anything else after it is the escape ending early, as it is to CRuby. */
    if (peek(c) != '-') compile_error(c, "too short control escape");
    next_char(c);
    return parse_control_escape(c);
  case 'M':
    /* `\M-X` sets the high bit, making a byte that starts no character. This
       engine has no encoding to read one against (see README.md), and CRuby
       refuses the escape in a pattern that is not binary, so it is refused
       rather than answered with a byte nothing matches. */
    compile_error(c, "meta escape is not supported");
  case 'n': return '\n';
  case 't': return '\t';
  case 'r': return '\r';
  case 'f': return '\f';
  case 'v': return '\v';
  case 'a': return '\a';
  case 'e': return 0x1b;
  case 'b': return '\b';  /* backspace; only reachable inside [...] since the
                             top-level dispatcher emits RE_WBOUND for `\b` */
  /* Octal escape `\NNN` (1-3 digits, value 0-255). From the top level a
     digit other than `0` reaches here only once the dispatcher has ruled out
     a backreference; inside `[...]` read_class_atom sends every digit here,
     since a class has no backreferences. Three digits can spell up to
     0777, and CRuby refuses what is past a byte rather than fold it. */
  case '0': case '1': case '2': case '3':
  case '4': case '5': case '6': case '7': {
    int val = ch - '0';
    int n = 1;
    while (n < 3) {
      int d = peek(c);
      if (d < '0' || d > '7') break;
      val = val * 8 + (d - '0');
      next_char(c);
      n++;
    }
    if (val > 0xff) compile_error(c, "invalid escape code");
    return val;
  }
  /* Hex escape `\xHH` (1-2 hex digits, value 0-255). The `\x{HHHH}` form
     for codepoints above 0xff is not implemented, and it is not read as
     `\x` either: a `\x` that no hex digit follows used to come out as
     `\x00`, so `\x{41}` compiled to a NUL and a quantifier. CRuby rejects
     it, as it rejects a bare `\x` and `\xZ`. */
  case 'x': {
    int val = 0;
    int n = 0;
    while (n < 2) {
      int v = hex_value(peek(c));
      if (v < 0) break;
      val = val * 16 + v;
      next_char(c);
      n++;
    }
    if (n == 0) compile_error(c, "invalid hex escape");
    return val & 0xff;
  }
  default: return ch;  /* literal: \., \\, \/, \(, etc. */
  }
}

/* Reject what a pattern may not name. CRuby reports both a surrogate and a
   value past the last plane as "invalid Unicode range", and reports it where
   the pattern is read rather than where it is emitted, so the check stays
   here: mrb_utf8_to_buf() refuses the second on its own but spells the first,
   and neither reaches it anyway. */
static void
check_unicode_cp(re_compiler *c, uint32_t cp)
{
  if (cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff)) {
    compile_error(c, "invalid Unicode range");
  }
}

/* Separator between the codepoints of a `\u{...}` list. */
static mrb_bool
unicode_list_space(int ch)
{
  return ch == ' ' || ch == '\t' || ch == '\n' || ch == '\v' || ch == '\f' || ch == '\r';
}

/* Read the next codepoint of an open `\u{...}` list, or close it. Returns
   FALSE once the `}` is consumed, leaving *more FALSE so the caller's loop
   ends. */
static mrb_bool
unicode_escape_next(re_compiler *c, mrb_bool *more, uint32_t *out)
{
  if (!*more) return FALSE;
  while (unicode_list_space(peek(c))) next_char(c);
  if (peek(c) == '}') {
    next_char(c);
    *more = FALSE;
    return FALSE;
  }

  uint32_t cp = 0;
  int n = 0;
  for (;;) {
    int v = hex_value(peek(c));
    if (v < 0) break;
    next_char(c);
    cp = cp * 16 + (uint32_t)v;
    /* Six digits reach U+FFFFFF, past the last plane, so a seventh can only
       be an overlong spelling. CRuby rejects `\u{0000061}` rather than
       reading it as U+0061. */
    if (++n > 6) compile_error(c, "invalid Unicode range");
  }
  /* Anything that is neither a hex digit nor the closing brace ends the
     list: a separator CRuby does not take (`\u{61,62}`), or the end of the
     pattern (`\u{61`). */
  if (n == 0) compile_error(c, "invalid Unicode list");
  check_unicode_cp(c, cp);
  *out = cp;
  return TRUE;
}

/* Read a `\u` escape and return its first codepoint; the backslash and the
   `u` are already consumed. `\uXXXX` is exactly four hex digits and yields
   one codepoint. `\u{...}` holds one or more, so *more is set and the rest
   come from unicode_escape_next(). */
static uint32_t
unicode_escape_first(re_compiler *c, mrb_bool *more)
{
  *more = FALSE;
  if (peek(c) == '{') {
    next_char(c);
    *more = TRUE;
    uint32_t cp;
    /* The list has to hold something: `\u{}` and `\u{ }` are errors, not an
       escape that contributes nothing. */
    if (!unicode_escape_next(c, more, &cp)) compile_error(c, "invalid Unicode list");
    return cp;
  }

  /* Nothing at all after `\u` is reported apart from a bad digit, as CRuby
     does: /\u/ is "too short escape sequence" while /\u6/ is not. */
  if (peek(c) < 0) compile_error(c, "too short escape sequence");
  uint32_t cp = 0;
  for (int i = 0; i < 4; i++) {
    int v = hex_value(peek(c));
    if (v < 0) compile_error(c, "invalid Unicode escape");
    next_char(c);
    cp = cp * 16 + (uint32_t)v;
  }
  check_unicode_cp(c, cp);
  return cp;
}

/* Add one member to the class: the ASCII bitmap and the range list each hold
   one side of 128, and class_match() picks the side to read from the value
   alone. Above 128 the value is a codepoint or a byte, which the tag records
   because the number cannot: see RE_CLASS_BYTE. */
static void
class_add_member(re_compiler *c, re_charclass *cc, uint32_t cp, mrb_bool is_byte)
{
  if (cp < 128) class_set_bit(cc, (uint8_t)cp);
  else class_add_codepoint(c, cc, (is_byte ? RE_CLASS_BYTE : 0) | cp);
}

/* What a `\u` escape names, in the members a class can hold. On a build whose
   characters are single bytes, a codepoint above ASCII is the bytes that spell
   it, which is already what a character written out in the class comes to
   there: read_class_atom() decodes one byte at a time, so `[Ā]` holds `\xC4`
   and `\x80`. Naming the same character rather than spelling it out cannot
   mean something else, so the escape contributes those bytes too. All but the
   last join the class here, and the last is returned, so it can open a range
   as any other atom would.

   A range so opened is a range of bytes, since that is what both ends are.
   The written out spelling reaches byte ends by its own route and comes to a
   different span, which is what a range between two characters neither
   spelling can express comes to on a build like this. */
static uint32_t
class_named_cp(re_compiler *c, re_charclass *cc, uint32_t cp, mrb_bool *is_byte)
{
  if (MRB_ENC_MULTIBYTE_P || cp < 0x80) return cp;

  char buf[4];
  int len = (int)mrb_utf8_to_buf(buf, (mrb_int)cp);
  for (int i = 0; i < len - 1; i++) {
    class_add_member(c, cc, (uint8_t)buf[i], TRUE);
  }
  *is_byte = TRUE;
  return (uint8_t)buf[len - 1];
}

/* Read one character class atom: either an ASCII byte (0-127), a
   `\escape`, or a full multi-byte UTF-8 codepoint. Returns the value and
   advances c->p. *is_byte says which of the two the value is: TRUE for a
   byte at or above 0x80 that starts no whole character, FALSE for ASCII, for
   a decoded codepoint and for `\u`, which names a codepoint outright.
   closes_range says the atom follows a `-`, which matters to a `\u{...}`
   list alone: the codepoint next to the `-` is the range end, and the rest
   of the list are members.

   The question is the one the literal path already answers: emit_char_folded()
   decodes and stands aside when the decode consumed one byte, so `\xB5` and a
   raw 0xB5 both compile to the byte outside [...]. Reading the same byte as
   U+00B5 inside [...] made the two halves of one pattern disagree about what
   the pattern holds. A byte and a codepoint of the same number are different
   members, which is what the tag on the stored value records. */
static uint32_t
read_class_atom(re_compiler *c, re_charclass *cc, mrb_bool *is_byte, mrb_bool closes_range)
{
  *is_byte = FALSE;
  if (peek(c) == '\\') {
    next_char(c);
    if (peek(c) == 'u') {
      next_char(c);
      mrb_bool more;
      uint32_t cp = unicode_escape_first(c, &more);
      uint32_t nx;
      /* Every codepoint of a `\u{...}` list is a member of its own, apart
         from the one next to a `-`, which is a range end as any other atom
         would be. That is the last of the list before the `-` and the first
         after it: `[\u{61 62}-z]` is `a` plus `b-z`, and `[a-\u{63 7a}]` is
         `a-c` plus `z`. The rest join the class here. */
      if (closes_range) {
        uint32_t end = class_named_cp(c, cc, cp, is_byte);
        while (unicode_escape_next(c, &more, &nx)) {
          mrb_bool member_byte = FALSE;
          uint32_t member = class_named_cp(c, cc, nx, &member_byte);
          class_add_member(c, cc, member, member_byte);
        }
        return end;
      }
      while (unicode_escape_next(c, &more, &nx)) {
        mrb_bool member_byte = FALSE;
        uint32_t member = class_named_cp(c, cc, cp, &member_byte);
        class_add_member(c, cc, member, member_byte);
        cp = nx;
      }
      return class_named_cp(c, cc, cp, is_byte);
    }
    /* A backslash before a multibyte character has no escape meaning, so let
       the decode below read the whole codepoint: [\Ā] is [Ā]. parse_escape()
       returns one byte, which left the continuation byte as a class atom of
       its own. A trailing backslash (peek < 0) still reaches parse_escape(),
       which reports it. */
    if (peek(c) < 0xC0) {
      uint32_t esc = (uint32_t)parse_escape(c);
      /* \xNN and octal \NNN name a byte, and the literal path emits one. */
      if (esc >= 0x80) *is_byte = TRUE;
      return esc;
    }
  }
  uint8_t b = (uint8_t)*c->p;
  if (b < 0xC0) {
    /* ASCII, or a continuation byte that starts nothing. */
    if (b >= 0x80) *is_byte = TRUE;
    return (uint32_t)next_char(c);
  }
  /* Multi-byte UTF-8 leader: decode the full codepoint. An invalid leader
     decodes as itself over one byte, so it is a byte like the rest. */
  int len = 0;
  uint32_t cp = mrb_re_decode_char(c->p, c->src_end, &len, FALSE);
  c->p += len;
  if (len == 1) *is_byte = TRUE;
  return cp;
}

/* Whether `\X` at `src` is one of the shorthand classes the class parser
   folds in whole. Each names a set rather than a character. */
static mrb_bool
at_shorthand_class(const char *src, const char *end)
{
  if (*src != '\\' || src + 1 >= end) return FALSE;
  switch (src[1]) {
  case 'd': case 'D': case 'w': case 'W':
  case 's': case 'S': case 'h': case 'H':
    return TRUE;
  default:
    return FALSE;
  }
}

/* Put the POSIX type `name` into the operand being read, or its complement
   where `neg` says so: the members of [:name:] or [:^name:]. The ASCII of a
   set ASCII defines goes to `ascii_set` rather than into the class; see
   compile_charclass(). `drop`, where given, is ASCII the type is to hold
   without, taken out before any complement is. FALSE where there is no type
   of that name. */
static mrb_bool
class_add_posix(re_compiler *c, re_charclass *cc, re_charclass *ascii_set,
                const char *name, size_t len, mrb_bool neg, const char *drop)
{
  uint8_t bits[16] = {0};
  mrb_bool by_ascii;
  uint16_t ctype;
  if (!posix_class_bits(bits, name, len, &by_ascii, &ctype)) return FALSE;
  for (; drop && *drop; drop++) {
    bits[(uint8_t)*drop >> 3] &= (uint8_t)~(1u << (*drop & 7));
  }
  re_charclass *dst = by_ascii ? ascii_set : cc;
  for (int i = 0; i < 128; i++) {
    mrb_bool in = (bits[i >> 3] >> (i & 7)) & 1;
    if (in != neg) class_set_bit(dst, (uint8_t)i);
  }
  /* Above ASCII a type is read off the table at match time, in either
     polarity. A set ASCII defines holds nothing there, so its negation
     holds everything there: [:^ascii:] is every character above ASCII
     and every byte that is no character. Without the table, every
     bracket is such a set. */
#ifdef RE_UNICODE_CTYPE
  if (ctype) {
    /* The bracket joins as a union, which is another type the class
       admits, and a class already holding an intersection of brackets
       has no room to say that. */
    if (cc->ctype_all | cc->ctype_none) {
      compile_error(c, "this character class union is not supported");
    }
    if (neg) cc->ctype_no |= ctype;
    else cc->ctype_yes |= ctype;
  }
  else if (neg) dst->utf8_any = TRUE;
#else
  (void)c;
  if (neg) dst->utf8_any = TRUE;
#endif
  return TRUE;
}

/* ---- character properties ------------------------------------------------
   \p{name}, and its complement \P{name} or \p{^name}. The POSIX names are
   the brackets under another spelling and read as them, types and all. The
   general categories and the emoji properties are spelled out as the ranges
   re_prop.h holds for them, so the class that holds one is an ordinary list
   of members by the time it is matched, and folds under /i as one. Those
   need the table, which only a build classifying characters by Unicode has;
   anywhere else they are refused, as every other property is. */

/* Room for the longest name looked up, once normalized. */
#define RE_PROP_NAME_MAX 24

enum { RE_PROP_NONE, RE_PROP_POSIX, RE_PROP_GC, RE_PROP_EMOJI };

/* The POSIX names, as [:name:] spells them and as a property name normalizes
   to: \p{Alpha} is [[:alpha:]] and \p{XDigit} [[:xdigit:]]. */
static const char *const prop_posix_names[] = {
  "alpha", "alnum", "word", "space", "upper", "lower", "digit",
  "punct", "graph", "print", "blank", "cntrl", "xdigit", "ascii",
};

#ifdef RE_UNICODE_CTYPE
/* The long names of the general categories, normalized, with the short ones
   each stands for: \p{Letter} is \p{L} and \p{Uppercase_Letter} \p{Lu}.
   LC, a cased letter, has no category of its own and is the three it lists.
   CRuby reads all of these. Digit, Cntrl and Punct are long names too, but
   the POSIX names come first and hold the same characters. */
static const struct {
  const char *name;
  char codes[3][3];
} prop_gc_long_names[] = {
  {"lc", {"Lu", "Ll", "Lt"}},
  {"casedletter", {"Lu", "Ll", "Lt"}},
  {"letter", {"L"}},
  {"uppercaseletter", {"Lu"}},
  {"lowercaseletter", {"Ll"}},
  {"titlecaseletter", {"Lt"}},
  {"modifierletter", {"Lm"}},
  {"otherletter", {"Lo"}},
  {"mark", {"M"}},
  {"combiningmark", {"M"}},
  {"nonspacingmark", {"Mn"}},
  {"spacingmark", {"Mc"}},
  {"enclosingmark", {"Me"}},
  {"number", {"N"}},
  {"decimalnumber", {"Nd"}},
  {"letternumber", {"Nl"}},
  {"othernumber", {"No"}},
  {"punctuation", {"P"}},
  {"connectorpunctuation", {"Pc"}},
  {"dashpunctuation", {"Pd"}},
  {"openpunctuation", {"Ps"}},
  {"closepunctuation", {"Pe"}},
  {"initialpunctuation", {"Pi"}},
  {"finalpunctuation", {"Pf"}},
  {"otherpunctuation", {"Po"}},
  {"symbol", {"S"}},
  {"mathsymbol", {"Sm"}},
  {"currencysymbol", {"Sc"}},
  {"modifiersymbol", {"Sk"}},
  {"othersymbol", {"So"}},
  {"separator", {"Z"}},
  {"spaceseparator", {"Zs"}},
  {"lineseparator", {"Zl"}},
  {"paragraphseparator", {"Zp"}},
  {"other", {"C"}},
  {"control", {"Cc"}},
  {"format", {"Cf"}},
  {"privateuse", {"Co"}},
  {"surrogate", {"Cs"}},
  {"unassigned", {"Cn"}},
};

/* The categories the short name `code`, `n` letters long and in either case,
   holds as a mask: a letter alone stands for every category it begins. */
static uint32_t
prop_gc_mask(const char *code, size_t n)
{
  uint32_t m = 0;
  for (int i = 0; i < RE_PROP_GC_COUNT; i++) {
    const char *gc = re_prop_gc_names[i];
    if ((gc[0] | 32) == (code[0] | 32) && (n == 1 || gc[1] == (code[1] | 32))) {
      m |= (uint32_t)1 << i;
    }
  }
  return m;
}

/* TRUE where `raw`, normalized, is `norm`. */
static mrb_bool
prop_name_is(const char *norm, const char *raw)
{
  for (; *raw; raw++) {
    char ch = *raw;
    if (ch == '_') continue;
    if (ch >= 'A' && ch <= 'Z') ch += 32;
    if (*norm++ != ch) return FALSE;
  }
  return *norm == '\0';
}
#endif

/* What the property `name` is, with its name normalized into `norm`: CRuby
   reads one without regard to case or to '_', '-' and ' ', and so does this.
   For a category the members are `*want` as a mask of the categories it
   holds, a letter standing for every category it begins and a long name for
   the ones prop_gc_long_names lists; for an emoji property they are its
   bit. */
static int
prop_lookup(const char *name, size_t len, char *norm, uint32_t *want)
{
  size_t n = 0;
  for (size_t i = 0; i < len; i++) {
    char ch = name[i];
    if (ch == '_' || ch == '-' || ch == ' ') continue;
    if (n == RE_PROP_NAME_MAX) return RE_PROP_NONE;
    norm[n++] = (ch >= 'A' && ch <= 'Z') ? (char)(ch + 32) : ch;
  }
  norm[n] = '\0';
  for (size_t i = 0; i < sizeof(prop_posix_names) / sizeof(prop_posix_names[0]); i++) {
    if (strcmp(norm, prop_posix_names[i]) == 0) return RE_PROP_POSIX;
  }
#ifdef RE_UNICODE_CTYPE
  if (n == 1 || n == 2) {
    uint32_t m = prop_gc_mask(norm, n);
    if (m) {
      *want = m;
      return RE_PROP_GC;
    }
  }
  for (size_t i = 0; i < sizeof(prop_gc_long_names) / sizeof(prop_gc_long_names[0]); i++) {
    if (strcmp(norm, prop_gc_long_names[i].name) != 0) continue;
    uint32_t m = 0;
    for (int j = 0; j < 3 && prop_gc_long_names[i].codes[j][0]; j++) {
      const char *code = prop_gc_long_names[i].codes[j];
      m |= prop_gc_mask(code, strlen(code));
    }
    *want = m;
    return RE_PROP_GC;
  }
  for (int i = 0; i < RE_PROP_EMOJI_COUNT; i++) {
    if (prop_name_is(norm, re_prop_emoji_names[i])) {
      *want = (uint32_t)1 << i;
      return RE_PROP_EMOJI;
    }
  }
#else
  (void)want;
#endif
  return RE_PROP_NONE;
}

#ifdef RE_UNICODE_CTYPE
/* The codepoints lo to hi join the class: the ASCII among them in the bitmap,
   the rest as a range. The surrogates spell no character, so they are left
   out of whatever holds them. */
static void
class_add_span(re_compiler *c, re_charclass *cc, uint32_t lo, uint32_t hi)
{
  if (lo < 128) {
    class_set_range(cc, (uint8_t)lo, (uint8_t)(hi < 128 ? hi : 127));
    if (hi < 128) return;
    lo = 128;
  }
  if (lo <= 0xDFFF && hi >= 0xD800) {
    if (lo < 0xD800) class_add_range(c, cc, lo, 0xD7FF);
    if (hi > 0xDFFF) class_add_range(c, cc, 0xE000, hi);
    return;
  }
  class_add_range(c, cc, lo, hi);
}

/* The runs of one of re_prop.h's tables that `want` admits join the class.
   A run's value is one category where `set` is FALSE, which `want` holds as a
   bit, and a set of properties where it is TRUE, any of which will do. The
   runs ascend, so every range lands at the end of the list. */
static void
class_add_runs(re_compiler *c, re_charclass *cc, const uint32_t *runs, size_t count,
               int bits, uint32_t want, mrb_bool set)
{
  for (size_t i = 0; i < count; i++) {
    uint32_t v = runs[i] & (((uint32_t)1 << bits) - 1);
    if (set ? (v & want) == 0 : ((want >> v) & 1) == 0) continue;
    uint32_t lo = runs[i] >> bits;
    uint32_t hi = i + 1 < count ? (runs[i + 1] >> bits) - 1 : 0x10FFFF;
    class_add_span(c, cc, lo, hi);
  }
}
#endif

/* Read the property at c->p, which stands on the 'p' or 'P' of the escape,
   into the operand whose class is `id`: the members a nested class holding
   the property alone would bring, [\p{Lu}] joining as [[:upper:]]-like types
   or ranges and \P{Lu} as the complement [^\p{Lu}] is. The ASCII of a set
   ASCII defines goes to `ascii_set`, as the bracket's does.

   With `negated` given, a complement is not taken but answered there, and
   the property joins as written: a property outside a class is its own
   class, which negates at match time as [^\p{Lu}] does. That is what makes
   \P{Lu} under /i reject every cased letter, as it does in CRuby, where
   [\P{Lu}] under /i closes the complement and accepts them all.

   A category or an emoji property is spelled out in a class of its own, added
   to the table for the time it takes, so that an error or a refused
   allocation leaves nothing the pattern's release would not find. That can
   move the table: a caller holding a pointer into it takes it again. */
static void
class_add_property(re_compiler *c, uint16_t id, re_charclass *ascii_set,
                   mrb_bool *negated)
{
  mrb_bool neg = next_char(c) == 'P';
  next_char(c);  /* '{' */
  if (peek(c) == '^') {
    next_char(c);
    neg = !neg;
  }
  const char *name = c->p;
  while (peek(c) >= 0 && peek(c) != '}') next_char(c);
  if (peek(c) < 0) compile_error(c, "invalid character property name");
  size_t len = (size_t)(c->p - name);
  next_char(c);  /* '}' */
  if (negated) {
    *negated = neg;
    neg = FALSE;
  }

  char norm[RE_PROP_NAME_MAX + 1];
  uint32_t want = 0;
  int kind = prop_lookup(name, len, norm, &want);
  if (kind == RE_PROP_POSIX) {
    /* \p{Punct} is the punctuation categories, where [[:punct:]] holds the
       ASCII symbols as well, in CRuby as here. Above ASCII the two agree. */
    const char *drop = strcmp(norm, "punct") == 0 ? "$+<=>^`|~" : NULL;
    class_add_posix(c, &c->pat->classes[id], ascii_set, norm, strlen(norm), neg, drop);
    return;
  }
#ifdef RE_UNICODE_CTYPE
  if (kind != RE_PROP_NONE) {
    uint16_t tmp = add_class(c);
    re_charclass *set = &c->pat->classes[tmp];
    if (kind == RE_PROP_GC) {
      class_add_runs(c, set, re_prop_gc_runs, RE_PROP_GC_RUN_COUNT,
                     RE_PROP_GC_BITS, want, FALSE);
    }
    else {
      class_add_runs(c, set, re_prop_emoji_runs, RE_PROP_EMOJI_RUN_COUNT,
                     RE_PROP_EMOJI_BITS, want, TRUE);
    }
    if (neg) class_complement(c, set);
    class_union(c, &c->pat->classes[id], set);
    drop_class(c, tmp);
    return;
  }
#endif
  compile_error_str(c, mrb_format(c->mrb, "character property {%l} is not supported",
                                  name, len));
}

/* TRUE where the text at `src` is a braced property escape, \p{...} or
   \P{...}. A bare \p is the letter, in CRuby as here. */
static mrb_bool
at_property(const char *src, const char *end)
{
  return end - src > 2 && src[0] == '\\' && (src[1] == 'p' || src[1] == 'P') &&
         src[2] == '{';
}

/* A shorthand and a POSIX bracket each name a set, so neither can be an end
   of a range. Called where one has just been folded in: a '-' after it opens
   a range this class cannot have, and CRuby reports that '-' rather than
   reading it as a member. A '-' just before the ']' is a member in both. */
static void
reject_set_as_range_start(re_compiler *c)
{
  if (peek(c) == '-' && c->p + 1 < c->src_end && c->p[1] != ']') {
    compile_error(c, "unmatched range specifier in char-class");
  }
}

/* Everything an ASCII-only set brought joins the class it was written in. */
static void
class_join_ascii_set(re_charclass *cc, const re_charclass *ascii_set)
{
  for (int i = 0; i < RE_CLASS_BITMAP_SIZE; i++) cc->bitmap[i] |= ascii_set->bitmap[i];
  if (ascii_set->utf8_any) cc->utf8_any = TRUE;
}

/* Open a level for a class body to be read into; see re_class_level. */
static re_class_level*
open_class_level(re_compiler *c, uint16_t id, mrb_bool negated)
{
  if (c->class_level_count == c->class_level_capa) {
    /* Outgrown: the levels move to a String the GC arena holds for the
       compile, as the levels the pattern nests do (see open_level()), and
       double from there. */
    uint32_t capa = c->class_level_capa * 2;
    size_t bytes = sizeof(re_class_level) * capa;
    if (mrb_nil_p(c->class_level_store)) {
      c->class_level_store = mrb_str_new(c->mrb, NULL, bytes);
      memcpy(RSTRING_PTR(c->class_level_store), c->class_levels,
             sizeof(re_class_level) * c->class_level_count);
    }
    else {
      mrb_str_resize(c->mrb, c->class_level_store, (mrb_int)bytes);
    }
    c->class_levels = (re_class_level*)RSTRING_PTR(c->class_level_store);
    c->class_level_capa = capa;
  }
  re_class_level *lv = &c->class_levels[c->class_level_count++];
  memset(lv, 0, sizeof(*lv));
  lv->id = lv->cur_id = id;
  lv->negated = negated;
  lv->first = TRUE;
  return lv;
}

/* The ']' of a nested class: the level closes, what it holds joins the
   operand the level below has open, and the class it was read into goes
   back.

   It is read into a class of its own rather than into the same one, because
   what it names is a set: a `&&` inside it takes the intersection of what is
   written there and of nothing around it, so [x[a&&b]] holds `x` and whatever
   `a` and `b` have in common. A class that is not negated then joins the outer
   one as a union, which is the same set reading [xab] gives, and a negated one
   joins it as the complement of what it holds, a set being able to join a
   union only once it is written out as members. The class goes back
   afterwards, so a pattern's nests cost one id at a time rather than one each.

   The ASCII members a nest holds only through an ASCII-only set of its own go
   to the outer level's `ascii_set` rather than into the class, which is how
   the fold at the end can still tell a `\w` written in a nest from one written
   beside it. A complement is a set of members like any other, so all of one
   goes into the class.

   Neither is closed under folding here. /i closes the union once at the end,
   which is where the counterparts of what a complement let in are picked up:
   [[^a]x] under /i holds `A`, and closing what holds it brings in `a` as
   well, so the class accepts what it was written to reject. CRuby reads it
   the same way, and reads [[^[:upper:]]x] under /i as [[:^upper:]x]. */
static void
close_nested_class(re_compiler *c)
{
  re_class_level *lv = &c->class_levels[c->class_level_count - 1];
  re_class_level *outer = lv - 1;
  re_charclass *sub = &c->pat->classes[lv->id];
  if (lv->negated) {
    class_complement(c, sub);
  }
  else {
    for (int i = 0; i < RE_CLASS_BITMAP_SIZE; i++) {
      outer->ascii_set.bitmap[i] |= sub->bitmap[i] & ~lv->cross[i];
      sub->bitmap[i] &= lv->cross[i];
    }
  }
  class_union(c, &c->pat->classes[outer->cur_id], sub);
  drop_class(c, lv->id);
  c->class_level_count--;
  c->depth--;

  /* A nested class names a set, and CRuby opens no range on one: the '-'
     after it is a member, where the '-' after a POSIX bracket or a shorthand
     is the error reject_set_as_range_start() reports. So [[a]-z] holds `a`,
     `-` and `z`, and [[:alpha:]-z] raises. */
  if (peek(c) == '-') {
    next_char(c);
    class_set_bit(&c->pat->classes[outer->cur_id], '-');
  }
}

/* TRUE where the two characters are the `&&` that separates one operand of a
   class from the next. A lone `&` is a member, as it is in CRuby. */
static mrb_bool
at_intersection(const char *p, const char *end)
{
  return p + 1 < end && p[0] == '&' && p[1] == '&';
}

/* Read the operand `lv` has open: the members written between the `&&` before
   it and the `&&`, the ']' or the nested '[' after it, which is what the
   return says; see RE_CLASS_END. The members go into the class the level is
   reading into, and the ASCII-only sets among them into the level's own
   `ascii_set`; see compile_charclass() for what is held there and why.

   A nest is reported rather than read here, so a class inside a class costs
   the level parse_class_levels() pushes and no C frame; the operand is read
   on from here once that level has closed. */
static int
parse_class_operand(re_compiler *c, re_class_level *lv)
{
  /* A nest is reported before its class is opened, and the one thing an
     operand holds that adds a class, a property, gives it back before it
     returns and has this pointer taken afresh after it, so the table does not
     move under it while the operand is read. */
  re_charclass *cc = &c->pat->classes[lv->cur_id];
  re_charclass *ascii_set = &lv->ascii_set;

  while (peek(c) != ']' || lv->first) {
    if (peek(c) < 0) compile_error(c, "premature end of char-class");
    lv->first = FALSE;

    if (at_intersection(c->p, c->src_end)) {
      next_char(c);
      next_char(c);
      return RE_CLASS_MORE;
    }

    /* A '[' inside a class opens something in CRuby rather than standing for
       itself: a POSIX bracket, a collating element, an equivalence class, or
       a class nested in this one. The bracket and the nested class are read
       here; a collating element and an equivalence class are refused, since
       taken as members they compile to a different pattern than the one
       written. `[\[]` holds the bracket itself, in CRuby as well. A '[' with
       nothing after it leaves the class unterminated, which the loop reports
       on its own. */
    if (peek(c) == '[' && c->p + 1 < c->src_end) {
      if (c->p[1] == '.') compile_error(c, "POSIX collating element is not supported");
      if (c->p[1] == '=') compile_error(c, "POSIX equivalence class is not supported");
      if (c->p[1] != ':') return RE_CLASS_NEST;
    }

    /* POSIX bracket class: [:name:] or negated [:^name:] inside [...]. */
    if (peek(c) == '[' && c->p + 1 < c->src_end && c->p[1] == ':') {
      const char *save = c->p;
      next_char(c);  /* '[' */
      next_char(c);  /* ':' */
      mrb_bool neg = FALSE;
      if (peek(c) == '^') { neg = TRUE; next_char(c); }
      const char *name = c->p;
      while (peek(c) >= 0 && peek(c) != ':' && peek(c) != ']') next_char(c);
      if (peek(c) == ':' && c->p + 1 < c->src_end && c->p[1] == ']') {
        if (!class_add_posix(c, cc, ascii_set, name, (size_t)(c->p - name), neg, NULL)) {
          compile_error(c, "invalid POSIX bracket type");
        }
        next_char(c);  /* ':' */
        next_char(c);  /* ']' */
        reject_set_as_range_start(c);
        continue;
      }
      /* The '[' opened a bracket, so a name that does not close is the
         bracket ending early rather than a literal '[', as it is to CRuby.
         Where the scan stopped makes no difference to what is said: the
         complaint is the class's own either way, as it is in CRuby, where
         /[[:al]/ and /[[:al/ raise the one message between them. */
      c->p = save;
      compile_error(c, "premature end of char-class");
    }

    /* Shorthand classes (\d, \D, \w, \W, \s, \S, \h, \H) are handled
       before the codepoint-aware path so the single-byte semantics
       stay intact. */
    if (peek(c) == '\\') {
      int esc = (c->p + 1 < c->src_end) ? (uint8_t)c->p[1] : -1;
      if (at_property(c->p, c->src_end)) {
        next_char(c);  /* '\\' */
        class_add_property(c, lv->cur_id, ascii_set, NULL);
        cc = &c->pat->classes[lv->cur_id];
        reject_set_as_range_start(c);
        continue;
      }
      if (esc == 'd' || esc == 'D' || esc == 'w' || esc == 'W' ||
          esc == 's' || esc == 'S' || esc == 'h' || esc == 'H') {
        next_char(c);  /* '\\' */
        next_char(c);  /* spec  */
        class_add_shorthand((esc == 'w' || esc == 'W') ? ascii_set : cc, esc);
        reject_set_as_range_start(c);
        continue;
      }
    }

    mrb_bool cp_byte;
    uint32_t cp = read_class_atom(c, cc, &cp_byte, FALSE);

    /* check for range a-z (or U+xxxx-U+yyyy). A '-' the operand ends at is a
       member, as one before the ']' is: [a-&&b] holds `a` and `-` on the one
       side, which is what CRuby reads there too. */
    if (peek(c) == '-' && c->p + 1 < c->src_end && c->p[1] != ']' &&
        !at_intersection(c->p + 1, c->src_end)) {
      next_char(c);  /* skip '-' */
      /* A set cannot close a range either. Read as a character `\d` is the
         letter, so [a-\d] was [a-d], a class of four letters rather than the
         error CRuby reports. A POSIX bracket in that place is caught by the
         backwards-range check below, since its '[' sorts under every letter. */
      if (at_shorthand_class(c->p, c->src_end) || at_property(c->p, c->src_end)) {
        compile_error(c, "char-class value at end of range");
      }
      /* A nested class names a set too, and CRuby answers one in that place
         with neither the range nor an error: [a-[b]] holds `b` alone, with
         the `a` and the `-` gone. Refused rather than reproduced. */
      if (peek(c) == '[' && c->p + 1 < c->src_end &&
          c->p[1] != ':' && c->p[1] != '.' && c->p[1] != '=') {
        compile_error(c, "char-class value at end of range");
      }
      mrb_bool hi_byte;
      uint32_t hi = read_class_atom(c, cc, &hi_byte, TRUE);
      /* An endpoint at or above 128 is a byte or a character, and a span from
         one to the other names neither: [\x80-µ] would run from a byte to a
         codepoint. ASCII belongs to both, so it pairs with either. */
      if (cp >= 128 && hi >= 128 && cp_byte != hi_byte) {
        compile_error(c, "character class range mixes a byte and a character");
      }
      /* A range written backwards holds nothing, and CRuby reports it rather
         than compiling a class that silently lacks the span, or in the
         negated form admits everything: [b-a] and [^b-a] both raise. The
         numbers compare, since the check above leaves no byte paired with a
         character and ASCII sits below either. */
      if (cp > hi) compile_error(c, "empty range in char class");
      /* A range that straddles the ASCII boundary is split in two: the
         bitmap takes the half below 128 and the codepoint list the rest.
         Neither half can hold the other, and class_match() picks the side
         to read from the codepoint alone, so a span left whole in the
         codepoint list is unreachable below 128. */
      if (cp < 128) class_set_range(cc, (uint8_t)cp, (uint8_t)(hi < 128 ? hi : 127));
      if (hi >= 128) {
        uint32_t tag = hi_byte ? RE_CLASS_BYTE : 0;
        class_add_range(c, cc, tag | (cp < 128 ? 128 : cp), tag | hi);
      }
    }
    else {
      class_add_member(c, cc, cp, cp_byte);
    }
  }
  next_char(c);  /* skip ']' */
  return RE_CLASS_END;
}

/* The operand ends: what it holds joins the class the level is reading into.

   The ASCII-only sets join before the intersection is taken, since the
   intersection is of what the operands hold and not of how they were written,
   and `cross` is narrowed by each operand in step: a member both sides put
   there in their own right is one the class holds in its own right. */
static void
close_class_operand(re_compiler *c, re_class_level *lv)
{
  re_charclass *cc = &c->pat->classes[lv->cur_id];

  if (lv->cur_id == lv->id) {
    for (int i = 0; i < RE_CLASS_BITMAP_SIZE; i++) lv->cross[i] = cc->bitmap[i];
    class_join_ascii_set(cc, &lv->ascii_set);
    return;
  }
  for (int i = 0; i < RE_CLASS_BITMAP_SIZE; i++) lv->cross[i] &= cc->bitmap[i];
  class_join_ascii_set(cc, &lv->ascii_set);
  class_intersect(c, lv->id, lv->cur_id);
  drop_class(c, lv->cur_id);
  lv->cur_id = lv->id;
}

/* The `&&` opens the next operand, which is read beside the class rather than
   into it, there being no way back from a union to the members it was made
   of. Only the bitmap and utf8_any are ever written to an ASCII-only set. */
static void
open_class_operand(re_compiler *c, re_class_level *lv)
{
  lv->cur_id = add_class(c);
  memset(&lv->ascii_set, 0, sizeof(lv->ascii_set));
}

/* Read a class body into class `id`, from just after its '[' (and its '^')
   through its ']': the intersection of the operands `&&` separates, each of
   them the union of what is written in it, and each of them able to hold a
   class written inside this one.

   A nest opens a level here rather than a C frame, as a '(' opens one in
   compile_levels(): the operand loop reports the '[' it stopped at, what
   follows is read by the same loop one level in, and the ']' pops the level
   into the operand the level below has open. So the classes a pattern nests
   cost the levels and no stack, at any depth, on any build.

   Two things bound the depth and the shallower answers: the class table,
   every open level holding an entry in it until it closes, and
   MRB_REGEXP_PARSE_DEPTH_LIMIT, which a nest counts against beside the
   levels the pattern has open. At the default limit the table is the one a
   pattern meets, at RE_MAX_CLASSES; a build that sets the limit at or below
   that meets the limit here first.

   `cross` receives the ASCII members the class holds in its own right, which
   is what the caller needs to tell them from the ones an ASCII-only set is
   the whole reason for; compile_charclass() says what the difference
   decides. */
static void
parse_class_levels(re_compiler *c, uint16_t id, uint8_t *cross)
{
  open_class_level(c, id, FALSE);

  for (;;) {
    /* A push can move the levels, so the one being read is taken afresh. */
    re_class_level *lv = &c->class_levels[c->class_level_count - 1];
    int ended = parse_class_operand(c, lv);

    if (ended == RE_CLASS_NEST) {
      /* The limit is met at the level that crosses it, as open_level() meets
         it, rather than at the bottom of a descent. */
      if (++c->depth > (uint32_t)MRB_REGEXP_PARSE_DEPTH_LIMIT) {
        compile_error(c, "parse depth limit over");
      }
      next_char(c);  /* '[' */
      mrb_bool negated = FALSE;
      if (peek(c) == '^') {
        next_char(c);
        negated = TRUE;
      }
      open_class_level(c, add_class(c), negated);
      continue;
    }

    close_class_operand(c, lv);
    if (ended == RE_CLASS_MORE) {
      open_class_operand(c, lv);
      continue;
    }
    if (c->class_level_count > 1) {
      close_nested_class(c);
      continue;
    }
    memcpy(cross, lv->cross, RE_CLASS_BITMAP_SIZE);
    c->class_level_count--;
    return;
  }
}

static void finish_charclass(re_compiler *c, uint16_t id, uint8_t *cross, mrb_bool negated);

/* Parse [...] character class */
static void
compile_charclass(re_compiler *c)
{
  uint16_t id = add_class(c);
  mrb_bool negated = FALSE;

  if (peek(c) == '^') {
    next_char(c);
    negated = TRUE;
  }

  /* The ASCII members a fold may leave ASCII from: the ones the class holds
     in its own right, as against the ones \w, \W, [:word:] or [:ascii:] is
     the whole reason for. The sets join the class before it is closed, so
     that the closure reaches them with the foldings that stay inside ASCII:
     what a class holds is one set however its members were written. Each of
     the sets already holds both cases of every letter in it, so for a class
     that is a union this adds nothing, and an intersection is where it tells:
     the letters left in [b-z&&\w] are cased like any others. */
  uint8_t cross[RE_CLASS_BITMAP_SIZE];
  parse_class_levels(c, id, cross);
  finish_charclass(c, id, cross, negated);
}

/* Close class `id` under /i and emit it: the class a bracket expression or a
   property outside one compiles to, once everything written in it is there.
   `cross` is the ASCII it holds in its own right; see compile_charclass(). */
static void
finish_charclass(re_compiler *c, uint16_t id, uint8_t *cross, mrb_bool negated)
{
  re_charclass *cc = &c->pat->classes[id];

  /* Close the class under case folding for /i. This runs once the class is
     complete, so it covers every form parse_class_levels() reads in: POSIX
     brackets, ranges, single literals and the nested classes whose union the
     class is. Negation is applied at match time against the same class
     (RE_NCLASS), so closing the positive set is also what keeps [^a-c] and
     [^Ā] from accepting what they were written to reject.

     Closing means: x belongs to the class whenever some written member folds
     the same way x does. A byte member has no case: it stands for no character,
     so nothing folds to it and it folds to nothing. Every walk below steps over
     the tagged ranges, which is also what keeps /i from refusing a class of
     continuation bytes on a build without the folding tables.

     What the word class and [:ascii:] brought is closed under the foldings
     that stay inside ASCII and no others, which is what `cross` records.
     Each is a set ASCII defines: \w is [a-zA-Z0-9_] and no more, so a fold
     that leaves ASCII leaves the set, and [\w] under /i is the ASCII word
     characters where [k] under /i reaches U+212A. CRuby reads them the same
     way, holding the two back from the folds it takes across the boundary,
     and it is what makes [^\w] under /i accept U+017F. The other POSIX
     brackets are ASCII here only for want of a table, and are not held back:
     CRuby folds them too, and there their members above ASCII hold what the
     fold adds anyway. */
  if (c->flags & RE_FLAG_IGNORECASE) {
    /* `cross` follows the class through the foldings that stay inside ASCII,
       so that the walk which leaves ASCII starts from every member the class
       holds in its own right and not only from the ones written in that case:
       [\wS] under /i reaches U+017F through the `s` that `S` folds to, where
       the `s` \w brought would not take it there. */
    for (int ch = 'A'; ch <= 'Z'; ch++) {
      if (bitmap_get(cross, (uint8_t)ch)) bitmap_set(cross, (uint8_t)(ch + 32));
      else if (bitmap_get(cross, (uint8_t)(ch + 32))) bitmap_set(cross, (uint8_t)ch);
    }
#ifdef RE_UNICODE_CASE
    /* That takes two rounds rather than one walk in each direction, because a
       fold can have more than one source (U+03A3 and U+03C2 both fold to
       U+03C3), and a class written with one of them reaches the others only
       through the fold they share. The first round puts that shared fold in
       the class; the second pulls in everything that folds to it. A third
       round would find nothing: whatever the second adds folds to something
       the first already added. */
    class_fold_sink sink = { c, cc };

    /* Round one: the fold of every member joins the class. Both rounds walk
       the list by codepoint rather than by index, since class_add_range()
       inserts where the order puts an entry and an index would name a
       different entry after one did. A walk that starts each step above the
       range it just handed over reaches every entry the round began with, and
       terminates whatever the additions do.

       What it may skip is an entry inserted behind the cursor, and neither
       round has anything to say about one. Folding is idempotent, so the fold
       of a fold this round added is the fold itself; and nothing folds to a
       character that folds elsewhere, so a source the next round adds has no
       source of its own. */
    for (uint32_t cp = 0;;) {
      uint32_t lo, hi;
      /* The tagged byte ranges sort above every codepoint, so the first one
         reached ends the walk rather than being stepped over. */
      if (!class_next_range(cc, cp, &lo, &hi) || (lo & RE_CLASS_BYTE)) break;
      mrb_uni_case_fold_range(lo, hi, class_fold_add, &sink);
      cp = hi + 1;
    }
    for (int ch = 'A'; ch <= 'Z'; ch++) {
      if (class_get_bit(cc, (uint8_t)ch)) class_set_bit(cc, (uint8_t)(ch + 32));
    }

    /* Round two: every source of a member joins it too. */
    for (uint32_t cp = 0;;) {
      uint32_t lo, hi;
      if (!class_next_range(cc, cp, &lo, &hi) || (lo & RE_CLASS_BYTE)) break;
      mrb_uni_case_unfold_range(lo, hi, class_fold_add, &sink);
      cp = hi + 1;
    }
    /* An ASCII member can have a non-ASCII source (U+212A folds to 'k'),
       which the range walk cannot reach: the bitmap holds no ranges. This is
       the walk that leaves ASCII, so it reads `cross` rather than the class:
       a run breaks where a member no ASCII-only set is behind gives way to one
       that is. A run is asked about in one question, since a question costs a
       walk of the tables whatever it spans. The tables hold no ASCII source,
       ASCII being what they are the rest of, so nothing this walk finds lands
       in the bitmap and no run of it grows while it is being read. */
    for (int ch = 0; ch < 128; ch++) {
      if (!class_get_bit(cc, (uint8_t)ch) || !bitmap_get(cross, (uint8_t)ch)) continue;
      int end = ch;
      while (end + 1 < 128 && class_get_bit(cc, (uint8_t)(end + 1)) &&
             bitmap_get(cross, (uint8_t)(end + 1))) end++;
      mrb_uni_case_unfold_range((uint32_t)ch, (uint32_t)end, class_fold_add, &sink);
      ch = end;
    }
    /* The upper case letter of a lower case member is the source the tables
       do not hold, so it is set here. Nothing folds to an upper case letter,
       which is what lets this come after the walk above rather than adding to
       what that walk is asked about. */
    for (int ch = 'a'; ch <= 'z'; ch++) {
      if (class_get_bit(cc, (uint8_t)ch)) class_set_bit(cc, (uint8_t)(ch - 32));
    }
#else
    /* The same closure, restricted to the foldings this build has. Refusing
       first is what makes the restriction sound: whatever is left in the
       codepoint list after this loop either folds to an ASCII letter or folds
       to nothing, so the rounds collapse into the ASCII pass with one exchange
       across the boundary in each direction. */
    for (uint32_t i = 0; i < cc->num_ranges; i++) {
      uint32_t lo = cc->ranges[2 * i], hi = cc->ranges[2 * i + 1];
      if (lo & RE_CLASS_BYTE) continue;
      if (mrb_re_needs_case_data(lo, hi)) {
        compile_error(c, "/i needs Unicode case folding for this character class");
      }
      if (lo <= RE_FOLD_LONG_S && RE_FOLD_LONG_S <= hi) class_set_bit(cc, 's');
      if (lo <= RE_FOLD_KELVIN && RE_FOLD_KELVIN <= hi) class_set_bit(cc, 'k');
    }
    for (int ch = 'a'; ch <= 'z'; ch++) {
      if (class_get_bit(cc, (uint8_t)ch)) class_set_bit(cc, (uint8_t)(ch - 32));
      else if (class_get_bit(cc, (uint8_t)(ch - 32))) class_set_bit(cc, (uint8_t)ch);
    }
    if (class_get_bit(cc, 'k') && bitmap_get(cross, 'k')) class_add_codepoint(c, cc, RE_FOLD_KELVIN);
    if (class_get_bit(cc, 's') && bitmap_get(cross, 's')) class_add_codepoint(c, cc, RE_FOLD_LONG_S);
#endif
  }

#ifdef RE_UNICODE_CTYPE
  /* A type is not spelled out as members, so the closure above never saw it;
     it is closed at match time instead, by reading the type of every
     character sharing the folding of the one in hand. The bitmap holds the
     ASCII of every bracket, and the closure has already reached across the
     boundary from there: U+017F is in the class once 's' is, so a type
     found only through an ASCII counterpart is found through the ranges. */
  cc->ctype_fold = (c->flags & RE_FLAG_IGNORECASE) && RE_CLASS_HAS_CTYPE(cc) != 0;
#endif

  cc->negated = negated;
  emit(c, negated ? RE_NCLASS : RE_CLASS, (uint8_t)id, 0);
}

/* A property outside a class, at c->p on its 'p' or 'P': the class holding it
   alone, which is what \p{Lu} and [\p{Lu}] both compile to, and \P{Lu} what
   [^\p{Lu}] does. */
static void
compile_property(re_compiler *c)
{
  uint16_t id = add_class(c);
  re_charclass ascii_set;
  mrb_bool negated;
  memset(&ascii_set, 0, sizeof(ascii_set));
  class_add_property(c, id, &ascii_set, &negated);
  re_charclass *cc = &c->pat->classes[id];
  uint8_t cross[RE_CLASS_BITMAP_SIZE];
  memcpy(cross, cc->bitmap, RE_CLASS_BITMAP_SIZE);
  class_join_ascii_set(cc, &ascii_set);
  finish_charclass(c, id, cross, negated);
}

/* Maximum value for {n}/{n,m} quantifiers. Each unit becomes (min-1) +
   (max-min) emitted copies of the inner atom; the cap keeps both the
   parse free of integer overflow and the bytecode size sane. */
#define RE_MAX_REPEAT 32768

/* Parse {n}, {n,}, {n,m} quantifier. Returns min,max via pointers. */
static mrb_bool
parse_quantifier(re_compiler *c, int *min_out, int *max_out, mrb_bool *ranged)
{
  const char *save = c->p;
  int min = 0, max = -1;
  mrb_bool has_digit = FALSE;

  *ranged = FALSE;

  while (peek(c) >= '0' && peek(c) <= '9') {
    min = min * 10 + (next_char(c) - '0');
    has_digit = TRUE;
    if (min > RE_MAX_REPEAT) compile_error(c, "too big number for repeat range");
  }
  if (peek(c) == ',') {
    next_char(c);
    *ranged = TRUE;
    if (peek(c) >= '0' && peek(c) <= '9') {
      max = 0;
      while (peek(c) >= '0' && peek(c) <= '9') {
        max = max * 10 + (next_char(c) - '0');
        has_digit = TRUE;
        if (max > RE_MAX_REPEAT) compile_error(c, "too big number for repeat range");
      }
    }
    /* else max = -1 (unlimited) */
  }
  else {
    max = min;  /* {n} means exactly n */
  }
  /* {} and {,} carry no count and are literals in Ruby, not quantifiers. */
  if (!has_digit || peek(c) != '}') {
    c->p = save;  /* not a quantifier, treat { as literal */
    return FALSE;
  }
  next_char(c);  /* skip '}' */
  /* A range written backwards names no repeat count, and CRuby reports it
     rather than compiling a repeat that silently drops the upper bound:
     compile_quantifiers() would lay out `min` mandatory copies and then a
     `max - min` loop that runs zero times, which is `{min}`. The check sits
     here, once the `}` is consumed, so that a `{...}` which is no quantifier
     at all is still restored as a literal brace above, and it lets the
     unlimited upper bound through, which is spelled -1. */
  if (max >= 0 && max < min) {
    compile_error(c, "upper is smaller than lower in repeat range");
  }
  *min_out = min;
  *max_out = max;
  return TRUE;
}

/* What one pc's measure is once fixed_len_walk() has reached it, in the two
   units a rewind may count (see RE_LB_WIDTH). `len` doubles as the state:
   the two markers below stand where no measure does. A fork's arms are
   measured to the same `end` and their measures compared, so what is
   remembered per pc is the distance from it to `end`, the same question
   whichever arm asks it, which is what makes one table serve them all. */
typedef struct {
  int32_t len;    /* bytes, or RE_FLEN_NEW / RE_FLEN_BUSY */
  int32_t chars;
} re_flen_memo;

#define RE_FLEN_NEW  (-1)   /* not measured yet */
#define RE_FLEN_BUSY (-2)   /* being measured: reaching it again is a cycle,
                               and a cycle is a body of no fixed width */

static int fixed_len_span(re_compiler *c, uint32_t start, uint32_t end,
                          int *chars_out, int depth);

/* A measure the walk left standing while it takes another. A fork is two
   measures of its own and the walk can only answer once both are in, so what
   it had taken before the fork waits here, with what the first arm answered
   once that is known, and a pc the table covers waits here to be filled from
   the measure it asked for. */
#define FLEN_MEMO  0   /* fill this pc's slot with what comes back */
#define FLEN_ARM_A 1   /* the fork's first arm is being measured */
#define FLEN_ARM_B 2   /* its second, with the first's measure in hand */

typedef struct {
  uint32_t pc;      /* MEMO: the pc measured. ARM_A: the fork itself. */
  int32_t len;      /* the arms: the measure taken before the fork */
  int32_t chars;
  int32_t a_len;    /* ARM_B: what the first arm answered */
  int32_t a_chars;
  uint8_t kind;
} flen_frame;

typedef struct {
  flen_frame *at;      /* `given` until the walk outgrows it, the heap after */
  flen_frame *given;   /* the room the caller carved out, and never freed */
  uint32_t top;
  uint32_t capa;
} flen_stack;

/* Room for one more measure, once the room the caller gave is all in use.
   FALSE is the allocator having refused it, which the walk reports as a body
   of no fixed width, the answer it gives for everything else it cannot
   measure (see fixed_len_span()). */
static mrb_bool
flen_grow(mrb_state *mrb, flen_stack *s)
{
  uint32_t capa = s->capa ? s->capa * 2 : 8;
  flen_frame *p;
  if (s->at == s->given) {
    p = (flen_frame*)mrb_malloc_simple(mrb, sizeof(flen_frame) * capa);
    /* A span the caller found no fork in is given no room at all, and a walk
       that leaves the span by a jump can still want some: there is nothing to
       carry over, and memcpy() is owed a pointer whatever the length is. */
    if (p && s->capa) memcpy(p, s->given, sizeof(flen_frame) * s->capa);
  }
  else {
    p = (flen_frame*)mrb_realloc_simple(mrb, s->at, sizeof(flen_frame) * capa);
  }
  if (!p) return FALSE;
  s->at = p;
  s->capa = capa;
  return TRUE;
}

/* Leave a measure standing. Inline: this stands where the recursive call it
   replaced stood, in the walk's own loop. */
static inline mrb_bool
flen_push(mrb_state *mrb, flen_stack *s, const flen_frame *f)
{
  if (s->top == s->capa && !flen_grow(mrb, s)) return FALSE;
  s->at[s->top++] = *f;
  return TRUE;
}

/*
 * Measure the bytecode in range [start, end) for a lookbehind, which must
 * know exactly how far back to rewind. Returns the byte count a binary
 * subject needs, one per consuming instruction since such a subject
 * advances one byte whatever the instruction is, and stores in *chars_out
 * the character count a UTF-8 subject needs. Returns -1 if the sub-pattern
 * has no fixed width (a quantifier, or a fork whose arms disagree).
 *
 * A measure the walk cannot finish before taking another stands on `stack`
 * rather than in a C frame of its own, so a body forking as often as it is
 * long is measured on the stack any build has: a body of 1,500 `(?:a|a)`
 * used to need more than 256 KiB of one and 3,000 more than 512 KiB.
 * What a pc is worth is remembered in the
 * table `memo` covers, without which a chain of forks is measured once per
 * path through it, both arms of every fork walking the whole tail, and
 * `(?:a|b)` thirty times over is 2^30 walks of a pattern a hundred bytes
 * long.
 */
static int
fixed_len_walk(re_compiler *c, uint32_t start, uint32_t end, int *chars_out,
               int depth, re_flen_memo *memo, uint32_t memo_base,
               uint32_t memo_len, flen_frame *room, uint32_t room_capa)
{
  int len = 0;
  int chars = 0;
  uint32_t pc = start;
  int r_len = 0, r_chars = 0;  /* the measure being handed back */
  int ret = -1;
  flen_stack stack;
  stack.at = stack.given = room;
  stack.top = 0;
  stack.capa = room_capa;

  /* The walk runs to `end` rather than while it is below it, because a call
     steps outside the span: an inline occurrence of a called group is a jump
     to the trampoline after the pattern and a jump back. The bound below is
     what keeps a walk that misses `end` finite; a cycle without RE_SPLIT does
     not exist, and RE_SPLIT answers -1. */
  goto walk;  /* the measure asked for here is not one the table holds */

 enter:
  /* Measure from `pc` to `end`, through the table where it covers this pc:
     a measure already taken is the answer, one being taken is a cycle and no
     fixed width, and one not taken yet is left to fill on the way back. */
  if (memo && pc >= memo_base && pc - memo_base < memo_len) {
    re_flen_memo *slot = &memo[pc - memo_base];
    if (slot->len == RE_FLEN_BUSY) goto fail;
    if (slot->len != RE_FLEN_NEW) {
      r_len = slot->len;
      r_chars = slot->chars;
      goto unwind;
    }
    slot->len = RE_FLEN_BUSY;
    flen_frame f;
    f.kind = FLEN_MEMO;
    f.pc = pc;
    f.len = f.chars = f.a_len = f.a_chars = 0;
    if (!flen_push(c->mrb, &stack, &f)) goto fail;
  }
  len = 0;
  chars = 0;

 walk:
  while (pc != end) {
    if (pc >= c->code_len) goto fail;
    re_inst inst = c->pat->code[pc];
    switch (inst.op) {
    case RE_CHAR: {
      /* A multibyte literal is a run of one-byte RE_CHAR instructions, and
         what a byte spells depends on the bytes after it, so hand the run to
         mrb_re_charlen() rather than read the lead bit alone: a continuation
         byte no lead reaches is a character of its own, which is the rule the
         executor rewinds by. Four bytes is the longest character there is,
         and a run never splits one. */
      char buf[4];
      int n = 0;
      while (n < 4 && pc + (uint32_t)n < end && c->pat->code[pc + n].op == RE_CHAR) {
        buf[n] = (char)c->pat->code[pc + n].a;
        n++;
      }
      int clen = mrb_re_charlen(buf, buf + n, FALSE);
      len += clen;
      chars += 1;
      pc += (uint32_t)clen;
      break;
    }
    case RE_BYTE:
      /* a byte that starts no character is a character of its own, which is
         the unit the rewind counts and the byte it costs */
      len += 1;
      chars += 1;
      pc++;
      break;
    case RE_CLASS:
    case RE_NCLASS:
    case RE_ANY:
    case RE_ANY_NL:
      /* one character whatever its members can be, since the executor
         hands a class one decoded character at a time */
      len += 1;
      chars += 1;
      pc++;
      break;
    case RE_SAVE:
      pc++;
      break;  /* zero-width */
    case RE_BOL: case RE_EOL: case RE_BOT: case RE_EOT: case RE_EOTNL: case RE_GPOS:
    case RE_WBOUND: case RE_NWBOUND:
      pc++;
      break;  /* zero-width assertions */
    case RE_LB_WIDTH:
      /* A rewind, which consumes nothing. A branch is measured once its
         rewind is in place, and where the last branch of the body is empty
         its rewind stands where the other branches exit to, so their walks
         run through it; see add_lookbehind_widths(). */
      pc++;
      break;
    case RE_JMP:
      pc = inst.offset;
      break;
    case RE_SPLIT:
    case RE_SPLITNG: {
      /* A fork the walk passes through is fixed only where both arms reach
         `end` by the same measure: `(?<=(a|b)c)` is two characters whichever
         arm runs, and `(?<=(a|bb)c)` is not two of anything. The arms are
         measured to `end` rather than to the point they rejoin, which is
         what makes what follows the fork part of each arm's measure and
         leaves `(?:a|bc)d` unmeasured. CRuby refuses that body too, and
         accepts a whole body of branches taking different widths only
         through the per-branch rewind the lookbehind arm builds.

         A loop closes with a backward fork, so this is also where a body
         that repeats is refused: the memo marks the pc it is measuring and
         reaching it again answers -1. */
      flen_frame f;
      f.kind = FLEN_ARM_A;
      f.pc = pc;
      f.len = len;
      f.chars = chars;
      f.a_len = f.a_chars = 0;
      if (!flen_push(c->mrb, &stack, &f)) goto fail;
      pc = pc + 1;
      goto enter;
    }
    case RE_LOOK_END:
      r_len = len;
      r_chars = chars;
      goto unwind;
    case RE_CALL: {
      /* The call runs the body it points at, so the body's measure is this
         instruction's. The depth bound is what answers a recursive call:
         distinct groups nest no deeper than there are groups, so a walk
         past that is going round a cycle, which no fixed length fits --
         CRuby refuses recursion in a lookbehind the same way. */
      if (depth > RE_MAX_CAPTURES) goto fail;
      uint32_t body = inst.offset;
      uint32_t close = body;
      while (close < c->code_len &&
             !(c->pat->code[close].op == RE_RETURN &&
               c->pat->code[close].a == inst.a)) {
        close++;
      }
      if (close >= c->code_len) goto fail;
      int sub_chars = 0;
      /* The body is measured to its own end, so it gets a table of its own:
         what a pc is worth is its distance to the end being asked about. The
         depth bound above is what keeps this a call and not a walk of its
         own: a body nests no deeper than there are groups. */
      int sub_len = fixed_len_span(c, body, close, &sub_chars, depth + 1);
      if (sub_len < 0) goto fail;
      len += sub_len;
      chars += sub_chars;
      pc++;
      break;
    }
    default:
      goto fail;  /* unknown/variable-length instruction */
    }
  }
  r_len = len;
  r_chars = chars;

 unwind:
  /* Hand the measure to whatever was left standing for it. */
  if (stack.top == 0) {
    *chars_out = r_chars;
    ret = r_len;
    goto done;
  }
  {
    flen_frame *f = &stack.at[--stack.top];
    switch (f->kind) {
    case FLEN_MEMO: {
      re_flen_memo *slot = &memo[f->pc - memo_base];
      slot->len = r_len;
      slot->chars = r_chars;
      goto unwind;
    }
    case FLEN_ARM_A: {
      /* The first arm is measured; keep it and measure the second, which the
         fork's offset opens. */
      flen_frame b;
      b.kind = FLEN_ARM_B;
      b.pc = f->pc;
      b.len = f->len;
      b.chars = f->chars;
      b.a_len = r_len;
      b.a_chars = r_chars;
      uint32_t arm = c->pat->code[f->pc].offset;
      if (!flen_push(c->mrb, &stack, &b)) goto fail;
      pc = arm;
      goto enter;
    }
    default: {  /* FLEN_ARM_B */
      if (r_len != f->a_len || r_chars != f->a_chars) goto fail;
      r_len = f->len + f->a_len;
      r_chars = f->chars + f->a_chars;
      goto unwind;
    }
    }
  }

 fail:
  /* A slot left BUSY is one whose measure was refused: a body with one
     unmeasurable path has no fixed width at all, so no later question about
     that pc has a different answer, and the compile is about to be refused
     either way. */
  ret = -1;

 done:
  if (stack.at != room) mrb_free(c->mrb, stack.at);
  return ret;
}

/* Measure [start, end) with whatever table the span needs. A span holding no
   fork and no backward edge is a straight line the walk crosses once, and it
   is measured with no table at all, which is every lookbehind that was
   measurable before per-branch widths. A span holding either gets one, since
   without it the walk would either repeat the tail of every fork or, on a
   loop, not come back. */
static int
fixed_len_span(re_compiler *c, uint32_t start, uint32_t end, int *chars_out,
               int depth)
{
  mrb_bool needs_memo = FALSE;
  for (uint32_t pc = start; pc < end && pc < c->code_len; pc++) {
    uint8_t op = c->pat->code[pc].op;
    if (op == RE_SPLIT || op == RE_SPLITNG ||
        (op == RE_JMP && c->pat->code[pc].offset <= pc)) {
      needs_memo = TRUE;
      break;
    }
  }
  /* A span with no fork and no table has nothing to leave standing either:
     what the walk keeps is a fork's other arm and a pc whose slot is to be
     filled, and this span holds neither. */
  if (!needs_memo) {
    return fixed_len_walk(c, start, end, chars_out, depth, NULL, 0, 0, NULL, 0);
  }

  uint32_t span = end > start ? end - start : 0;
  uint32_t slots = span ? span : 1;
  /* The measures the walk leaves standing are carved out of the same block
     as the table, so measuring a span asks the allocator once: a slot to
     fill and an arm to take are one apiece per pc the walk stands on, and
     the walk grows its own stack where a path it did not expect wants more.

     mrb_malloc_simple(), not mrb_malloc(): a raise here would longjmp past
     the frees of the spans measuring around this one. A refusal is reported
     as a body of no fixed width, which is what the caller does with every
     other answer it cannot use. */
  uint32_t room = slots + 8;
  if (room > 1024) room = 1024;  /* past a body of this size, let it grow */
  re_flen_memo *memo = (re_flen_memo*)mrb_malloc_simple(
      c->mrb, sizeof(re_flen_memo) * slots + sizeof(flen_frame) * room);
  if (!memo) return -1;
  for (uint32_t i = 0; i < span; i++) memo[i].len = RE_FLEN_NEW;
  int len = fixed_len_walk(c, start, end, chars_out, depth, memo, start, span,
                           (flen_frame*)(memo + slots), room);
  mrb_free(c->mrb, memo);
  return len;
}

static int
compute_fixed_len(re_compiler *c, uint32_t start, uint32_t end, int *chars_out)
{
  return fixed_len_span(c, start, end, chars_out, 0);
}

/* One measured width, as the RE_LB_WIDTH that carries it. */
static uint16_t
lookbehind_width(re_compiler *c, uint32_t start, uint32_t end)
{
  int chars = 0;
  int len = compute_fixed_len(c, start, end, &chars);
  if (len < 0) compile_error(c, "invalid pattern in look-behind");
  if (len > 255) compile_error(c, "lookbehind too long (max 255 bytes)");
  /* The character count never exceeds the byte count, so it fits too. */
  return RE_LB_PACK(len, chars);
}

/* Where branch `i` of an alternation of `n` branches begins, `from` being
   the first SPLIT of its chain: the chain's last SPLIT falls through into
   branch 0, and the SPLIT that jumps to branch i stands i places before
   that; see close_alternation() for the layout. */
static uint32_t
branch_head(re_compiler *c, uint32_t from, uint32_t n, uint32_t i)
{
  if (i == 0) return from + n - 1;
  return c->pat->code[from + n - 1 - i].offset;
}

/*
 * Give the lookbehind at `lb_pos`, whose body is [sub_start, body_end), the
 * rewinds it runs by, and refuse a body that has none.
 *
 * A body of a single fixed width carries one RE_LB_WIDTH at its head. A body
 * that *is* an alternation carries one at the head of each branch, each
 * measured on its own, which is how `(?<=ab|c)` looks back two characters
 * down one branch and one down the other. CRuby draws its line in the same
 * place, and by the same reading of the pattern: the branches of the body
 * itself may differ, while an alternation anywhere else must come out one
 * width or the body is refused, whether it stands under a capture,
 * `(?<=(ab|b))`, or with anything beside it, `(?<=(?:a|bc)d)`. `(?:...)`
 * around the whole body emits nothing, so `(?<=(?:ab|b))` is the first case
 * there as it is here.
 *
 * The single width is tried first because the alternation may already be one:
 * `(?<=ab|cd)` is two characters whichever branch runs, and one carrier for
 * the whole body is one rewind rather than two identical ones.
 */
static void
add_lookbehind_widths(re_compiler *c, uint32_t lb_pos, uint32_t sub_start,
                      uint32_t body_end)
{
  int chars = 0;
  int len = compute_fixed_len(c, sub_start, body_end, &chars);
  if (len >= 0) {
    if (len > 255) compile_error(c, "lookbehind too long (max 255 bytes)");
    c->pat->code[lb_pos].a = 1;  /* measured: measure_deferred skips it */
    insert_inst(c, sub_start, RE_LB_WIDTH, 0, RE_LB_PACK(len, chars));
    return;
  }

  /* The alternation the body left behind is the body's own only when it
     covers all of it: it starts where the body starts and ends at the
     RE_LOOK_END, which stands at body_end - 1. */
  if (!(c->alt_count > 1 && c->alt_from == sub_start &&
        c->alt_to == body_end - 1)) {
    compile_error(c, "invalid pattern in look-behind");
  }
  uint32_t n = c->alt_count;

  /* With a rewind per branch, a branch can match from another's rewind and
     stop short of where the lookbehind was entered, so the end has to check
     where it landed. One width for the whole body is the width of every path
     through it, and such a body cannot land anywhere else. */
  c->pat->code[body_end - 1].a |= RE_LOOK_LANDING;

  /* Each branch gets its rewind before any is measured, from the last head
     down so that the heads still ahead of an insertion keep their positions.
     A branch's head is what the alternation's SPLIT jumps to, and
     insert_inst() leaves such a reference on the inserted instruction, so
     the branch now begins with its rewind and the chain now names where
     that rewind stands. The measuring then reads the chain again: what it
     measures is the branch behind each rewind, which the inserted
     instructions have moved but not changed. */
  for (uint32_t i = n; i > 0; i--) {
    insert_inst(c, branch_head(c, sub_start, n, i - 1), RE_LB_WIDTH, 0, 0);
  }
  body_end += n;
  for (uint32_t i = 0; i < n; i++) {
    uint32_t at = branch_head(c, sub_start, n, i);
    c->pat->code[at].offset = lookbehind_width(c, at + 1, body_end);
  }
  c->pat->code[lb_pos].a = 1;  /* measured: measure_deferred skips it */
}

/* Parse the option letters of an inline (?...) group. The parser is
   positioned just past the '?'; it reads i, m, x and '-' in any order until
   the terminator (':' or ')'), a '-' switching the letters after it off.
   `base` is the option set in effect on entry; the resulting set is
   returned. Ruby's inline letters are i (IGNORECASE), m (DOTALL),
   x (EXTENDED). All three are scoped alike by the group they are read in:
   skip_extended_space() reads x from c->flags, which compile_atom() saves
   at every '(' and restores at its ')'. preprocess_pattern() tracks the
   same scopes over the pattern as written for the one thing it still does
   under /x, removing `#` comments.

   No letter has to come at all, and a second '-' is read like the first:
   Onigmo's loop asks only that what it reads is one of these bytes and that
   what stops it is the terminator, so `(?-)` is a toggle that changes
   nothing, `(?-:a)` is `(?:a)` and `(?--i)` is `(?-i)`. A generator that
   writes `(?#{on}-#{off}:...)` reaches the first two with both lists empty.
   The caller reports what stops the loop when it is neither ':' nor ')',
   which is where a letter that is not an option is refused, and `(?)` never
   gets here at all: compile_atom() takes this arm only on i, m, x or '-'. */
static uint32_t
parse_inline_flags(re_compiler *c, uint32_t base)
{
  uint32_t on = 0, off = 0;
  mrb_bool negate = FALSE;
  for (;;) {
    int oc = peek(c);
    uint32_t bit;
    if (oc == 'i') bit = RE_FLAG_IGNORECASE;
    else if (oc == 'm') bit = RE_FLAG_DOTALL;
    else if (oc == 'x') bit = RE_FLAG_EXTENDED;
    else if (oc == '-') { negate = TRUE; next_char(c); continue; }
    else break;
    if (negate) off |= bit;
    else on |= bit;
    next_char(c);
  }
  return (base | on) & ~off;
}

/* Emit one byte as an atom, for a character that is a single byte. Under /i an
   ASCII letter becomes a class of its case counterparts instead, so any of them
   matches. The multibyte spelling of the same job is emit_char_bytes() below. */
static void
emit_char(re_compiler *c, uint8_t ch)
{
  if ((c->flags & RE_FLAG_IGNORECASE) &&
      ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))) {
    mrb_bool found;
    uint16_t id = literal_class(c, ch, &found);
    if (!found) {
      class_set_bit(&c->pat->classes[id], ch);
      class_set_bit(&c->pat->classes[id], (uint8_t)(ch ^ 0x20));  /* the other case */
      class_add_fold_counterparts(c, id, ch);
    }
    emit(c, RE_CLASS, (uint8_t)id, 0);
    return;
  }
  emit(c, RE_CHAR, ch, 0);
}

/* Emit every byte of the character whose lead byte `ch` was just consumed, so
   the whole character is one atom. Leaving the continuation bytes to the parse
   loop made each of them an atom of its own, and a quantifier binds to the last
   atom emitted: /Ā+/ compiled as \xC4(\x80)+ and matched one Ā in "ĀĀ". An
   invalid lead byte has a charlen of 1 and still emits alone. Every atom that
   consumes a character has to emit all of its bytes before returning, since
   what compile_quantifiers() repeats is the bytes that atom emitted. */
static void
emit_char_bytes(re_compiler *c, int ch)
{
  /* A byte-indexed pattern holds bytes and not the character they would
     spell, so each one is an atom of its own and a quantifier after them
     repeats the last, which is what CRuby reads an ASCII-8BIT pattern as. */
  int len = c->binary ? 1 : mrb_re_charlen(c->p - 1, c->src_end, FALSE);
  /* A byte the pattern spells out that starts no whole character spells no
     character either, and is the same byte `\xNN` names: RE_BYTE, not a byte
     of something. Written raw or written escaped, a pattern holds one for the
     same reason and it matches in the same places. */
  if (len == 1 && ch >= 128) {
    emit(c, RE_BYTE, (uint8_t)ch, 0);
    return;
  }
  emit(c, RE_CHAR, (uint8_t)ch, 0);
  for (int i = 1; i < len; i++) {
    int b = next_char(c);
    if (b < 0) break;
    emit(c, RE_CHAR, (uint8_t)b, 0);
  }
}

/* Read one more byte escape, or answer -1 and leave the position where it
   stood. Only `\xNN` and octal `\NNN` name a byte; everything else names a
   character or an assertion and is not a byte of the sequence being spelled. */
static int
next_escaped_byte(re_compiler *c)
{
  const char *save = c->p;
  if (peek(c) != '\\') return -1;
  next_char(c);
  int k = peek(c);
  if (k != 'x' && !(k >= '0' && k <= '7')) { c->p = save; return -1; }
  int v = parse_escape(c);
  if (v < 0x80 || v > 0xBF) { c->p = save; return -1; }
  return v;
}

/* Emit a byte escape whose value is above 127, having read the first one.

   Byte escapes that spell a character are that character: CRuby reads
   `\xC4\x80` as "\u{100}" and binds a quantifier to the whole of it, and so
   does the unescaped spelling here through emit_char_bytes(). So the
   continuation bytes are read and the character emitted as one atom.

   What is left is a byte no character reaches, which is a byte and not the
   codepoint of the same number: `\xC4` alone is not "\u{C4}", and the byte it
   names lives inside "\u{100}" without being a character there. RE_BYTE is
   what asks for it, matching only where the subject byte stands alone, the
   rule `[\xC4]` already reads it by. Matching it inside a character instead
   was what let a match, a capture and a lookaround stop between two bytes of
   one. */
static void
emit_escaped_byte(re_compiler *c, int ch)
{
  int need = 0;
  if (c->binary) need = 0;  /* bytes spell no character here; see above */
  else if (ch >= 0xC2 && ch <= 0xDF) need = 1;
  else if (ch >= 0xE0 && ch <= 0xEF) need = 2;
  else if (ch >= 0xF0 && ch <= 0xF4) need = 3;

  if (need > 0) {
    const char *save = c->p;
    char buf[4];
    buf[0] = (char)ch;
    int n = 1;
    while (n <= need) {
      int b = next_escaped_byte(c);
      if (b < 0) break;
      buf[n++] = (char)b;
    }
    if (n == need + 1 && mrb_re_charlen(buf, buf + n, FALSE) == n) {
      int len = 0;
      uint32_t cp = mrb_re_decode_char(buf, buf + n, &len, FALSE);
      emit_codepoint(c, cp);
      return;
    }
    c->p = save;  /* spells no character: the lead byte is a byte of its own */
  }
  emit(c, RE_BYTE, (uint8_t)ch, 0);
}

/* Emit a non-ASCII codepoint under /i as a class rather than a run of bytes,
   and report whether it did. A counterpart need not have the same byte length
   (U+212A folds to 'k'), which a byte-wise RE_CHAR run cannot express, while
   RE_CLASS decodes one codepoint and compares that whatever its width. A
   character with no counterpart, which is most of the non-ASCII range and
   every script without case in it, falls back to the bytes and costs /i
   nothing. A character this build cannot fold is refused rather than answered
   without the folding it needs. The caller has already established /i. */
static mrb_bool
emit_cp_folded(re_compiler *c, uint32_t cp)
{
  if (mrb_re_needs_case_data(cp, cp)) {
    compile_error(c, "/i needs Unicode case folding for this character");
  }
#ifdef RE_UNICODE_CASE
  uint32_t alt[MRB_UNI_MAX_UNFOLD];
  int n = mrb_uni_case_unfold(cp, alt, MRB_UNI_MAX_UNFOLD);
#else
  /* Whatever survived the refusal folds to an ASCII letter or to nothing at
     all, so the counterparts are that letter and its upper case: the first two
     steps of the general walk, and the only two this build can take. */
  uint32_t alt[2];
  int n = 0;
  uint32_t f = mrb_re_case_fold(cp);
  if (f != cp) { alt[n++] = f; alt[n++] = f - 32; }
#endif
  if (n == 0) return FALSE;
  mrb_bool found;
  uint16_t id = literal_class(c, cp, &found);
  if (!found) {
    class_add_codepoint(c, &c->pat->classes[id], cp);
    for (int i = 0; i < n; i++) {
      class_add_member(c, &c->pat->classes[id], alt[i], FALSE);
    }
  }
  emit(c, RE_CLASS, (uint8_t)id, 0);
  return TRUE;
}

/* The same for a character the pattern spells out, whose bytes the caller is
   partway through: the codepoint comes from the pattern, and the bytes it took
   are consumed only once the class is emitted.

   A byte that starts no whole character is not a character to fold. It decodes
   as one byte and hands back its own value, which would read a lone 0xB5 as
   U+00B5 and answer /i for a character the pattern does not hold, so it falls
   back to the bytes like every other invalid sequence in the literal path.

   A byte-indexed pattern holds no character to fold either, whatever its bytes
   would spell: emit_escaped_byte() reads `\xC2\xB5` there as two bytes, and
   the raw spelling of the same two bytes says the same thing. */
static mrb_bool
emit_char_folded(re_compiler *c, int ch)
{
  if (ch < 128 || !(c->flags & RE_FLAG_IGNORECASE) || c->binary) return FALSE;
  int len = 0;
  uint32_t cp = mrb_re_decode_char(c->p - 1, c->src_end, &len, FALSE);
  if (len == 1) return FALSE;
  if (!emit_cp_folded(c, cp)) return FALSE;
  c->p += len - 1;
  return TRUE;
}

/* Emit one codepoint as an atom: a run of RE_CHAR, one per UTF-8 byte. This is
   emit_char_bytes() for a codepoint the pattern names rather than spells, so
   the bytes come from the encoder instead of from the pattern. The run has to
   be a single atom just the same, or a following quantifier binds to the last
   byte alone. Naming a character does not change what /i does with it, so the
   folded spelling is tried first, as it is for a character the pattern
   spells. */
static void
emit_codepoint(re_compiler *c, uint32_t cp)
{
  if (cp < 128) {
    emit_char(c, (uint8_t)cp);
    return;
  }
  char buf[4];
  int len = (int)mrb_utf8_to_buf(buf, (mrb_int)cp);
  /* Fold only a spelling the engine reads back as the one character it spells.
     What the fold emits is a class, and a class compares one decoded
     character; where the build decodes bytes it never sees this one, so the
     class would answer for a lone byte of the same number rather than for the
     character the pattern names. The bytes below name it on either build,
     which is the fallback a character the pattern spells already takes there,
     through the length emit_char_folded() reads. */
  if ((c->flags & RE_FLAG_IGNORECASE) &&
      mrb_re_charlen(buf, buf + len, FALSE) == len &&
      emit_cp_folded(c, cp)) {
    return;
  }
  for (int i = 0; i < len; i++) {
    emit(c, RE_CHAR, (uint8_t)buf[i], 0);
  }
}

/* Largest number a \k<n> / \k<-n> backreference may spell. The bound is far
   above RE_MAX_CAPTURES because it is not a capacity: it separates two of
   CRuby's messages, `too big number` for a number past it and `invalid backref
   number/name` for one within it that names no group. */
#define RE_MAX_BACKREF_NUM 2147483647

/* A \g reference the parse could not finish resolving: a name, which has to
   wait for the definitions still to come, or a number past the groups open so
   far, which CRuby takes when the pattern goes on to open enough. The
   RE_CALL emitted for one carries RE_CALL_PENDING in `a` and this record's
   index in `offset` until resolve_calls() rewrites it; RE_MAX_CAPTURES is 32,
   so no resolved group ever wears the sentinel. What the record points into
   is c->src, which outlives the parse, so a name is an offset and a length
   rather than a copy. */
#define RE_CALL_PENDING 255

enum re_pending_kind {
  RE_PENDING_NAME,  /* resolved against the named-capture table */
  RE_PENDING_NUM    /* already a group number; checked against the count */
};

typedef struct {
  uint32_t src_off;   /* where the name, or the number's digits, start */
  uint32_t len;
  uint32_t resolved;  /* the group number it spelled (RE_PENDING_NUM) or the
                         name resolved to (filled in by resolve_calls()) */
  uint8_t kind;
} re_pending_call;

/* Park one reference. The records live in a String rather than a buffer this
   frame owns, because the parse raises through longjmp and a raise must not
   strand them: the GC arena holds the String for the length of the compile
   and no longer, which is exactly the records' life. The count is bounded by
   the instructions emitted, so it fits the uint16_t field that carries it. */
static uint16_t
add_pending_call(re_compiler *c, uint8_t kind, const char *at, uint32_t len,
                 uint32_t resolved)
{
  re_pending_call rec;
  if (mrb_nil_p(c->pending_calls)) {
    c->pending_calls = mrb_str_new(c->mrb, NULL, 0);
  }
  rec.src_off = (uint32_t)(at - c->src);
  rec.len = len;
  rec.resolved = resolved;
  rec.kind = kind;
  mrb_str_cat(c->mrb, c->pending_calls, (const char*)&rec, sizeof(rec));
  return c->num_pending++;
}

/* Read the group a reference names, `<name>` or `'name'` with the parse
   point on the opening delimiter, and answer its number. This is what
   `\k` reads after its letter and what a conditional reads inside its
   parentheses, and the two agree on every spelling: a name looks up the
   first group defined under it so far, digits are an absolute number a
   group written later may still satisfy, `-n` counts back over the groups
   already open, and a nest level is refused. A number that names no group
   is caught by mrb_re_compile() once the whole pattern is read; see
   `max_backref`.

   A name the pattern has given to several groups answers the first of them,
   which is the group a conditional tests, and `set` collects all of them,
   one bit per group number, for the backreference that reads them all (see
   emit_multi_backref()). A caller with no use for the set passes NULL, and
   the numeric spellings leave it empty: those name one group, which the
   answer carries, and the group a forward `\k<n>` names is not open yet. */
static int
parse_group_ref(re_compiler *c, uint32_t *set)
{
  if (set) *set = 0;
  int close = (peek(c) == '<') ? '>' : '\'';
  next_char(c);  /* skip < or ' */
  const char *name = c->p;
  while (peek(c) != close && peek(c) >= 0) {
    /* The reference reads a name the same way a definition does, and stops
       at a ')' the same way too, from the second byte on: \k<)> reaches the
       group (?<)>x) opened, while \k<a)b> is `invalid group name`. */
    if (peek(c) == ')' && c->p > name) {
      compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                      name, (size_t)(c->src_end - name)));
    }
    next_char(c);
  }
  /* The end of the pattern ends the name the way a ')' does; see the
     definition side for the pair. */
  if (c->p == name) compile_error(c, "group name is empty");
  /* A pattern that ends inside the name never closed it, so what was read
     is not a name to look up: it is quoted back as the malformed one it
     is. This comes before the level check below because an unclosed name
     is not a level either. */
  if (peek(c) != close) {
    compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                    name, (size_t)(c->p - name)));
  }
  uint32_t name_len = (uint32_t)(c->p - name);

  /* A `+` or `-` past the first byte ends a \k name and opens a nest
     level: `\k<name+n>` reads the group as the enclosing recursion left
     it n levels up, which is a feature of the subexpression calls this
     engine refuses (see `\g` below), so the reference is refused with it.
     The first byte is exempt because that is where the relative form's
     sign stands: `\k<-1>` is the group one back, and `\k<-1-1>` is that
     group at a level. Reading the sign as part of the name instead let a
     reference reach a group CRuby's own numbering puts out of reach, since
     a definition takes the sign into the name where a reference never
     does: `(?<a-1>x)\k<a-1>` matched here and is `undefined name <a>`
     there. Only digits stand behind the sign, so a level CRuby itself
     refuses is a malformed name here as it is there, `\k<a+>` and
     `\k<a+1x>` reaching the message the rest of this arm gives one. The
     name is quoted as it was read; CRuby quotes it to the end of the
     pattern instead, the way it does for every name its own scan ended.
     The whole check comes before the length one below because the sign is
     where the name ends, so a name long enough to fail that one is a
     level first. */
  uint32_t sign = 1;
  while (sign < name_len && name[sign] != '+' && name[sign] != '-') sign++;
  if (sign < name_len) {
    mrb_bool numeric = (sign + 1 < name_len);
    for (uint32_t i = sign + 1; numeric && i < name_len; i++) {
      if (name[i] < '0' || name[i] > '9') numeric = FALSE;
    }
    if (numeric) compile_error(c, "backreference with nest level is not supported");
    compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                    name, (size_t)name_len));
  }

  if (!RE_NAME_LEN_FITS(name_len)) compile_error(c, "group name too long");
  next_char(c);  /* skip the closing > or ' */

  int group = -1;
  if (name_len > 0 && (name[0] == '-' || (name[0] >= '0' && name[0] <= '9'))) {
    mrb_bool relative = (name[0] == '-');
    uint32_t first = relative ? 1 : 0;

    /* CRuby reads the whole name before converting it, so a name that is
       not `-`? followed by digits is a malformed name whatever the digits
       it does hold would come to: \k<99999999999999999999x> is `invalid
       group name`, not `too big number`. A lone `-` is malformed too. */
    mrb_bool numeric = (first < name_len);
    for (uint32_t i = first; numeric && i < name_len; i++) {
      if (name[i] < '0' || name[i] > '9') numeric = FALSE;
    }

    int n = 0;
    for (uint32_t i = first; numeric && i < name_len; i++) {
      int digit = name[i] - '0';
      /* CRuby's scanner stops at RE_MAX_BACKREF_NUM, and a number past it
         is too big rather than a reference to a group that is missing. */
      if (n > (RE_MAX_BACKREF_NUM - digit) / 10) compile_error(c, "too big number");
      n = n * 10 + digit;
    }
    /* n == 0 names group 0, the whole match, which \k cannot reference */
    if (!numeric || n == 0) {
      compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                      name, (size_t)name_len));
    }

    if (relative) {
      /* `\k<-n>` counts back from where it stands, so the groups it can
         name are the ones already open; Onigmo resolves it the same way
         (BACKREF_REL_TO_ABS) and refuses a relative forward reference.
         The count is `num_groups` rather than `num_captures` because the
         groups a named pattern demotes still count here, as they do
         everywhere else the parse numbers a group; where nothing is
         demoted the two agree, `num_groups` standing one below
         `num_captures`, which counts group 0. The resolution comes before
         the refusal below because CRuby reaches that refusal only once
         the reference has resolved to a group the pattern has:
         `(?<n>a)\k<-1>` is refused for being numbered, `(?<n>a)\k<-2>`
         is out of range instead. */
      group = (int)c->num_groups + 1 - n;
      if (group < 1) compile_error(c, "invalid backref number/name");
    }

    /* CRuby rejects a numbered backreference in a named pattern whatever
       its spelling, and it has to be rejected here too: once plain groups
       stop consuming numbers, the check after the parse, which counts the
       demoted groups, would silently accept a number naming a group that
       no longer carries it. */
    if (c->dont_capture) {
      compile_error(c, "numbered backref/call is not allowed. (use name)");
    }

    if (!relative) {
      /* The absolute form may name a group written later, `\k<1>(a)`
         being as valid in CRuby as `\1(a)` is, so the number is only
         recorded here and mrb_re_compile() checks it against the
         pattern's group count once the parse is done. A number above
         RE_MAX_CAPTURES names no group whatever the pattern goes on to
         open, and is kept at that bound so the check still refuses it
         while the number stays one a group field can hold. */
      if (n > RE_MAX_CAPTURES) n = RE_MAX_CAPTURES;
      if (n > (int)c->max_backref) c->max_backref = (uint16_t)n;
      group = n;
    }
  }
  else {
    for (uint16_t i = 0; i < c->num_named; i++) {
      if (c->pat->named_captures[i].name_len == name_len &&
          memcmp(c->pat->named_captures[i].name, name, name_len) == 0) {
        uint16_t g = c->pat->named_captures[i].group;
        if (group < 0) group = g;
        if (set) *set |= (uint32_t)1 << g;
      }
    }
    if (group < 1) {
      compile_error_str(c, mrb_format(c->mrb, "undefined name <%l> reference",
                                      name, (size_t)name_len));
    }
  }
  return group;
}

/* Open a nesting level; see re_level for what one is. The count is what
   MRB_REGEXP_PARSE_DEPTH_LIMIT bounds, and the limit is met here rather than
   at the bottom of a recursion: a pattern past it is refused at the level
   that crosses it, having cost the levels below it and nothing more. */
static re_level*
open_level(re_compiler *c, uint8_t kind, uint32_t begin, uint32_t outer_atom_start)
{
  if (c->depth >= (uint32_t)MRB_REGEXP_PARSE_DEPTH_LIMIT) {
    compile_error(c, "parse depth limit over");
  }
  if (c->level_count == c->level_capa) {
    /* Outgrown: the levels move to a String the GC arena holds for the
       compile, as pending_calls is held (see re_compiler), and double from
       there. An allocation the allocator refuses is mrb_realloc()'s
       NoMemoryError, which is the answer a pattern nested past what the
       machine holds gets, at whatever depth that is. */
    uint32_t capa = c->level_capa * 2;
    size_t bytes = sizeof(re_level) * capa;
    if (mrb_nil_p(c->level_store)) {
      c->level_store = mrb_str_new(c->mrb, NULL, bytes);
      memcpy(RSTRING_PTR(c->level_store), c->levels, sizeof(re_level) * c->level_count);
    }
    else {
      mrb_str_resize(c->mrb, c->level_store, (mrb_int)bytes);
    }
    c->levels = (re_level*)RSTRING_PTR(c->level_store);
    c->level_capa = capa;
  }
  c->depth++;
  re_level *lv = &c->levels[c->level_count++];
  memset(lv, 0, sizeof(*lv));
  lv->kind = kind;
  lv->flags = c->flags;
  lv->begin = begin;
  lv->atom_start = outer_atom_start;
  lv->alt_start = c->code_len;
  return lv;
}

/* Open the level a '(' begins, the '(' itself just consumed: read the
   prefix that says which construct it is, emit what the construct puts
   before its body, and push the level the body is read in. The body is
   then read by compile_levels() as the sequence it stands in, and
   close_level() emits what follows it. `begin` and `outer_atom_start`
   are what the enclosing sequence needs back when the level closes; see
   re_level. */
static void
open_group(re_compiler *c, uint32_t begin, uint32_t outer_atom_start)
{
  mrb_bool capturing = TRUE;
  const char *cap_name = NULL;
  uint32_t cap_name_len = 0;

  /* `(?` and nothing more: the prefix that names which group this is
     runs off the end of the pattern. It is reported here because what
     the parser would otherwise be left with is a `?` standing where no
     atom is, which compile_levels() reads as a quantifier with nothing to
     repeat. */
  if (peek(c) == '?' && c->p + 1 >= c->src_end) {
    compile_error(c, "end pattern in group");
  }

  if (peek(c) == '?' && c->p + 1 < c->src_end) {
    if (c->p[1] == ':') {
      next_char(c); next_char(c);  /* skip ?: */
      capturing = FALSE;
    }
    else if (c->p[1] == '=' || c->p[1] == '!') {
      /* lookahead (?=...) or (?!...) */
      mrb_bool negative = (c->p[1] == '!');
      next_char(c); next_char(c);  /* skip ?= or ?! */
      uint32_t la_pos = emit(c, negative ? RE_NEG_LOOKAHEAD : RE_LOOKAHEAD, 0, 0);
      re_level *lv = open_level(c, RE_LEVEL_LOOKAHEAD, begin, outer_atom_start);
      lv->state = negative;
      lv->num = (uint16_t)++c->num_cuts;
      lv->head = la_pos;
      return;
    }
    else if (c->p[1] == '<' && c->p + 2 < c->src_end && (c->p[2] == '=' || c->p[2] == '!')) {
      /* lookbehind (?<=...) or (?<!...) */
      mrb_bool negative = (c->p[2] == '!');
      next_char(c); next_char(c); next_char(c);  /* skip ?<= or ?<! */
      uint32_t lb_pos = emit(c, negative ? RE_NEG_LOOKBEHIND : RE_LOOKBEHIND, 0, 0);
      c->alt_count = 0;  /* the record is this body's own; see there */
      re_level *lv = open_level(c, RE_LEVEL_LOOKBEHIND, begin, outer_atom_start);
      lv->state = negative;
      lv->num = (uint16_t)++c->num_cuts;
      lv->head = lb_pos;
      lv->aux = lv->alt_start;  /* where the body's code begins */
      return;
    }
    else if (c->p[1] == '>') {
      /* atomic group (?>...): the body is a non-capturing group whose
         first match is its only one. The two instructions bracketing it
         carry a number of the group's own, which is how the executor
         pairs the end of a body with the group it closes when a failure
         after the body has to fail the group; see bt_match(). The number
         is the count of groups numbered before it rather than the
         nesting depth: a possessive repeat wraps a group around code
         already emitted, and with depths that wrapper and a group inside
         it, compiled with the same groups open around them, shared a
         depth, so a cut of the wrapper was read as the inner group's.
         Every numbered group emits two instructions, so the number fits
         the field. */
      next_char(c); next_char(c);  /* skip ?> */
      uint16_t cut = (uint16_t)++c->num_cuts;
      emit(c, RE_ATOMIC, 0, cut);
      re_level *lv = open_level(c, RE_LEVEL_ATOMIC, begin, outer_atom_start);
      lv->num = cut;
      return;
    }
    else if (c->p[1] == '~') {
      /* The absent repeater (?~e): the longest run of text from here
         that holds no match of e. The body is no part of the match, it
         is run at one position after another to say where the run has
         to stop, so the three instructions are a scan rather than a
         sub-pattern the search passes through, and RE_ABSENT is its
         head. `offset` on that head is the text after the group, which
         is patched in once the body is compiled, as a lookaround's is.

         CRuby's syntax has no absent expression (?~|absent|exp) or
         absent stopper (?~|absent): a `|` here opens an alternative of
         the body like any other, so (?~|a|b) is this repeater over
         `|a|b`, which matches empty everywhere and leaves the absent
         with nothing it can reach. That is CRuby's answer too. */
      next_char(c); next_char(c);  /* skip ?~ */
      emit(c, RE_ABSENT_START, 0, 0);
      uint32_t head = emit(c, RE_ABSENT, 0, 0);
      re_level *lv = open_level(c, RE_LEVEL_ABSENT, begin, outer_atom_start);
      lv->head = head;
      return;
    }
    else if (c->p[1] == '\'' ||
             (c->p[1] == '<' && c->p + 2 < c->src_end &&
              c->p[2] != '=' && c->p[2] != '!')) {
      /* A named capture, in either spelling: (?<name>...) or (?'name'...).
         The quoted one needs none of the ruling out the angled one does
         above, since no lookbehind is spelled with a quote. The name runs
         to its own terminator, so a '>' inside quotes and a quote inside
         angles are both members of the name. */
      int close = (c->p[1] == '<') ? '>' : '\'';
      next_char(c); next_char(c);  /* skip ?< or ?' */
      cap_name = c->p;
      while (peek(c) != close && peek(c) >= 0) {
        /* CRuby's fetch_name() ends the scan at a ')' instead of taking it
           into the name, and a name no delimiter ended is `invalid group
           name`. The first byte is exempt, the test starting one byte
           in, so (?<)>x) names ")" in both engines. The message quotes
           to the end of the pattern, as CRuby does when the scan never
           reached a delimiter. */
        if (peek(c) == ')' && c->p > cap_name) {
          compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                          cap_name, (size_t)(c->src_end - cap_name)));
        }
        next_char(c);
      }
      /* A name the pattern ends before the delimiter of is the same
         `invalid group name` as one a ')' ended, quoted the same way,
         and an empty one is empty whether or not it was ever closed:
         (?'  and (?<>x) answer alike, as they do in CRuby. */
      if (c->p == cap_name) compile_error(c, "group name is empty");
      if (peek(c) != close) {
        compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                        cap_name, (size_t)(c->p - cap_name)));
      }
      /* A definition names a group, it never numbers one: CRuby reads a
         leading digit or '-' as the number spelling, which only a
         reference may use, and refuses it here. Everything after the first
         byte is a name to both engines, `-` and spaces included, so this
         is not a restriction to word characters. Without it, (?<1>x)
         defined a group that no \k could reach, the reference side
         reading digits as a number. */
      if (*cap_name == '-' || (*cap_name >= '0' && *cap_name <= '9')) {
        compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                        cap_name, (size_t)(c->p - cap_name)));
      }
      if (!RE_NAME_LEN_FITS(c->p - cap_name)) compile_error(c, "group name too long");
      cap_name_len = (uint32_t)(c->p - cap_name);
      next_char(c);  /* skip the closing > or ' */
    }
    else if (c->p[1] == 'i' || c->p[1] == 'm' || c->p[1] == 'x' || c->p[1] == '-') {
      /* Inline options: the toggle form (?imx) / (?-imx) changes the
         options for the rest of the enclosing group, and the scoped
         form (?imx:...) is a non-capturing group whose options apply
         only to its body. */
      next_char(c);  /* skip '?' */
      uint32_t new_flags = parse_inline_flags(c, c->flags);
      if (peek(c) == ')') {
        /* The rest of the enclosing group, alternatives and all, is the
           toggle's scope: `a(?i)b|c` is `a(?i:b|c)`, as Onigmo builds it
           (parse_exp() hands its "option only" remainder to
           parse_subexp(), the alternation level). So compile that
           remainder here rather than returning to the sequence the
           toggle was read in, where the `|` would split at the level the
           toggle was written at and `c` would match with no `a` before
           it. The level takes every `|` and closes at the group's ')' or
           the end of the pattern, consuming neither, which is where the
           enclosing level expects the parse point, so what follows is
           unchanged: that level finds its terminator, a stray ')' at top
           level is still refused by mrb_re_compile(), and a quantifier
           with nothing before it is refused inside the level. */
        next_char(c);
        open_level(c, RE_LEVEL_TOGGLE, begin, outer_atom_start);
        c->flags = new_flags;
        return;
      }
      else if (peek(c) == ':') {
        next_char(c);
        open_level(c, RE_LEVEL_OPTION, begin, outer_atom_start);
        c->flags = new_flags;
        return;
      }
      else {
        if (peek(c) < 0) compile_error(c, "end pattern in group");
        compile_error(c, "undefined group option");
      }
    }
    else if (c->p[1] == '(') {
      /* The conditional (?(cond)yes|no): `yes` where the group `cond`
         names has matched, `no` where it has not, and `no` is empty
         where it is left out. The condition is a group reference in the
         spellings a backreference takes, `(1)`, `(<name>)` and
         `('name')`, and a group has matched when its capture pair is
         closed: one still open, the conditional standing inside it, has
         not, and neither has one a repetition has just re-entered (see
         RE_SAVE in bt_match()). That is Onigmo's reading too.

         The number form is read here rather than by parse_group_ref():
         the digits run to the ')' with no delimiter of their own, and
         CRuby refuses the sign that gives the relative forms, so what is
         read is digits or a malformed name. Every check the absolute
         form makes there is made here in the same order, the count
         check coming after the parse as it does for `\1(a)`, so
         `(?(1)b|c)(a)` is as valid as that is. A named pattern refuses
         the number as it refuses `\1`.

         Two branches at most: a third `|` is `invalid conditional
         pattern`, as in CRuby, so the level reads the `|` between the
         bodies itself, where any other level reads every `|` as a branch
         of its alternation; see compile_levels(). The bodies nest a level
         as a group's would, and count as one.

         One instruction carries the test and the layout is a fork's
         with the choice made by the captures instead of pushed: RE_COND
         goes on at pc + 1 where the group has matched and at `offset`
         where it has not, `yes` ends with a jump past `no`, and with no
         `no` the head's offset is the text after the group. */
      next_char(c); next_char(c);  /* skip ?( */
      int group = 0;
      int cond = peek(c);
      if (cond < 0) {
        /* `(?(` and nothing more: CRuby answers for the prefix, not for
           the condition it never began. */
        compile_error(c, "undefined group option");
      }
      if (cond == '<' || cond == '\'') {
        /* A name given to several groups tests the first of them, as in
           CRuby: `(?<x>a)?(?<x>b)(?(<x>)y|z)` reads `z` against "b", the
           group that matched not being the one the condition names. That
           is where the condition parts from the backreference, which
           reads every group of the name. */
        group = parse_group_ref(c, NULL);
        /* A name closed by its delimiter and then something other than
           the ')': CRuby's answer is the prefix's, as above. */
        if (peek(c) != ')') compile_error(c, "undefined group option");
      }
      else if (cond >= '0' && cond <= '9') {
        const char *digits = c->p;
        while (peek(c) != ')' && peek(c) >= 0) next_char(c);
        uint32_t dlen = (uint32_t)(c->p - digits);
        mrb_bool numeric = TRUE;
        for (uint32_t i = 0; numeric && i < dlen; i++) {
          if (digits[i] < '0' || digits[i] > '9') numeric = FALSE;
        }
        /* A condition the pattern ends inside is quoted back the way a
           name the pattern ends inside is, and so is one that is not
           all digits, as in parse_group_ref(). */
        if (!numeric || peek(c) < 0) {
          compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                          digits, (size_t)dlen));
        }
        int n = 0;
        for (uint32_t i = 0; i < dlen; i++) {
          int digit = digits[i] - '0';
          if (n > (RE_MAX_BACKREF_NUM - digit) / 10) compile_error(c, "too big number");
          n = n * 10 + digit;
        }
        /* Group 0 is the whole match, which is never closed while the
           pattern runs, and CRuby refuses it as it refuses `\k<0>`. */
        if (n == 0) {
          compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                          digits, (size_t)dlen));
        }
        if (c->dont_capture) {
          compile_error(c, "numbered backref/call is not allowed. (use name)");
        }
        if (n > RE_MAX_CAPTURES) n = RE_MAX_CAPTURES;
        if (n > (int)c->max_backref) c->max_backref = (uint16_t)n;
        group = n;
      }
      else {
        /* Anything else in the condition's place, a bare name, a signed
           number, nothing at all: CRuby refuses the condition rather
           than reading it as a name. */
        compile_error(c, "invalid conditional pattern");
      }
      next_char(c);  /* skip the ')' closing the condition */

      uint32_t head = emit(c, RE_COND, (uint8_t)group, 0);
      re_level *lv = open_level(c, RE_LEVEL_COND, begin, outer_atom_start);
      lv->head = head;
      return;
    }
    else if (c->p[1] == '#') {
      /* preprocess_pattern() removes a terminated comment group before
         the parser runs, so one reaching here was never closed, which
         is the pattern ending inside the prefix like any other. */
      compile_error(c, "end pattern in group");
    }
    else {
      /* (?X) with an unsupported X: not one of the recognized (?: (?= (?!
         (?<= (?<! (?<name> (?'name' (?> (?~ (?( (?imx forms. Comment
         groups (?#...) never get here either, having been removed by
         preprocess_pattern(). Raise here rather than falling through to
         the capturing-group path, which would leave the stray `?` for
         compile_levels() to spin on forever (A1). */
      if (c->p[1] == '<') {
        /* `(?<` and nothing more, the only way a '<' reaches here: the
           pattern ends before the character that tells a lookbehind
           from a named group. CRuby answers for the group that never
           closes rather than for the prefix, which either reading
           leaves open. */
        compile_error(c, "end pattern with unmatched parenthesis");
      }
      compile_error(c, "undefined group option");
    }
  }

  /* Onigmo's ONIG_OPTION_DONT_CAPTURE_GROUP, which CRuby turns on for a
     pattern that declares a named group: a plain (...) then groups
     without capturing, so the numbered side counts only the named
     groups. The named group itself keeps its number. The count of groups
     opened is taken before that demotion: CRuby demotes plain groups
     only once the parse is done, so while it reads the pattern every one
     of them is still a group that a `\NN` may refer to. */
  if (capturing && c->num_groups < UINT16_MAX) c->num_groups++;
  if (c->dont_capture && cap_name == NULL) capturing = FALSE;

  uint16_t group = 0;
  if (capturing) {
    if (c->num_captures >= RE_MAX_CAPTURES) {
      compile_error(c, "too many capture groups are specified");
    }
    group = c->num_captures++;
    emit(c, RE_SAVE, 0, group * 2);
    if (cap_name) {
      /* register named capture */
      c->pat->named_captures = (re_named_capture*)mrb_realloc(c->mrb, c->pat->named_captures,
        sizeof(re_named_capture) * (c->num_named + 1));
      c->pat->named_captures[c->num_named].name = cap_name;
      c->pat->named_captures[c->num_named].name_len = cap_name_len;
      c->pat->named_captures[c->num_named].group = group;
      c->num_named++;
    }
  }

  re_level *lv = open_level(c, RE_LEVEL_GROUP, begin, outer_atom_start);
  lv->state = capturing;
  lv->num = group;
}

/* Emit the backreference to a name the pattern has given to several groups:
   `set` holds them, one bit per group number, and the reference matches
   where any of them does. CRuby reads such a name that way and this engine
   used to read one group of it, so a subject only another group could vouch
   for did not match.

   The groups are tried from the last defined to the first, which is the
   order CRuby takes them in: `(?<x>ab)(?<x>a)\k<x>` matches "abaa" rather
   than the "abaab" the first group would reach. A group that took no part
   in the match holds no text and matches nothing, so it falls through to
   the next like a group whose text is not there; where none of them
   matches, the whole reference fails, as `(?:(?<x>a))?\k<x>` does against
   "".

   The first group that matches is the one the reference takes, and a
   failure after it does not come back for another: CRuby refuses
   `\A(?<x>a)(?<x>ab)\k<x>b\z` against "aabab", where taking "a" instead of
   "ab" would have matched. That is what the atomic group around the
   alternatives says, and it is why this is not the plain alternation the
   same groups would spell. */
static void
emit_multi_backref(re_compiler *c, uint32_t set, uint8_t fold)
{
  uint32_t taken[RE_MAX_CAPTURES];  /* the arms' jumps to the join point */
  uint32_t num_taken = 0;
  uint16_t cut = (uint16_t)++c->num_cuts;

  emit(c, RE_ATOMIC, 0, cut);
  for (int g = RE_MAX_CAPTURES - 1; g > 0; g--) {
    if (!((set >> g) & 1)) continue;
    set &= ~((uint32_t)1 << g);
    if (set == 0) {
      /* The last arm: nothing follows it to fall through to, so it fails
         the reference itself rather than forking first. */
      emit(c, RE_BACKREF, (uint8_t)g, fold);
      break;
    }
    uint32_t fork = emit(c, RE_SPLIT, 0, 0);
    emit(c, RE_BACKREF, (uint8_t)g, fold);
    taken[num_taken++] = emit(c, RE_JMP, 0, 0);
    patch(c, fork, (uint16_t)c->code_len);
  }
  for (uint32_t i = 0; i < num_taken; i++) {
    patch(c, taken[i], (uint16_t)c->code_len);
  }
  emit(c, RE_ATOMIC_END, 0, cut);
  c->needs_backtrack = TRUE;  /* the Pike VM cannot cut a thread */
}

/* Compile a single atom (character, class, anchor, escape). Returns whether
   one was read: FALSE when what stands at the parse point is not an atom,
   either a quantifier metacharacter or the end of the sequence, neither of
   them consumed. A '(' is not read here: it opens a level, which is
   compile_levels()'s to push, through open_group(). */
static mrb_bool
compile_atom(re_compiler *c)
{
  int ch = peek(c);

  switch (ch) {

  case '[':
    next_char(c);
    compile_charclass(c);
    break;

  case '.':
    next_char(c);
    emit(c, (c->flags & RE_FLAG_DOTALL) ? RE_ANY_NL : RE_ANY, 0, 0);
    break;

  case '^':
    next_char(c);
    emit(c, RE_BOL, 0, 0);
    break;

  case '$':
    next_char(c);
    emit(c, RE_EOL, 0, 0);
    break;

  case '\\':
    next_char(c);
    ch = peek(c);
    if (ch >= '1' && ch <= '9') {
      /* A digit run after the backslash is read as one decimal number first,
         and is a backreference when that number is at most 9 or at most the
         number of groups opened so far, as in CRuby (Onigmo's fetch_token):
         `\1` and `\12` after twelve groups refer back, `\12` before them is
         octal 012, a newline. What is not a backreference is an octal escape
         of up to three digits (`\101` is `A`, `\1234` is `S4`), or the digit
         itself when it starts with 8 or 9 (`\81` is `81`). Only the
         comparison with the group count needs the number, so accumulation
         stops once it is past every count a pattern can reach. */
      uint32_t num = 0;
      const char *q = c->p;
      while (q < c->src_end && *q >= '0' && *q <= '9') {
        if (num <= UINT16_MAX) num = num * 10 + (uint32_t)(*q - '0');
        q++;
      }
      if (num <= 9 || num <= c->num_groups) {
        if (c->dont_capture) {
          compile_error(c, "numbered backref/call is not allowed. (use name)");
        }
        /* Not dont_capture, so every group counted captures and num is
           within RE_MAX_CAPTURES. */
        c->p = q;
        emit(c, RE_BACKREF, (uint8_t)num, (c->flags & RE_FLAG_IGNORECASE) ? 1 : 0);
        c->has_backref = TRUE;
        if (num > c->max_backref) c->max_backref = (uint16_t)num;
      }
      else {
        /* parse_escape() reads `\1`-`\7` as octal and `\8`, `\9` as the
           digit itself, its default for a byte with no escape meaning. */
        emit_char(c, (uint8_t)parse_escape(c));
      }
    }
    else if (ch == 'd' || ch == 'D' || ch == 'w' || ch == 'W' || ch == 's' || ch == 'S') {
      next_char(c);
      uint16_t id = add_class(c);
      class_add_shorthand(&c->pat->classes[id], ch);
      /* class_add_shorthand already builds the complemented set for the
         uppercase forms (\D, \W, \S include utf8_any), so always emit
         RE_CLASS. Emitting RE_NCLASS here would negate a second time and
         make \D/\W/\S behave like \d/\w/\s (issue: negated shorthands). */
      emit(c, RE_CLASS, (uint8_t)id, 0);
    }
    else if (ch == 'h' || ch == 'H') {
      /* \h / \H both carry their full positive set (hex digits /
         non-hex-digits), so emit RE_CLASS for both rather than routing
         \H through an RE_NCLASS path that would double-negate. */
      next_char(c);
      uint16_t id = add_class(c);
      class_add_shorthand(&c->pat->classes[id], ch);
      emit(c, RE_CLASS, (uint8_t)id, 0);
    }
    else if (ch == 'A') {
      next_char(c);
      emit(c, RE_BOT, 0, 0);
    }
    else if (ch == 'z') {
      next_char(c);
      emit(c, RE_EOT, 0, 0);
    }
    else if (ch == 'Z') {
      next_char(c);
      emit(c, RE_EOTNL, 0, 0);
    }
    else if (ch == 'b') {
      next_char(c);
      emit(c, RE_WBOUND, 0, 0);
    }
    else if (ch == 'B') {
      next_char(c);
      emit(c, RE_NWBOUND, 0, 0);
    }
    else if (ch == 'k' && c->p + 1 < c->src_end &&
             (c->p[1] == '<' || c->p[1] == '\'')) {
      /* \k<name> / \k'name': backreference to a named group. Numeric forms
         \k<2> (absolute) and \k<-1> (relative to the groups seen so far) are
         also accepted, like the \g/\k family in Onigmo. A name the pattern
         has given to several groups reaches every one of them, which takes
         more than the one instruction; see emit_multi_backref(). */
      next_char(c);  /* skip k */
      uint32_t set;
      int group = parse_group_ref(c, &set);
      uint8_t fold = (c->flags & RE_FLAG_IGNORECASE) ? 1 : 0;
      if (set & (set - 1)) {
        emit_multi_backref(c, set, fold);
      }
      else {
        emit(c, RE_BACKREF, (uint8_t)group, fold);
      }
      c->has_backref = TRUE;
    }
    else if (ch == 'g' && c->p + 1 < c->src_end &&
             (c->p[1] == '<' || c->p[1] == '\'')) {
      /* \g<name> / \g'name': run a group's sub-pattern again, from wherever
         the call stands -- recursion when the call stands inside the group it
         names. The numeric forms follow the \k family: \g<2> is absolute,
         \g<-1> counts back over the groups already open, and \g<+1>, a form
         \k has no use for, counts forward over the groups still to come.
         \g<0> is the whole pattern. The name is read as a definition reads
         one, signs included: there is no nest level on a call, so `\g<a-1>`
         reaches the group `(?<a-1>x)` names, which the sign-cutting \k arm
         above can never reach.

         What is emitted here is one RE_CALL. Where it jumps to is not
         decided now: the group it names may not be written yet, a name may
         turn out to name two groups, and the body it runs has to be given
         its one entry and one exit once the whole pattern is laid out. All
         of that is resolve_calls(), after the parse; a reference it must
         finish resolving is parked in c->pending_calls and the instruction
         carries the parking slot until then. */
      next_char(c);  /* skip g */
      {
        int close = (peek(c) == '<') ? '>' : '\'';
        next_char(c);  /* skip < or ' */
        const char *name = c->p;
        while (peek(c) != close && peek(c) >= 0) {
          /* The scan stops at a ')' from the second byte on, as every name
             scan here does; the message quotes to the end of the pattern,
             as CRuby does when its own scan never reached a delimiter. */
          if (peek(c) == ')' && c->p > name) {
            compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                            name, (size_t)(c->src_end - name)));
          }
          next_char(c);
        }
        /* The end of the pattern ends the name the way a ')' does, and the
           two failures are reported as the \k arm above reports them: a name
           that never began is the empty one whether or not it was closed,
           and one the pattern ends inside is quoted back as the malformed
           name it is. */
        if (c->p == name) compile_error(c, "group name is empty");
        if (peek(c) != close) {
          compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                          name, (size_t)(c->p - name)));
        }
        uint32_t name_len = (uint32_t)(c->p - name);
        if (!RE_NAME_LEN_FITS(name_len)) compile_error(c, "group name too long");
        next_char(c);  /* skip the closing > or ' */

        int group = -1;
        uint16_t pend = 0;
        mrb_bool pended = FALSE;
        if (name[0] == '-' || name[0] == '+' ||
            (name[0] >= '0' && name[0] <= '9')) {
          mrb_bool back = (name[0] == '-');
          uint32_t first = (back || name[0] == '+') ? 1 : 0;

          /* As at \k: the whole name is read before it is converted, and a
             lone sign is malformed. The message is CRuby's own for a call,
             which differs from the one its backreferences get. */
          mrb_bool numeric = (first < name_len);
          for (uint32_t i = first; numeric && i < name_len; i++) {
            if (name[i] < '0' || name[i] > '9') numeric = FALSE;
          }
          if (!numeric) {
            compile_error_str(c, mrb_format(c->mrb, "invalid char in group name <%l>",
                                            name, (size_t)name_len));
          }

          int n = 0;
          for (uint32_t i = first; i < name_len; i++) {
            int digit = name[i] - '0';
            if (n > (RE_MAX_BACKREF_NUM - digit) / 10) compile_error(c, "too big number");
            n = n * 10 + digit;
          }

          if (n == 0) {
            /* `\g<0>` is the whole pattern, group 0, which even a named
               pattern numbers; a signed zero names no group either way.
               CRuby quotes `-0` as written and `+0` without its sign. */
            if (first) {
              compile_error_str(c, mrb_format(c->mrb, "invalid group name <%l>",
                                              name + (back ? 0 : 1),
                                              (size_t)(name_len - (back ? 0 : 1))));
            }
            group = 0;
          }
          else if (back) {
            /* Backward-relative resolves against the groups already open,
               exactly as \k<-n> does above, and for the same CRuby order:
               the range is checked before a named pattern refuses the
               numbered spelling. */
            group = (int)c->num_groups + 1 - n;
            if (group < 1) compile_error(c, "invalid backref number/name");
            if (c->dont_capture) {
              compile_error(c, "numbered backref/call is not allowed. (use name)");
            }
          }
          else {
            if (c->dont_capture) {
              compile_error(c, "numbered backref/call is not allowed. (use name)");
            }
            /* Forward-relative counts on from the groups already open; the
               absolute form is the number itself. Either may name a group
               written later, so a number past the count so far is checked
               against the whole pattern's count once the parse is done. The
               digits are kept for that check's message, which quotes them
               as written, sign dropped, as CRuby quotes a call's number. */
            group = first ? (int)c->num_groups + n : n;
            if (group > (int)c->num_groups) {
              pend = add_pending_call(c, RE_PENDING_NUM, name + first,
                                      name_len - first, (uint32_t)group);
              pended = TRUE;
            }
          }
        }
        else {
          /* A name resolves once the whole pattern is read: CRuby takes a
             call to a group defined later, and a name two groups carry is
             refused only where a call reads it, so even a name already
             defined here has to wait for the definitions still to come. */
          pend = add_pending_call(c, RE_PENDING_NAME, name, name_len, 0);
          pended = TRUE;
        }

        if (pended) {
          emit(c, RE_CALL, RE_CALL_PENDING, pend);
        }
        else {
          /* group 0, or a group already open: 32 at most, so it fits `a` */
          emit(c, RE_CALL, (uint8_t)group, 0);
        }
        c->has_call = TRUE;
        c->needs_backtrack = TRUE;  /* the Pike VM has no call stack */
      }
    }
    else if (ch == 'G') {
      /* spinel: \G, the position the search started from -- the string
         start for a plain #match, the end of the previous match for a
         scan/gsub step (spinel #3637). Only the backtracking engine keeps
         that position. */
      next_char(c);
      emit(c, RE_GPOS, 0, 0);
      c->needs_backtrack = TRUE;
    }
    else if (ch == 'K') {
      /* spinel: \K, keep: what was matched before it stays out of the
         match, so $& and group 0 begin where it stood and the pre-match
         takes the rest. It records its position in a pair of slots past the
         groups, which a backtrack past it puts back as it does any capture;
         keep_apply() moves the position into group 0 once the match is
         made. Inside a lookaround CRuby's reading of it is not one this
         follows, so it is refused there. */
      for (uint32_t i = 0; i < c->level_count; i++) {
        uint8_t k = c->levels[i].kind;
        if (k == RE_LEVEL_LOOKAHEAD || k == RE_LEVEL_LOOKBEHIND || k == RE_LEVEL_ABSENT)
          compile_error(c, "\\K inside a look-around or an absent operator is not supported");
      }
      next_char(c);
      emit(c, RE_SAVE, 0, RE_KEEP_PENDING);
      c->has_keep = TRUE;
    }
    else if (ch == 'R' || ch == 'X') {
      /* Each of these means something in CRuby that this engine does not do:
         `\R` is any linebreak and `\X` is a whole grapheme cluster. Left to
         the fall-through each was simply its own letter, so /\R/ matched an
         R rather than a newline. Inside a character class CRuby reads them
         as the letter too, which is what the class parser already does, so
         only the escape outside one is refused here. */
      compile_error_str(c, mrb_format(c->mrb, "\\\\%c is not supported", (char)ch));
    }
    else if ((ch == 'p' || ch == 'P') && c->p + 1 < c->src_end && c->p[1] == '{') {
      /* Only the braced spelling is a property: CRuby reads a bare `\p`, and
         `\pL` as well, as the letter, and so does the fall-through below. */
      compile_property(c);
    }
    else if (ch == 'u') {
      next_char(c);  /* skip u */
      mrb_bool more;
      uint32_t cp = unicode_escape_first(c, &more);
      uint32_t nx;
      /* A `\u{...}` list is a sequence of atoms rather than one, so a
         quantifier after it repeats the last codepoint only: /\u{61 62}+/
         is `a` followed by `b+`. Moving atom_start past the codepoints
         already emitted is what leaves the last one as the target. */
      while (unicode_escape_next(c, &more, &nx)) {
        emit_codepoint(c, cp);
        c->atom_start = c->code_len;
        cp = nx;
      }
      emit_codepoint(c, cp);
    }
    else if (ch >= 0xC0) {
      /* A backslash before a multibyte character has no escape meaning: \Ā is
         Ā. parse_escape() returns one byte, which left the continuation bytes
         to the parse loop as atoms of their own, so emit the whole character
         here as the unescaped spelling does. The dispatch has to happen before
         parse_escape() reads the letter, since \xNN and octal \NNN name a byte
         rather than a character. */
      next_char(c);
      if (!emit_char_folded(c, ch)) emit_char_bytes(c, ch);
    }
    else {
      int v = parse_escape(c);
      if (v >= 128) emit_escaped_byte(c, v);
      else emit_char(c, (uint8_t)v);
    }
    break;

  case '{':
    {
      /* `{` opens a repeat only as a valid quantifier, which compile_quantifiers()
         consumes after an atom. Reaching it here means there is no atom to
         repeat: a real quantifier (e.g. {2}) is an error, like CRuby, and
         anything else (e.g. {a}, a lone {) is a literal `{`. parse_quantifier
         consumes the `{...}` on success and restores the position on failure,
         so without this case a literal `{` was never consumed and the
         sequence loop spun forever (issue #6914). */
      next_char(c);  /* consume `{` for the trial parse */
      int qmin, qmax;
      mrb_bool qranged;
      if (parse_quantifier(c, &qmin, &qmax, &qranged)) {
        compile_error(c, "target of repeat operator is not specified");
      }
      emit(c, RE_CHAR, '{', 0);
    }
    break;

  default:
    if (ch < 0 || ch == ')' || ch == '|' || ch == '*' || ch == '+' || ch == '?') {
      return FALSE;  /* not an atom */
    }
    next_char(c);
    if (ch >= 128) {
      if (!emit_char_folded(c, ch)) emit_char_bytes(c, ch);
      break;
    }
    emit_char(c, (uint8_t)ch);
    break;
  }
  return TRUE;
}

/* Append a copy of the atom bytecode in [start, start+size) at the current
   position. Internal code indices are relocated to the copy, so a repeated
   group like (a{2,3}){2} keeps each iteration self-contained instead of
   jumping back into the first copy (which corrupted its captures). A
   lookaround's sub-pattern end is one of those indices: left pointing into
   the original, the copy runs its assertion against the first iteration's
   code and ends the outer match early. Capture slots (RE_SAVE) are shared
   across copies on purpose: a repeated group keeps only its last iteration,
   like CRuby. */
static void
emit_atom_copy(re_compiler *c, uint32_t start, uint32_t size)
{
  int32_t delta = (int32_t)c->code_len - (int32_t)start;
  uint32_t atom_end = start + size;
  for (uint32_t j = 0; j < size; j++) {
    re_inst in = c->pat->code[start + j];
    if (op_holds_code_index(in.op) && in.offset >= start && in.offset <= atom_end) {
      in.offset = (uint16_t)((int32_t)in.offset + delta);
    }
    emit(c, in.op, in.a, in.offset);
  }
}

/* Read the quantifiers that follow a body which matches empty and emit
   nothing for them: `a{0}` and `(?:)` leave no code, and repeating what
   matches empty any number of times still matches empty, so `a{0}*`,
   `a{0}{2}?` and `(?:)+` are the empty match CRuby gives. */
static void
skip_quantifiers(re_compiler *c)
{
  for (;;) {
    skip_extended_space(c);
    int ch = peek(c);
    if (ch == '*' || ch == '+' || ch == '?') {
      next_char(c);
      if (peek(c) == '?') next_char(c);
      continue;
    }
    if (ch == '{') {
      const char *save = c->p;
      int min, max;
      mrb_bool ranged;
      next_char(c);
      if (!parse_quantifier(c, &min, &max, &ranged)) { c->p = save; return; }
      if (peek(c) == '?') next_char(c);
      continue;
    }
    return;
  }
}

/* TRUE for an assertion whose repeated evaluations at one position have no
   observable difference. A capture write would make the repetitions visible,
   and a call may write captures in a body outside this span. */
static mrb_bool
idempotent_assertion(const re_inst *code, uint32_t start, uint32_t end)
{
  if (end == start + 1) {
    switch (code[start].op) {
    case RE_BOL: case RE_EOL: case RE_BOT: case RE_EOT: case RE_EOTNL: case RE_GPOS:
    case RE_WBOUND: case RE_NWBOUND:
      return TRUE;
    default:
      return FALSE;
    }
  }

  switch (code[start].op) {
  case RE_LOOKAHEAD: case RE_NEG_LOOKAHEAD:
  case RE_LOOKBEHIND: case RE_NEG_LOOKBEHIND:
    if (code[start].offset != end) return FALSE;
    break;
  default:
    return FALSE;
  }
  for (uint32_t pc = start + 1; pc < end; pc++) {
    if (code[pc].op == RE_SAVE || code[pc].op == RE_CALL) return FALSE;
  }
  return TRUE;
}

/* Read the quantifiers after an atom, `*`, `+`, `?` and `{n,m}`, and wrap
   the code the atom emitted, from `begin` to the end of the code, in them.
   `start` is where the atom itself begins, which is `begin` except after a
   `\u{...}` list, whose last codepoint alone is the quantifier's; see
   compile_atom(). */
static void
compile_quantifiers(re_compiler *c, uint32_t begin, uint32_t start)
{
  if (c->code_len == begin) {
    /* Nothing emitted. An empty group `(?:)` is an atom all the same, and
       one that matches empty matches empty however it is repeated, so its
       quantifiers are read and emit nothing, as those of `a{0}` are; CRuby
       compiles `(?:)*` the same way. `(?i)*` is refused, as CRuby refuses
       it, but inside the toggle's level, where the `*` stands with no atom
       before it; see compile_levels(). */
    skip_quantifiers(c);
    return;
  }
  mrb_bool assertion = idempotent_assertion(c->pat->code, start, c->code_len);

  /* Under /x the quantifier may stand apart from its atom, `a +` being `a+`.
     A `?` making it non-greedy is read right after it, though, as CRuby
     reads it.

     A quantifier that follows a quantifier binds everything emitted so far
     rather than the atom alone, so the loop below comes round with `start`
     back at `begin`: `a**` is `(?:a*)*` and `a{2}{3}` is `(?:a{2}){3}`. Two
     spellings are read before it comes round, as CRuby reads them:

     - `?` right after `*`, `+`, `?` or a `{n,m}` written with a comma is the
       non-greedy marker. `{n}` has no non-greedy form, so its `?` is a
       quantifier of its own: `a{3}?` is `(?:a{3})?` and matches empty, where
       the lazy `a{3,3}?` does not.
     - `+` right after `*`, `+` or `?` is possessive, `a*+` being `(?>a*)`.
       That is why `a?+` takes one `a` out of "aa" where `(?:a?)+` takes two.
       After a `{...}` it is a quantifier again, `a{2}+` matching "aaaa".

     `greedy_rep` says the last thing read was a greedy `*`, `+` or `?`, which
     is the only place a `+` is possessive: the `+` of `a+` follows the atom,
     the one of `a+?+` follows a lazy repeat, and the one of `a?++` follows a
     possessive, and CRuby reads all three of those as quantifiers. */
  mrb_bool greedy_rep = FALSE;

  for (;;) {
    skip_extended_space(c);
    int ch = peek(c);

    if (greedy_rep && ch == '+') {
      /* Possessive: what stands emitted becomes an atomic group of its own,
         numbered after every group inside it, since those are emitted. */
      next_char(c);
      uint16_t cut = (uint16_t)++c->num_cuts;
      insert_inst(c, begin, RE_ATOMIC, 0, cut);
      emit(c, RE_ATOMIC_END, 0, cut);
      c->needs_backtrack = TRUE;  /* the Pike VM cannot cut a thread */
      greedy_rep = FALSE;
      start = begin;
      continue;
    }

    if (ch == '*' || ch == '+' || ch == '?') {
      next_char(c);
      mrb_bool nongreedy = (peek(c) == '?');
      if (nongreedy) {
        next_char(c);
      }

      /* Repeating a capture-free assertion at one position can only ask the
         same question again. Zero repetitions therefore emit nothing, and a
         positive minimum keeps the one copy already emitted. */
      if (assertion) {
        if (ch != '+') {
          c->code_len = start;
        c->alt_count = 0;  /* the record's positions are gone with the code */
          skip_quantifiers(c);
          return;
        }
        if (!nongreedy && peek(c) == '+') next_char(c);
        greedy_rep = FALSE;
        start = begin;
        continue;
      }
      if (nongreedy) c->needs_backtrack = TRUE;

      if (ch == '*') {
        /* e* -> L: SPLIT(body, end); body; JMP L; end:
           SPLIT offset = end (after JMP), patched after JMP is emitted */
        insert_inst(c, start, nongreedy ? RE_SPLITNG : RE_SPLIT, 0, 0);
        emit(c, RE_JMP, 0, start);
        c->pat->code[start].offset = (uint16_t)c->code_len;  /* patch: skip to end */
      }
      else if (ch == '+') {
        /* e+ -> body; SPLIT/SPLITNG(start)
           SPLIT: first=pc+1(end), second=offset(start) -> non-greedy
           SPLITNG: first=offset(start), second=pc+1(end) -> greedy */
        emit(c, nongreedy ? RE_SPLIT : RE_SPLITNG, 0, start);
      }
      else { /* ? */
        /* e? -> SPLIT(body, end); body; end: */
        insert_inst(c, start, nongreedy ? RE_SPLITNG : RE_SPLIT, 0, 0);
        c->pat->code[start].offset = (uint16_t)c->code_len;  /* patch: skip to end */
      }
      greedy_rep = !nongreedy;
      start = begin;
      continue;
    }

    if (ch != '{') return;

    const char *save = c->p;
    next_char(c);
    int min, max;
    mrb_bool ranged;
    if (!parse_quantifier(c, &min, &max, &ranged)) {
      c->p = save;
      return;  /* not a quantifier */
    }
    /* `{n}` has no non-greedy form, so a `?` after it is a quantifier and the
       loop takes it; `{n,m}` takes it as the marker. */
    mrb_bool nongreedy = (ranged && peek(c) == '?');
    if (nongreedy) {
      next_char(c);
    }
    if (assertion) {
      if (min == 0) {
        c->code_len = start;
        c->alt_count = 0;  /* the record's positions are gone with the code */
        skip_quantifiers(c);
        return;
      }
      greedy_rep = FALSE;
      start = begin;
      continue;
    }
    if (nongreedy) c->needs_backtrack = TRUE;

    /* For {n,m}: repeat atom min times, then optional (max-min) times */
    uint32_t atom_end = c->code_len;
    uint32_t atom_size = atom_end - start;

    if (min == 0 && max == 0) {
      /* {0}: the atom matches zero times. The copy we emitted is dropped --
         except where it defines a capture group. CRuby erases only the
         inline occurrence there: the group stays callable by \g, and \k
         still reads it as a group that never matched rather than one that
         does not exist, so the body is kept behind a jump instead. Nothing
         inline reaches it; a call may. */
      mrb_bool has_group = FALSE;
      for (uint32_t i = start; i < atom_end; i++) {
        if (c->pat->code[i].op == RE_SAVE) { has_group = TRUE; break; }
      }
      if (has_group) {
        insert_inst(c, start, RE_JMP, 0, 0);
        patch(c, start, (uint16_t)c->code_len);
      }
      else {
        c->code_len = start;
        c->alt_count = 0;  /* the record's positions are gone with the code */
      }
    }
    else {
      /* {0,m} and {0,} compile as {1,m}/{1,} wrapped in an optional, so the
         single already-emitted copy is not forced to match. lo is the lower
         bound used while laying out copies (1 in the wrapped case). */
      mrb_bool wrap_optional = (min == 0);
      int lo = wrap_optional ? 1 : min;

      /* We have one copy already; emit lo-1 more mandatory copies. */
      for (int i = 1; i < lo; i++) {
        emit_atom_copy(c, start, atom_size);
      }
      /* Then optional copies */
      if (max < 0) {
        /* {n,} = lo copies + * */
        uint32_t loop_start = c->code_len;
        uint32_t split_pos = emit(c, nongreedy ? RE_SPLITNG : RE_SPLIT, 0, 0);
        emit_atom_copy(c, start, atom_size);
        emit(c, RE_JMP, 0, loop_start);
        patch(c, split_pos, c->code_len);
      }
      else {
        for (int i = lo; i < max; i++) {
          uint32_t split_pos = emit(c, nongreedy ? RE_SPLITNG : RE_SPLIT, 0, 0);
          emit_atom_copy(c, start, atom_size);
          patch(c, split_pos, c->code_len);
        }
      }
      if (wrap_optional) {
        /* Make the whole {1,m}/{1,} body skippable so it matches zero times. */
        insert_inst(c, start, nongreedy ? RE_SPLITNG : RE_SPLIT, 0, 0);
        c->pat->code[start].offset = (uint16_t)c->code_len;
      }
    }
    greedy_rep = FALSE;
    start = begin;
    /* `{0}` left nothing to repeat, and a quantifier over a body that matches
       empty matches empty, so what follows is read and emits nothing. */
    if (c->code_len == begin) {
      skip_quantifiers(c);
      return;
    }
  }
}

/* Mark on the RE_JMP a branch ends with while the alternation it belongs to
   is still open: the target is the code after the last branch, which is not
   known until then. close_alternation() finds the level's branches by these
   marks and clears them. By the time a level closes, every alternation
   inside it has closed, so the marks left are the level's own; none survives
   the parse, and the mark mark_empty_loops() writes on the same field
   afterwards is another matter. */
#define RE_JMP_BRANCH 1

/* Close the alternation of a level that is closing: give its branches the
   SPLIT chain that chooses among them and the exits that rejoin after the
   last, and leave the record the lookbehind arm reads. A level that read no
   `|` has one branch and nothing to do.

   a|b|c lays out as

     SPLIT c; SPLIT b; a; JMP end; b; JMP end; c; end:

   Each SPLIT falls through to the next, and the chain's final fall-through
   reaches the first branch, so the engines (which rank a SPLIT's
   fall-through above its jump) explore branch 0 first. The jump targets are
   then unwound in reverse, so SPLIT i must jump to branch (n - 1 - i) to
   keep the remaining branches in source order, leftmost-first across three
   or more. The chain goes in front of the first branch once the last has
   been read, which is what moves the branches; the exits are found where
   they stand by their marks, in the order the branches were read. */
static void
close_alternation(re_compiler *c, re_level *lv)
{
  if (lv->branches == 0) return;
  uint32_t n = lv->branches + 1;
  uint32_t split_count = n - 1;
  insert_insts(c, lv->alt_start, split_count);
  uint32_t first = lv->alt_start + split_count;  /* where branch 0 now begins */
  uint32_t end = c->code_len;
  uint32_t k = 0;
  for (uint32_t pc = first; pc < end; pc++) {
    re_inst *in = &c->pat->code[pc];
    if (in->op != RE_JMP || in->a != RE_JMP_BRANCH) continue;
    in->a = 0;
    in->offset = (uint16_t)end;
    k++;  /* branch k begins right after the exit of branch k - 1 */
    c->pat->code[first - k].op = RE_SPLIT;
    c->pat->code[first - k].a = 0;
    c->pat->code[first - k].offset = (uint16_t)(pc + 1);
  }
  mrb_assert(k == split_count);

  /* Leave the span where the lookbehind arm can find it; see the record's
     declaration. Nothing moves this code between here and the arm's look at
     it: a lookbehind body ends with the RE_LOOK_END emitted right after
     this returns. */
  c->alt_count = n;
  c->alt_from = lv->alt_start;
  c->alt_to = end;
}

static void
close_paren(re_compiler *c)
{
  if (peek(c) != ')') compile_error(c, "end pattern with unmatched parenthesis");
  next_char(c);
}

/* Close the innermost level, the parse point on its ')' or at the end of the
   pattern: finish its alternation, emit what its construct puts after the
   body, consume the ')' where the construct owns one, and restore the
   options it opened with. */
static void
close_level(re_compiler *c)
{
  re_level *lv = &c->levels[c->level_count - 1];

  if (lv->kind != RE_LEVEL_COND) close_alternation(c, lv);
  switch (lv->kind) {
  case RE_LEVEL_PATTERN:
    /* a ')' that ends the pattern is left for mrb_re_compile() to refuse */
    break;

  case RE_LEVEL_GROUP:
    close_paren(c);
    if (lv->state) emit(c, RE_SAVE, 0, (uint16_t)(lv->num * 2 + 1));
    break;

  case RE_LEVEL_LOOKAHEAD:
    /* The end carries the lookaround's number, from the count the atomic
       groups use, so that a cut aimed at this lookaround is told from one
       aimed at a group around or inside it; see bt_match(). */
    emit(c, RE_LOOK_END, lv->state ? RE_LOOK_NEGATED : 0, lv->num);
    c->pat->code[lv->head].offset = (uint16_t)c->code_len;  /* patch: skip past sub-pattern */
    close_paren(c);
    c->needs_backtrack = TRUE;  /* needs backtracking engine */
    break;

  case RE_LEVEL_LOOKBEHIND: {
    emit(c, RE_LOOK_END, lv->state ? RE_LOOK_NEGATED : 0, lv->num);
    uint32_t sub_start = lv->aux;
    uint32_t body_end = c->code_len;  /* the RE_LOOK_END is at body_end - 1 */

    /* A sub-pattern holding a \g call cannot be measured yet: where the
       call jumps is not decided until resolve_calls(), and the body it runs
       may not be written yet. A width of its own per branch is out of reach
       for one of those, the alternation record being long gone by then, so
       it is left with the single carrier it can be given here and
       measure_deferred_lookbehinds() fills that in once the calls are
       wired. The landing bit is not set on the end here either: whether it
       is needed is known only once the body is measured, and
       add_lookbehind_widths() sets it.

       The same walk answers what a negative lookbehind may hold. One of
       those holds only where its body did not match, so a capture written
       inside it claims a slot that can never be set and shifts the
       numbering of every group after it. CRuby refuses such a pattern,
       wherever in the body the capture stands and however deep, with the
       message this gem already refuses a lookbehind body with. A group the
       body reaches by \g is another matter: the capture is written outside
       the assertion, and CRuby takes it. */
    mrb_bool deferred = FALSE;
    for (uint32_t i = sub_start; i < body_end; i++) {
      uint8_t op = c->pat->code[i].op;
      if (op == RE_CALL) {
        deferred = TRUE;
      }
      else if (op == RE_SAVE && lv->state) {
        compile_error(c, "invalid pattern in look-behind");
      }
    }
    if (deferred) {
      insert_inst(c, sub_start, RE_LB_WIDTH, 0, 0);
    }
    else {
      add_lookbehind_widths(c, lv->head, sub_start, body_end);
    }
    c->pat->code[lv->head].offset = (uint16_t)c->code_len;
    close_paren(c);
    c->needs_backtrack = TRUE;  /* needs backtracking engine */
    break;
  }

  case RE_LEVEL_ATOMIC:
    emit(c, RE_ATOMIC_END, 0, lv->num);
    close_paren(c);
    c->needs_backtrack = TRUE;  /* the Pike VM cannot cut a thread */
    break;

  case RE_LEVEL_ABSENT:
    emit(c, RE_ABSENT_END, 0, 0);
    close_paren(c);
    c->pat->code[lv->head].offset = (uint16_t)c->code_len;
    c->needs_backtrack = TRUE;  /* the Pike VM has no scan of its own */
    break;

  case RE_LEVEL_OPTION:
    close_paren(c);
    break;

  case RE_LEVEL_TOGGLE:
    /* Its scope ends at the ')' of the group it stands in, or at the end of
       the pattern, and neither is its own to consume. */
    break;

  case RE_LEVEL_COND:
    /* With no `no`, the head's offset is the text after the group; with
       one, the jump that ends `yes` goes there. */
    c->pat->code[lv->state ? lv->aux : lv->head].offset = (uint16_t)c->code_len;
    close_paren(c);
    c->needs_backtrack = TRUE;  /* the Pike VM's threads carry no test of their captures */
    break;
  }
  c->flags = lv->flags;
  c->depth--;
  c->level_count--;
}

/* Read the pattern from the parse point, one atom at a time, opening a level
   at every '(' and closing one at every ')'. The descent a recursive parser
   makes per level is a push here, so the parse stands in this one C frame
   at any depth, and what a level costs is the re_level open_level() finds
   room for. Returns at the end of the pattern, or at a ')' with no level
   left to close, which is left standing for mrb_re_compile() to refuse.

   A level is the atom its opener began: when it closes, the quantifiers
   after its ')' bind the code from its `begin`, as those after a character
   bind the character. Around any atom, c->atom_start is set to where the
   atom begins and put back afterwards, so that an atom whose `\u{...}` list
   moved it, inside a level or not, leaves nothing behind for the next one;
   a level keeps the outer value until its close. */
static void
compile_levels(re_compiler *c)
{
  open_level(c, RE_LEVEL_PATTERN, c->code_len, c->atom_start);
  for (;;) {
    /* One token ends here and the next may begin, so under /x this is where
       the whitespace between them goes: `a b` is `ab`, and the blanks before
       a '|' or a ')' are gone by the time the level looks for one. */
    skip_extended_space(c);
    int ch = peek(c);
    re_level *lv = &c->levels[c->level_count - 1];

    if (ch == '|') {
      next_char(c);
      if (lv->kind == RE_LEVEL_COND) {
        /* Two bodies at most: a third is `invalid conditional pattern`, as
           in CRuby. `yes` ends with a jump past `no`, and the head goes on
           at `no` where the group has not matched. */
        if (lv->state) compile_error(c, "invalid conditional pattern");
        lv->aux = emit(c, RE_JMP, 0, 0);
        c->pat->code[lv->head].offset = (uint16_t)c->code_len;
        lv->state = TRUE;
        continue;
      }
      emit(c, RE_JMP, RE_JMP_BRANCH, 0);  /* the branch's exit; see close_alternation() */
      lv->branches++;
      continue;
    }

    if (ch < 0 || ch == ')') {
      uint8_t kind = lv->kind;
      uint32_t begin = lv->begin;
      uint32_t outer = lv->atom_start;
      close_level(c);
      if (kind == RE_LEVEL_PATTERN) return;
      compile_quantifiers(c, begin, begin);
      c->atom_start = outer;
      continue;
    }

    uint32_t begin = c->code_len;
    uint32_t outer = c->atom_start;
    c->atom_start = begin;
    if (ch == '(') {
      next_char(c);
      open_group(c, begin, outer);
      continue;
    }
    if (!compile_atom(c)) {
      /* The character is a quantifier metacharacter with no atom to repeat,
         a `*`, `+` or `?` opening a sequence or standing after the toggle
         `(?i)`. CRuby raises RegexpError here; without this the loop would
         come round to the same character forever (A1). */
      compile_error(c, "target of repeat operator is not specified");
    }
    compile_quantifiers(c, begin, c->atom_start);
    c->atom_start = outer;
  }
}

/* Inside a character class, is `src` the start of a POSIX bracket [:name:]?
   Returns the position just past its closing "]", or NULL if it is not one.
   compile_charclass() consumes such a bracket as a unit, so its ']' does not
   end the class; a malformed one falls through and the '[' is an ordinary
   member. The scan below has to agree with the parser on this. */
static const char*
skip_posix_bracket(const char *src, const char *end)
{
  if (!(*src == '[' && src + 1 < end && src[1] == ':')) return NULL;
  const char *q = src + 2;
  while (q < end && *q != ':' && *q != ']') q++;
  /* Compare the distance rather than q + 1: the loop above stops with
     q == end for a bracket the pattern truncates, as in /[[:alpha/, and
     forming q + 1 from a one-past-the-end pointer is undefined even where
     the && never reads through it. */
  if (end - q >= 2 && q[0] == ':' && q[1] == ']') return q + 2;
  return NULL;
}

/*
 * Step over the one construct at `src` that a pattern scan must not read
 * into: an escape sequence, or a character class from its '[' through its
 * ']'. Returns the position just past it, having updated *class_depth, or
 * NULL when the byte at `src` is neither and the caller has to handle it
 * itself. A class spans several calls, with *class_depth carrying the state
 * between them, so the caller keeps one counter and starts it 0. It counts
 * rather than flags because a class nests: see the '[' arm below.
 *
 * An escape is stepped over at the width CRuby's pre-pass (re.c) reads it,
 * because preprocess_pattern() copies what is stepped over and removes
 * comments from what is not, and a comment removed from inside an escape
 * leaves the parser a different escape: `\u12(?#c)34` would reach it as the
 * valid `\u1234`, where CRuby has read `\u12(?` and rejected it before the
 * comment is removed. So the escapes spelled with digits take their digits
 * here:
 *
 * - `\u{...}` runs through its '}' (an unterminated list to the end): a `#`
 *   inside it is a malformed list for the parser to reject, not a comment
 *   for the pass to remove, and a "(?<" inside it declares nothing.
 * - `\uXXXX` takes the next four bytes whatever they are, so that a byte
 *   that is not a hex digit reaches the parser and is rejected there rather
 *   than replaced by whatever a removed comment brings next.
 * - `\x` takes up to two hex digits, and with none of them the one byte
 *   after, which the parser rejects. `\0` takes up to two more octal digits.
 *   Both stop short of their full width at the first byte that is not a
 *   digit, and a digit a removed comment brings next would lengthen them:
 *   `\x6(?#c)1` is `\x06` and `1` in CRuby, whose pre-pass has read `\x6`
 *   whole and written it at full width before it reaches the comment. *pad
 *   says how many '0' bytes bring the escape to full width, for the pass to
 *   write after the letter; a full-width or non-numeric escape sets it to 0.
 *
 * `\1`-`\9` are the backslash and the digit, and the digits after them are
 * plain bytes, as they are to CRuby's pre-pass: a removed comment does join
 * them, and `\1(?#c)0` is `\10` there and here.
 *
 * preprocess_pattern() and has_named_group() both walk the pattern hunting
 * for a "(?" opener, and both have to agree with the parser on when a '(' is
 * an opener rather than an escaped or bracketed byte. The rules for that live
 * here alone, so a correction to them cannot be made in one walk and missed
 * in the other.
 */
static const char*
skip_uninterpreted(const char *src, const char *end, uint32_t *class_depth, int *pad)
{
  char ch = *src;

  *pad = 0;
  if (ch == '\\' && src + 1 < end) {
    char kind = src[1];
    src += 2;
    if (kind == 'u') {
      if (src < end && *src == '{') {
        while (src < end) {
          if (*src++ == '}') break;
        }
      }
      else {
        src += (end - src < 4) ? end - src : 4;
      }
    }
    else if (kind == 'x') {
      int n = 0;
      while (n < 2 && src < end && hex_value(*src) >= 0) { src++; n++; }
      if (n == 0) { if (src < end) src++; }
      else *pad = 2 - n;
    }
    else if (kind == '0') {
      int n = 0;
      while (n < 2 && src < end && *src >= '0' && *src <= '7') { src++; n++; }
      *pad = 2 - n;
    }
    return src;
  }

  if (*class_depth > 0) {
    /* A POSIX bracket is consumed as a unit by parse_class_operand(), so the
       ']' that closes it does not close the class. */
    const char *q = skip_posix_bracket(src, end);
    if (q) return q;
    if (ch == ']') {
      (*class_depth)--;
      return src + 1;
    }
    /* A '[' that opens no bracket opens a class of its own, whose ']' closes
       that one and not this. Counting the levels is what keeps this pass
       reading the same span as the class levels do: with a flag, the ']' of
       [[a]b#c] would end the class here and leave `#c]` a comment under /x
       where the parser has it as members. */
    if (ch != '[') return src + 1;
  }
  else if (ch != '[') {
    return NULL;
  }

  (*class_depth)++;
  src++;
  /* A ']' written first is a literal member, optionally after '^',
     mirroring the `first` flag in parse_class_operand(). */
  if (src < end && *src == '^') src++;
  if (src < end && *src == ']') src++;
  return src;
}

/* Read the letters of an inline option group whose "(?" starts at `src`,
   as far as the comment pass needs them: whether the group is one,
   whether it is the toggle form (?imx) rather than the scoped (?imx:...),
   and what it makes of x. `*x_on` is left as it was when the letters do
   not name x. Returns the terminator's position, or NULL when the bytes
   are not an option group at all, which includes every malformed one: the
   parser reads those bytes too and reports them, and this pass has only to
   agree with it about the well-formed ones.

   The letters are optional here as they are in parse_inline_flags(), so a
   plain `(?:` is read as a scoped group carrying no options; that is what
   it is, and the pass does the same with it either way, opening a scope
   and leaving x as it stands. */
static const char*
scan_option_group(const char *src, const char *end, mrb_bool *toggle, mrb_bool *x_on)
{
  if (end - src < 3 || src[1] != '?') return NULL;
  const char *q = src + 2;
  mrb_bool negate = FALSE;
  for (; q < end; q++) {
    if (*q == '-') negate = TRUE;
    else if (*q == 'x') *x_on = !negate;
    else if (*q != 'i' && *q != 'm') break;
  }
  if (q >= end || (*q != ')' && *q != ':')) return NULL;
  *toggle = (*q == ')');
  return q;
}

/* The comment pass's scope stack: one bit per open group, holding what
   extended mode was outside it. */
static void
scope_set(uint8_t *scope, mrb_int depth, mrb_bool extended)
{
  uint8_t bit = (uint8_t)(1u << (depth & 7));
  if (extended) scope[depth >> 3] |= bit;
  else scope[depth >> 3] &= (uint8_t)~bit;
}

static mrb_bool
scope_get(const uint8_t *scope, mrb_int depth)
{
  return (scope[depth >> 3] >> (depth & 7)) & 1;
}

/*
 * Rewrite the pattern before the parser sees it: remove the (?#...) comment
 * groups, under any flags, and wherever extended mode is in effect the `#`
 * comments too. That is what CRuby's own pre-pass (re.c) removes before its
 * tokenizer reads the pattern, and it is why the removal is done here rather
 * than by the parser: taking a comment out of the source joins the bytes on
 * either side of it, and CRuby has `\1(?#c)0` and `\1#c`, a newline and `0`
 * both as `\10`. The whitespace of free-spacing mode is another matter. It
 * separates tokens and never joins anything, so the parser skips it between
 * tokens (skip_extended_space()) and reads every token, escapes and group
 * names included, with the whitespace still in place.
 *
 * Extended mode is in effect from the start when the Regexp carries /x, and
 * it is switched inside the pattern by the inline option groups: (?x) and
 * (?-x) for the rest of the enclosing group, (?x:...) and (?-x:...) for
 * their own body. So this pass keeps a stack of one bit per open group,
 * pushed at every '(' it interprets and popped at every ')', which is what
 * lets a toggle end where its group does. That is the same scoping the
 * parser gives x for the whitespace; the `#` comments have to be resolved
 * here because the bytes they cover are gone before the parser reads them.
 * A `#` inside [...] is a member of the class, and so is a (?# written
 * there. Escaped characters (\ followed by anything) are preserved.
 * skip_uninterpreted() decides which bytes those are, and it also says when
 * a numeric escape is to be written at full width, `\x6` as `\x06`, so that
 * a digit a removed comment brings next cannot lengthen it.
 *
 * The buffer comes from the GC arena, which holds it until the caller's frame
 * is gone: the parser reads it from beginning to end, and every raise in
 * between leaves this function nothing to be reached through. The scope
 * stack lives behind the rewritten pattern in the same allocation: a group
 * opener is one byte of source, so len bits is room for every group. The
 * pattern part is twice the source: writing an escape at full width
 * lengthens it by two bytes at most, `\0` to `\000`, and nothing else the
 * pass writes is longer than what it read.
 */
static char*
preprocess_pattern(mrb_state *mrb, const char *src, mrb_int len,
                   mrb_bool extended, mrb_int *out_len)
{
  char *buf = (char*)mrb_temp_alloc(mrb, (size_t)len * 2 + ((size_t)len + 7) / 8);
  uint8_t *scope = (uint8_t*)buf + len * 2;
  mrb_int depth = 0;
  mrb_int o = 0;
  uint32_t class_depth = 0;
  const char *end = src + len;

  while (src < end) {
    char ch = *src;
    /* An escape or a character class is copied through untouched: neither
       holds a comment. A numeric escape short of its full width is padded
       with zeros after its letter, `\x6` to `\x06`. */
    int pad;
    const char *skip = skip_uninterpreted(src, end, &class_depth, &pad);
    if (skip) {
      if (pad) {
        buf[o++] = *src++;
        buf[o++] = *src++;
        while (pad-- > 0) buf[o++] = '0';
      }
      while (src < skip) buf[o++] = *src++;
      continue;
    }
    if (ch == ')') {
      /* An unmatched ')' has no scope to close; the parser reports it. */
      if (depth > 0) extended = scope_get(scope, --depth);
      buf[o++] = *src++;
      continue;
    }
    if (ch == '(' && end - src >= 3 && src[1] == '?' && src[2] == '#') {
      /* Comment group: ends at the first ')' not preceded by a backslash.
         It does not nest, so (?#a(?#b)) closes at the first ')' and leaves
         the second one to be reported as unmatched, as CRuby does.
         Dropping the group here rather than in compile_atom() is what lets
         it stand where an atom cannot: CRuby compiles "a(?#x)*" as "a*", and
         an atom that emits no instruction cannot be a quantifier's target.
         An unterminated group is copied through instead, so that
         compile_atom() raises on it. */
      const char *q = src + 3;
      while (q < end && *q != ')') {
        if (*q == '\\' && q + 1 < end) q++;
        q++;
      }
      if (q < end) {
        src = q + 1;
        continue;
      }
      buf[o++] = *src++;
      buf[o++] = *src++;
      buf[o++] = *src++;
      continue;
    }
    if (ch == '(') {
      mrb_bool toggle = FALSE, x_on = extended;
      const char *term = scan_option_group(src, end, &toggle, &x_on);
      if (term && toggle) {
        /* (?imx) changes the rest of the enclosing group and opens none of
           its own, so the stack is left alone. The group is copied through
           for the parser, which applies all three letters from the same
           bytes. */
        while (src <= term) buf[o++] = *src++;
        extended = x_on;
        continue;
      }
      /* Every other '(' opens a group whose ')' restores what x is now:
         (?imx:...) after setting it for its body, and a plain, named,
         non-capturing or lookaround group after leaving it as it is. */
      scope_set(scope, depth++, extended);
      if (term) {
        while (src <= term) buf[o++] = *src++;
        extended = x_on;
        continue;
      }
      buf[o++] = *src++;
      continue;
    }
    if (extended && ch == '#') {
      /* Skip to the end of the line, newline included: the comment is one
         removed span, and the newline is not left for the parser to read
         as whitespace where the comment stood inside a token. */
      while (src < end && *src != '\n') src++;
      if (src < end) src++;
      continue;
    }
    buf[o++] = *src++;
  }
  *out_len = o;
  return buf;
}

/*
 * Does the pattern declare a named group anywhere? Answering this before the
 * parser starts is what lets compile_atom() demote a plain (...) that comes
 * before the named group that causes the demotion.
 *
 * A definition has two spellings, so the scan looks for "(?<" and "(?'" both.
 * It excludes (?<= and (?<!, which are lookbehind rather than a definition,
 * and it steps over escapes and character classes with skip_uninterpreted(),
 * so that /\(?/ and /[(?<]/ are not false positives.
 *
 * A truncated "(?<" or "(?'" at the end of the pattern is counted as a named
 * group, which is harmless: the parser reaches the same bytes and raises
 * there.
 */
static mrb_bool
has_named_group(const char *src, mrb_int len)
{
  const char *end = src + len;
  uint32_t class_depth = 0;

  while (src < end) {
    char ch = *src;
    int pad;
    const char *skip = skip_uninterpreted(src, end, &class_depth, &pad);
    if (skip) {
      src = skip;
      continue;
    }
    if (ch == '(' && end - src >= 3 && src[1] == '?') {
      if (src[2] == '\'') return TRUE;
      if (src[2] == '<') {
        /* src + 3 is at most end here, since the test above leaves three
           bytes to read, so the one-past-the-end pointer it can form is a
           position C allows. */
        if (src + 3 >= end || (src[3] != '=' && src[3] != '!')) return TRUE;
        src += 3;
        continue;
      }
    }
    src++;
  }
  return FALSE;
}

/* Instructions the anchor and first-byte walks mark and keep pcs for without
   asking the allocator for room. A program this long or shorter is scanned
   from the frame of the scan that calls them, which is most of what a pattern
   spells: the marks and the pcs are five bytes an instruction. */
#define RE_WALK_INLINE 128

/* A walk's marks and the pcs it has yet to take, one apiece per instruction,
   in one block: the pcs come first, since the marks are bytes and would leave
   them unaligned. NULL is the allocator having refused, which leaves the scan
   that asked unbuilt. What these walks answer moves a search along and is
   nothing a pattern's answer depends on, so a build with nothing left
   compiles the pattern and scans it the long way. */
static uint32_t*
walk_room(mrb_state *mrb, uint32_t n)
{
  return (uint32_t*)mrb_malloc_simple(mrb, (size_t)n * (sizeof(uint32_t) + 1));
}

/* Put the bytes a character of the class can begin with into `bm`, all 256
   of them. A codepoint member begins with the lead byte UTF-8 spells it with,
   which rises with the codepoint, so a range's leads are the run between its
   ends'; a byte member (RE_CLASS_BYTE) is the byte itself. The set is only
   ever a superset: a lead of a codepoint the subject cannot hold (a
   byte-indexed one) costs a proposal and nothing more, and a byte the scan
   finds inside a character is refused by the search's interior test. FALSE
   where the class answers by type, which has no range to read. */
static mrb_bool
class_first_bytes(const re_charclass *cc, uint8_t *bm)
{
  for (int i = 0; i < 16; i++) bm[i] |= cc->bitmap[i];
#ifdef RE_UNICODE_CTYPE
  if (RE_CLASS_HAS_CTYPE(cc)) return FALSE;
#endif
  if (cc->utf8_any) {
    memset(bm + 16, 0xff, 16);
    return TRUE;
  }
  for (uint32_t i = 0; i < cc->num_ranges; i++) {
    uint32_t lo = cc->ranges[2*i], hi = cc->ranges[2*i + 1];
    uint32_t b, e;
    if (lo & RE_CLASS_BYTE) {
      b = lo & 0xff;
      e = hi & 0xff;
    }
    else {
      b = utf8_lead_byte(lo);
      e = utf8_lead_byte(hi > 0x10FFFF ? 0x10FFFF : hi);
    }
    for (; b <= e; b++) bm[b >> 3] |= (uint8_t)(1 << (b & 7));
  }
  return TRUE;
}

/*
 * Compute the set of bytes that could be the first consumed byte of a match.
 * Walks bytecode from pc=0, following epsilon transitions (SAVE, JMP, SPLIT).
 * Returns TRUE if the set is narrower than "any byte" (i.e., useful for skip).
 * `bm` covers all 256 bytes; see class_first_bytes() for why a byte above
 * 127 in it is safe to scan for.
 *
 * Every path has to answer TRUE for the set to be one, so a path that
 * answers FALSE ends the walk there; the others put their bytes in `bm` and
 * hand the walk back the branch a fork left on `stack`, newest first, which
 * is the order taking one in a call of its own gave.
 */
static mrb_bool
first_set_walk(const re_inst *code, uint32_t code_len,
               const re_charclass *classes, uint32_t pc,
               uint8_t *bm, uint8_t *seen, uint32_t *stack)
{
  uint32_t top = 0;

  for (;;) {
    while (pc < code_len) {
      if (seen[pc]) goto next;  /* already visited */
      seen[pc] = 1;
      switch (code[pc].op) {
      case RE_SAVE:
      case RE_BOL: case RE_EOL: case RE_BOT: case RE_EOT: case RE_EOTNL: case RE_GPOS:
      case RE_WBOUND: case RE_NWBOUND:
      case RE_ATOMIC: case RE_ATOMIC_END:
        pc++;
        continue;  /* zero-width, keep walking */
      case RE_JMP:
        pc = code[pc].offset;
        continue;
      case RE_CALL:
        /* The body runs where the call stands, so its first bytes are the
           call's. What follows a body that can complete without consuming is
           unknown to this walk, which has no call stack; that path ends at
           the body's RE_RETURN, whose default below answers FALSE. */
        pc = code[pc].offset;
        continue;
      case RE_SPLIT:
      case RE_COND:  /* either body may run first; the walk cannot know which */
        /* both branches: pc+1 and offset */
        stack[top++] = pc + 1;
        pc = code[pc].offset;
        continue;
      case RE_SPLITNG:
        stack[top++] = code[pc].offset;
        pc = pc + 1;
        continue;
      case RE_BYTE:
      case RE_CHAR:
        bm[code[pc].a >> 3] |= (uint8_t)(1 << (code[pc].a & 7));
        goto next;
      case RE_CLASS:
        if (!class_first_bytes(&classes[code[pc].a], bm)) return FALSE;
        goto next;
      case RE_NCLASS: {
        /* negated class: complement of bitmap. Too many bits; not useful. */
        return FALSE;
      }
      case RE_ANY: case RE_ANY_NL:
        return FALSE;  /* any byte possible */
      case RE_MATCH:
        /* Reaching MATCH via epsilon transitions means the regex can match
           zero characters at any position. Skipping bytes that aren't in the
           first-byte set would skip past valid empty-match positions, so the
           optimization isn't safe -- bail out and accept any starting byte. */
        return FALSE;
      default:
        return FALSE;
      }
    }
    /* Walked off the end without hitting MATCH or a consuming op. Treat as
       empty-matchable, same as RE_MATCH. */
    return FALSE;

  next:
    if (top == 0) return TRUE;
    pc = stack[--top];
  }
}

/*
 * The anchor every path from pc asserts before consuming input, as the
 * weakest guarantee: RE_ANCHOR_BOT when every path passes \A first,
 * RE_ANCHOR_BOL when every path passes at least ^, RE_ANCHOR_NONE otherwise.
 * The walk covers zero-width instructions only, so an anchor it finds holds
 * at the position a match would start at; anything consuming, unknown, or an
 * epsilon path to RE_MATCH answers NONE. A branch already seen answers BOT,
 * the neutral value for the min: a path cut short there has no anchor of its
 * own before the join (one before it would have been the walk's answer
 * already), so its value is the join's, which the visit that explored the
 * join contributed.
 *
 * The branch of a fork the walk has yet to take waits on `stack`, newest
 * first, and every branch that ends folds its value into the answer. NONE
 * ends the whole walk where the recursion returned it up: what it says is
 * that a path asserts nothing, and no other path can make up for it.
 */
static uint8_t
anchor_walk(const re_inst *code, uint32_t code_len, uint32_t pc, uint8_t *seen,
            uint32_t *stack)
{
  uint8_t best = RE_ANCHOR_BOT;  /* the neutral value for the min */
  uint32_t top = 0;
  uint8_t here;

  for (;;) {
    while (pc < code_len) {
      if (seen[pc]) { here = RE_ANCHOR_BOT; goto joined; }
      seen[pc] = 1;
      switch (code[pc].op) {
      case RE_BOT:
        here = RE_ANCHOR_BOT;
        goto joined;
      case RE_BOL:
        here = RE_ANCHOR_BOL;
        goto joined;
      case RE_SAVE:
      case RE_EOL: case RE_EOT: case RE_EOTNL:
      case RE_WBOUND: case RE_NWBOUND:
      case RE_ATOMIC: case RE_ATOMIC_END:
        pc++;
        continue;
      case RE_JMP:
        pc = code[pc].offset;
        continue;
      case RE_CALL:
        /* The body runs where the call stands, as in first_set_walk(); a body
           that completes without consuming ends at its RE_RETURN, whose
           default answers NONE. */
        pc = code[pc].offset;
        continue;
      case RE_SPLIT:
      case RE_SPLITNG:
      case RE_COND:  /* a fork to this walk: both bodies are paths */
        stack[top++] = pc + 1;
        pc = code[pc].offset;
        continue;
      default:
        return RE_ANCHOR_NONE;
      }
    }
    return RE_ANCHOR_NONE;

  joined:
    if (here < best) best = here;
    if (top == 0) return best;
    pc = stack[--top];
  }
}

/* The anchor of the program, with the room anchor_walk() needs. */
static uint8_t
compute_anchor(mrb_state *mrb, const re_inst *code, uint32_t code_len)
{
  uint32_t n = code_len + 1;
  uint32_t pcs[RE_WALK_INLINE];
  uint8_t marks[RE_WALK_INLINE];
  uint32_t *heap = NULL;
  uint32_t *stack = pcs;
  uint8_t *seen = marks;
  if (n > RE_WALK_INLINE) {
    heap = walk_room(mrb, n);
    if (!heap) return RE_ANCHOR_NONE;
    stack = heap;
    seen = (uint8_t*)(heap + n);
  }
  memset(seen, 0, n);
  uint8_t anchor = anchor_walk(code, code_len, 0, seen, stack);
  mrb_free(mrb, heap);
  return anchor;
}

/* TRUE when a path that need not consume runs from pc to goal, so the
   repetition that goal closes can complete an iteration without consuming.
   A lookaround is zero-width whatever its sub-pattern does, so the walk
   steps over the sub-pattern; a backreference to a group that captured
   empty consumes nothing, so it can be on such a path, and so can a call,
   whose body may match empty. seen[] is marked with `mark` rather than
   cleared, so one buffer serves every edge.

   The walk is not bounded to [pc, goal]: an inline occurrence of a called
   group jumps out to the trampoline after the pattern and back in, so a path
   may stand past `goal` and still reach it. seen[] is what makes the walk
   finite, and the answer stays conservative: what a stray path can add is a
   mark on a loop whose body cannot in fact match empty, and a marked loop
   whose iterations all consume never triggers the handling the mark turns
   on.

   `stack` holds the branch of each fork the walk has still to take, newest
   first, which is the order following one in a call of its own gave. A pc
   goes on it only where the walk marked a fork, and a mark is made once,
   so the caller's code_len entries are room enough for any pattern. */
static mrb_bool
epsilon_path(const re_inst *code, uint32_t code_len, uint32_t pc, uint32_t goal,
             uint32_t *seen, uint32_t mark, uint32_t *stack)
{
  uint32_t top = 0;

  for (;;) {
    while (pc != goal) {
      if (pc >= code_len || seen[pc] == mark) goto next;
      seen[pc] = mark;
      switch (code[pc].op) {
      case RE_SAVE:
      case RE_BOL: case RE_EOL: case RE_BOT: case RE_EOT: case RE_EOTNL: case RE_GPOS:
      case RE_WBOUND: case RE_NWBOUND:
      case RE_ATOMIC: case RE_ATOMIC_END:
      case RE_BACKREF:
      case RE_CALL:
      case RE_ABSENT_START:
        pc++;
        break;
      case RE_JMP:
      case RE_LOOKAHEAD: case RE_NEG_LOOKAHEAD:
      case RE_LOOKBEHIND: case RE_NEG_LOOKBEHIND:
      /* An absent repeater takes no text where its body matches at the
         position it began at, so a repetition around one has a body that can
         match empty and needs the handling this pass turns on. The body of
         the absent is not on the path: it is a test the scan runs, not text
         the search passes through. */
      case RE_ABSENT:
        pc = code[pc].offset;
        break;
      case RE_SPLIT:
      case RE_SPLITNG:
      case RE_COND:  /* either body may be the one that runs */
        stack[top++] = pc + 1;
        pc = code[pc].offset;
        break;
      default:
        goto next;  /* consumes input */
      }
    }
    return TRUE;

  next:
    if (top == 0) return FALSE;
    pc = stack[--top];
  }
}

/* Find the repetitions whose body can match empty and mark the backward edge
   that closes each one, so that both engines know which loops need the
   empty-iteration handling (add_thread() and bt_match()) and which can stay
   on the cheap path. A repetition laid out as e* is closed by a jump back to
   its SPLIT/SPLITNG head, and that head is marked too: it is where an
   iteration begins, which the backtracker has to record; see bt_iter(). The
   head is a forward edge, and a forward edge's mark means nothing else.
   Returns how deeply the marked loops nest, which bounds the VM's epsilon
   passes and the thread lists sized from them; see RE_MAX_PASS and
   RE_LIST_CAPA. */
static uint8_t
mark_empty_loops(mrb_state *mrb, re_inst *code, uint32_t code_len)
{
  /* One block holds all three arrays. Asking three times puts a raising call
     between the first allocation and anything that could free it: mrb_calloc()
     raises when it cannot answer, and this frame is the only owner `delta` has.
     code_len is capped at RE_MAX_CODE_LEN, so the tripled element count stays
     well inside the overflow check mrb_calloc() makes. */
  uint32_t n = code_len + 1;
  int32_t *delta = (int32_t*)mrb_calloc(mrb, 3 * (size_t)n, sizeof(int32_t));
  uint32_t *seen = (uint32_t*)(delta + n);
  uint32_t *stack = seen + n;  /* the forks epsilon_path() has yet to take */
  uint32_t mark = 0;

  for (uint32_t pc = 0; pc < code_len; pc++) {
    re_inst in = code[pc];
    /* The parsed pattern ends at its RE_MATCH; what follows are the
       trampolines resolve_calls() appended, whose jump back into a called
       body is a backward edge but not a loop. Reading one as a loop close
       was two defects in one: its "head" is whatever instruction the body
       resumes after, whose fields mean something else entirely, so marking
       it clobbered them, and the empty-iteration stop then resumed at that
       instruction's `offset`, which for a backward SPLITNG is the body --
       the repetition that was to stop re-entered instead, and grew the
       stack to the limit. */
    if (in.op == RE_MATCH) break;
    if (in.op != RE_JMP && in.op != RE_SPLIT && in.op != RE_SPLITNG) continue;
    code[pc].a = 0;                /* this pass owns `a` on the edge opcodes */
    if (in.offset > pc) continue;  /* forward edge: alternation, not a loop */
    if (!epsilon_path(code, code_len, in.offset, pc, seen, ++mark, stack)) continue;
    code[pc].a = 1;
    if (in.op == RE_JMP) {
      /* The head was passed earlier in this scan, so its mark stays. */
      mrb_assert(code[in.offset].op == RE_SPLIT || code[in.offset].op == RE_SPLITNG);
      code[in.offset].a = 1;
    }
    delta[in.offset]++;
    delta[pc + 1]--;  /* the closing edge itself still sits inside the loop */
  }

  int32_t depth = 0, max = 0;
  for (uint32_t pc = 0; pc < code_len; pc++) {
    depth += delta[pc];
    if (depth > max) max = depth;
  }
  mrb_free(mrb, delta);
  return max > UINT8_MAX ? UINT8_MAX : (uint8_t)max;
}

static mrb_bool
compute_first_set(mrb_state *mrb, const re_inst *code, uint32_t code_len,
                  const re_charclass *classes, uint8_t *bm)
{
  uint32_t n = code_len + 1;
  uint32_t pcs[RE_WALK_INLINE];
  uint8_t marks[RE_WALK_INLINE];
  uint32_t *heap = NULL;
  uint32_t *stack = pcs;
  uint8_t *seen = marks;
  if (n > RE_WALK_INLINE) {
    heap = walk_room(mrb, n);
    if (!heap) return FALSE;
    stack = heap;
    seen = (uint8_t*)(heap + n);
  }
  memset(seen, 0, n);
  mrb_bool narrow = first_set_walk(code, code_len, classes, 0, bm, seen, stack);
  mrb_free(mrb, heap);
  if (!narrow) return FALSE;
  /* Check if bitmap is all-ones (no benefit to skip) */
  int set_bits = 0;
  for (int i = 0; i < 32; i++) {
    for (int b = 0; b < 8; b++) {
      if (bm[i] & (1 << b)) set_bits++;
    }
  }
  return set_bits < 192;  /* useful only if fewer than 75% of bytes match */
}

/* ---- subexpression calls -------------------------------------------------
   The parse leaves a pattern with \g in it unfinished in three ways: an
   RE_CALL may still carry a parked reference, no RE_CALL has anywhere to
   jump, and a lookbehind holding one is unmeasured. resolve_calls() finishes
   all three, and refuses the recursions no input could end. */

/* One reachability walk over the finished code, from `start` down every
   branch. The answer is the set of groups the walk reached a RE_CALL to, as
   bits; with `reached_ret` given, whether it reached the RE_RETURN closing
   `ret_group`'s body is answered there too. Three questions share the walk:

   - consuming_stops on: which calls stand where no input need be consumed
     first. What a call itself consumes is its body's minimum, so the walk
     steps over one only when `pass_mask` holds the group -- the groups whose
     body can complete consuming nothing, computed by fixpoint below. CRuby
     counts the same way: `(?<g1>b\g<g1>??)$\g<0>?` compiles there because
     the call to g1 consumes a `b` and \g<0> is never at the head, while
     `(?<e>)(?<a>\g<e>\g<a>)` is refused because e's body is empty.
   - consuming_stops off, look_forks on: which calls can run at all inside an
     invocation, wherever they stand -- inside either branch of a fork, and
     inside a lookaround of either polarity, whose sub-pattern runs whatever
     its answer is used for.
   - consuming_stops off, look_forks off, wall_mask set: whether an
     invocation can complete without recursing. A lookaround is walked
     through its sub-pattern alone, since the text after it is reached only
     once the sub-pattern has run; a call no invocation is yet known to
     return from is a wall, and reaching the body's own RE_RETURN is the
     escape.

   A RE_RETURN ends every path: the walk has no call stack, and what follows
   one belongs to whoever called. seen[] is marked with `mark` so one buffer
   serves every walk; `stack` is the worklist, and code_len entries bound it
   because a fork is pushed at most once. */
static uint32_t
call_walk(const re_inst *code, uint32_t code_len, uint32_t start,
          uint32_t *seen, uint32_t mark, uint32_t *stack,
          mrb_bool consuming_stops, mrb_bool look_forks, uint32_t wall_mask,
          uint32_t pass_mask, uint16_t ret_group, mrb_bool *reached_ret)
{
  uint32_t mask = 0;
  uint32_t top = 0;

  if (reached_ret) *reached_ret = FALSE;
  stack[top++] = start;
  while (top > 0) {
    uint32_t pc = stack[--top];
    for (;;) {
      if (pc >= code_len || seen[pc] == mark) break;
      seen[pc] = mark;
      re_inst in = code[pc];
      switch (in.op) {
      case RE_CHAR: case RE_BYTE:
      case RE_CLASS: case RE_NCLASS: case RE_ANY: case RE_ANY_NL:
        if (consuming_stops) break;
        pc++;
        continue;
      case RE_SAVE:
      case RE_BOL: case RE_EOL: case RE_BOT: case RE_EOT: case RE_EOTNL: case RE_GPOS:
      case RE_WBOUND: case RE_NWBOUND:
      case RE_ATOMIC: case RE_ATOMIC_END:
      case RE_BACKREF: case RE_LOOK_END:
      case RE_LB_WIDTH:  /* a rewind, which consumes nothing */
      case RE_ABSENT_START: case RE_ABSENT_END:
        pc++;
        continue;
      case RE_JMP:
        pc = in.offset;
        continue;
      case RE_SPLIT: case RE_SPLITNG:
      case RE_COND:  /* a fork to this walk: both bodies are paths */
        stack[top++] = in.offset;
        pc++;
        continue;
      case RE_LOOKAHEAD: case RE_NEG_LOOKAHEAD:
      /* The scan of an absent repeater runs its body wherever it stands,
         and the text after is reached once the scan is done, which is the
         same shape a lookaround has here. */
      case RE_ABSENT:
        if (look_forks) stack[top++] = in.offset;
        pc++;
        continue;
      case RE_LOOKBEHIND: case RE_NEG_LOOKBEHIND:
        if (look_forks) stack[top++] = in.offset;
        pc++;  /* into the sub-pattern, whose head is a rewind */
        continue;
      case RE_CALL:
        if ((wall_mask >> in.a) & 1) break;
        mask |= (uint32_t)1 << in.a;
        /* What stands after the call is reached only through what its body
           consumes; a body that cannot complete at zero width ends this
           path where a literal would. */
        if (!((pass_mask >> in.a) & 1)) break;
        pc++;
        continue;
      case RE_RETURN:
        if (reached_ret && in.a == ret_group) *reached_ret = TRUE;
        break;
      default:  /* RE_MATCH */
        break;
      }
      break;
    }
  }
  return mask;
}

/* Close a 32-node call graph under reachability, in place. */
static void
call_closure(uint32_t *adj)
{
  for (;;) {
    mrb_bool changed = FALSE;
    for (int k = 0; k < RE_MAX_CAPTURES; k++) {
      uint32_t reach = adj[k];
      for (int m = 0; m < RE_MAX_CAPTURES; m++) {
        if ((adj[k] >> m) & 1) reach |= adj[m];
      }
      if (reach != adj[k]) { adj[k] = reach; changed = TRUE; }
    }
    if (!changed) return;
  }
}

/* Refuse the recursions no input could end, with CRuby's message and, as far
   as the probes reach, CRuby's line. Two shapes are refused:

   - a call cycle a walk reaches with nothing consumed on the way, wherever
     the calls stand: `(?<a>\g<a>?x)` and `(?<a>x|\g<a>)` alike, since an
     engine that takes them re-enters the body at the position it left.
   - a group no invocation can complete: `(?<a>x\g<a>)` must recurse to match
     at all, and so must `x(?=\g<0>)`, whose lookahead is not an alternative
     but a requirement.

   What escapes both is a call every path can decline: `(?<a>x\g<a>?)` and
   the balanced-parentheses pattern this feature exists for. A body may also
   decline through a call it can step through, which is how the mutual
   recursion in `(?<a>\g<b>)(?<b>x\g<a>?)` compiles. */
static void
never_ending_check(re_compiler *c, uint32_t called, const uint32_t *entry)
{
  uint32_t code_len = c->code_len;
  const re_inst *code = c->pat->code;
  uint32_t eps[RE_MAX_CAPTURES];   /* calls reached consuming nothing */
  uint32_t mark = 0;
  mrb_bool bad = FALSE;

  /* One block: the seen marks and the walk's worklist. Freed before the
     raise below, this frame being its only owner. */
  uint32_t *buf = (uint32_t*)mrb_calloc(c->mrb, 2 * (size_t)code_len + 2,
                                        sizeof(uint32_t));
  uint32_t *seen = buf;
  uint32_t *stack = buf + code_len + 1;

  /* Which called bodies can complete consuming nothing, to fixpoint: a body
     completing through a call needs that call's body to have completed the
     same way, so the set starts empty and grows until it holds. This is what
     prices a call in the head walk below at its body's minimum rather than
     at zero. */
  uint32_t eps_done = 0;
  for (;;) {
    uint32_t before = eps_done;
    for (int k = 0; k < RE_MAX_CAPTURES; k++) {
      if (!((called >> k) & 1) || ((eps_done >> k) & 1)) continue;
      mrb_bool done;
      call_walk(code, code_len, entry[k], seen, ++mark, stack,
                TRUE, TRUE, 0, eps_done, (uint16_t)k, &done);
      if (done) eps_done |= (uint32_t)1 << k;
    }
    if (eps_done == before) break;
  }

  memset(eps, 0, sizeof(eps));
  for (int k = 0; k < RE_MAX_CAPTURES; k++) {
    if (!((called >> k) & 1)) continue;
    eps[k] = call_walk(code, code_len, entry[k], seen, ++mark, stack,
                       TRUE, TRUE, 0, eps_done, (uint16_t)k, NULL);
  }
  call_closure(eps);

  for (int k = 0; !bad && k < RE_MAX_CAPTURES; k++) {
    if (((called >> k) & 1) && ((eps[k] >> k) & 1)) bad = TRUE;
  }

  /* Which called bodies an invocation can complete, to fixpoint: a body
     completes by declining every call it cannot step through, and it can
     step through only a call some invocation is already known to complete,
     its own excluded. The set starts empty and grows, so a mutual recursion
     is admitted from whichever body stands on its own first:
     `(?<a>\g<b>)(?<b>x\g<a>?)` compiles because b's body can stop at its
     `x`, which is then what a's one call steps through. A body left out
     when the set holds is one no input could end. */
  if (!bad) {
    uint32_t ends = 0;
    for (;;) {
      uint32_t before = ends;
      for (int k = 0; k < RE_MAX_CAPTURES; k++) {
        if (!((called >> k) & 1) || ((ends >> k) & 1)) continue;
        mrb_bool escapes;
        call_walk(code, code_len, entry[k], seen, ++mark, stack,
                  FALSE, FALSE, ~ends, ~(uint32_t)0, (uint16_t)k, &escapes);
        if (escapes) ends |= (uint32_t)1 << k;
      }
      if (ends == before) break;
    }
    if (called & ~ends) bad = TRUE;
  }

  mrb_free(c->mrb, buf);
  if (bad) compile_error(c, "never ending recursion");
}

/* Measure the lookbehinds whose sub-pattern holds a call, which the parse
   left unmeasured with an empty RE_LB_WIDTH at the head of the body; see the
   lookbehind arm in compile_atom(). The walk is the parse's own, now able to
   follow a call. Nothing may move code from here on, so the carrier that is
   already there is the only one such a lookbehind gets: its body has to come
   out one width, where a body without a call may take one per branch. */
static void
measure_deferred_lookbehinds(re_compiler *c)
{
  for (uint32_t pc = 0; pc + 1 < c->code_len; pc++) {
    re_inst in = c->pat->code[pc];
    if (in.op != RE_LOOKBEHIND && in.op != RE_NEG_LOOKBEHIND) continue;
    if (in.a != 0) continue;  /* measured during the parse */
    c->pat->code[pc + 1].offset = lookbehind_width(c, pc + 2, in.offset);
    c->pat->code[pc].a = 1;
  }
}

/* Finish what the \g arm left: resolve the parked references, give every
   called group's body its one entry and one exit, point every call at the
   body it names, refuse the recursions no input could end, and measure the
   lookbehinds that waited. Runs once, after the last instruction is emitted;
   nothing moves code after it, which is what lets RE_CALL carry a code index
   from here on (see op_holds_code_index()). */
static void
resolve_calls(re_compiler *c)
{
  re_pending_call *pend = c->num_pending
    ? (re_pending_call*)RSTRING_PTR(c->pending_calls) : NULL;
  uint32_t entry[RE_MAX_CAPTURES];
  uint32_t called = 0;
  uint32_t parsed_len = c->code_len;

  /* Resolve the parked references, every record and not only those an
     instruction still carries: `{0}` drops a callless atom's code but not
     its records, and CRuby refuses `(?:\g<nope>){0}` all the same. A name
     is read against the whole pattern's definitions: a group written after
     the call is reachable, a name two groups carry is refused where the
     call reads it, as CRuby refuses it, and a number past the groups open
     at the call is checked against the count the finished pattern reached.
     Every group number here is under RE_MAX_CAPTURES: the numeric forms are
     refused in a pattern that demotes plain groups, so the count they were
     checked against is the capture count. */
  for (uint16_t i = 0; i < c->num_pending; i++) {
    re_pending_call *r = &pend[i];
    const char *at = c->src + r->src_off;
    if (r->kind == RE_PENDING_NUM) {
      if (r->resolved > c->num_groups) {
        compile_error_str(c, mrb_format(c->mrb, "undefined group <%l> reference",
                                        at, (size_t)r->len));
      }
    }
    else {
      int group = -1;
      int defs = 0;
      for (uint16_t n = 0; n < c->num_named; n++) {
        if (c->pat->named_captures[n].name_len == r->len &&
            memcmp(c->pat->named_captures[n].name, at, r->len) == 0) {
          group = c->pat->named_captures[n].group;
          defs++;
        }
      }
      if (defs == 0) {
        compile_error_str(c, mrb_format(c->mrb, "undefined name <%l> reference",
                                        at, (size_t)r->len));
      }
      if (defs > 1) {
        compile_error_str(c, mrb_format(c->mrb, "multiplex definition name <%l> call",
                                        at, (size_t)r->len));
      }
      r->resolved = (uint32_t)group;
    }
  }
  for (uint32_t pc = 0; pc < parsed_len; pc++) {
    re_inst *in = &c->pat->code[pc];
    if (in->op != RE_CALL || in->a != RE_CALL_PENDING) continue;
    in->a = (uint8_t)pend[in->offset].resolved;
    in->offset = 0;
  }

  for (uint32_t pc = 0; pc < parsed_len; pc++) {
    if (c->pat->code[pc].op == RE_CALL) {
      called |= (uint32_t)1 << c->pat->code[pc].a;
    }
  }

  /* Reroute every copy of every called group's body through the call
     machinery, so the body has one entry and one exit however it is reached.
     The inline SAVE pair becomes a jump out to a trampoline appended after
     the pattern and the RE_RETURN that jumps back, so nothing here moves an
     instruction and no jump into or around the group needs relocating: a
     repetition's back edge still lands where the group begins, which is now
     the jump out, and takes the same path the first iteration took. A
     quantifier that copied the body leaves several pairs; each copy gets its
     own trampoline, and the calls all run the first, the slots being shared
     among the copies anyway. */
  memset(entry, 0, sizeof(entry));
  for (uint32_t pc = 0; pc < parsed_len; pc++) {
    re_inst in = c->pat->code[pc];
    uint16_t k;
    if (in.op != RE_SAVE || (in.offset & 1)) continue;
    k = in.offset / 2;
    if (!((called >> k) & 1)) continue;
    /* This copy's close: spans of one group never nest, so the next close
       slot of the same group is this copy's. */
    uint32_t close = pc + 1;
    while (close < parsed_len &&
           !(c->pat->code[close].op == RE_SAVE &&
             c->pat->code[close].offset == (uint16_t)(k * 2 + 1))) {
      close++;
    }
    mrb_assert(close < parsed_len);
    {
      uint32_t tramp = c->code_len;
      emit(c, RE_CALL, (uint8_t)k, 0);  /* the entry index lands below */
      emit(c, RE_JMP, 0, (uint16_t)(close + 1));
      c->pat->code[pc].op = RE_JMP;
      c->pat->code[pc].a = 0;
      c->pat->code[pc].offset = (uint16_t)tramp;
      c->pat->code[close].op = RE_RETURN;
      c->pat->code[close].a = (uint8_t)k;
      c->pat->code[close].offset = 0;
      if (entry[k] == 0) entry[k] = pc + 1;  /* never 0: pc 0 is group 0's open */
    }
  }

  /* Point every call, the trampolines' own included, at the body it runs. */
  for (uint32_t pc = 0; pc < c->code_len; pc++) {
    if (c->pat->code[pc].op != RE_CALL) continue;
    mrb_assert(entry[c->pat->code[pc].a] != 0);
    c->pat->code[pc].offset = (uint16_t)entry[c->pat->code[pc].a];
  }

  never_ending_check(c, called, entry);
  measure_deferred_lookbehinds(c);
}

void
mrb_re_compile(mrb_state *mrb, mrb_regexp_pattern *pat,
               const char *pattern, mrb_int len, uint32_t flags,
               mrb_bool binary)
{
  re_compiler c;
  memset(&c, 0, sizeof(c));

  c.binary = binary;
  c.mrb = mrb;
  c.pat = pat;
  c.orig = pattern;
  c.orig_end = pattern + len;
  c.pending_calls = mrb_nil_value();  /* a zero fill is not a nil mrb_value */
  c.level_store = mrb_nil_value();
  c.levels = c.levels_inline;
  c.level_capa = RE_LEVELS_INLINE;
  c.class_level_store = mrb_nil_value();
  c.class_levels = c.class_levels_inline;
  c.class_level_capa = RE_CLASS_LEVELS_INLINE;

  /* Both things the pre-pass removes, a (?#...) group and a `#` comment,
     are spelled with a '#', so a pattern without one is parsed as written.
     A '#' that is escaped or a class member is a false positive here, which
     costs the pass and nothing else: the pass steps over both. */
  if (memchr(pattern, '#', (size_t)len)) {
    mrb_int slen;
    pattern = preprocess_pattern(mrb, pattern, len,
                                 (flags & RE_FLAG_EXTENDED) != 0, &slen);
    len = slen;
  }
  c.src = pattern;
  c.src_end = pattern + len;
  c.p = pattern;
  c.flags = flags;
  c.orig_flags = flags;
  c.num_captures = 1;  /* group 0 = whole match */
  /* Scan the same bytes the parser is about to read: preprocess_pattern() has
     already taken out the #comments and the (?#...) groups. */
  c.dont_capture = has_named_group(pattern, len);

  pat->flags = flags;

  /* group 0 start */
  emit(&c, RE_SAVE, 0, 0);

  compile_levels(&c);

  if (c.p < c.src_end) {
    compile_error(&c, "unmatched close parenthesis");
  }

  /* A backreference names a group the pattern does not have. The count is
     taken here rather than where the reference stands because a reference may
     be written before the group it names, `\1(a)` being valid in CRuby, and
     it is taken once for both spellings so `\1` and `\k<1>` agree on which
     references a pattern accepts. */
  if (c.max_backref > c.num_groups) {
    compile_error(&c, "invalid backref number/name");
  }

  /* \K: its slots are the pair after the last group, known only now that
     every group is counted (at most RE_MAX_CAPTURES, so the pair still fits
     the array re_exec_attempt() searches into); a quantifier that copied
     one copied the placeholder too. A group a \g call runs again may hold the \K, and
     whether its position then counts is CRuby's question this does not
     answer, so the two are not taken together. */
  if (c.has_keep) {
    if (c.has_call) compile_error(&c, "\\K in a pattern that calls a group (\\g) is not supported");
    for (uint32_t i = 0; i < c.code_len; i++) {
      if (pat->code[i].op == RE_SAVE && pat->code[i].offset == RE_KEEP_PENDING)
        pat->code[i].offset = (uint16_t)(c.num_captures * 2);
    }
    pat->keep_slot = (uint16_t)(c.num_captures * 2);
  }

  /* group 0 end */
  emit(&c, RE_SAVE, 0, 1);
  emit(&c, RE_MATCH, 0, 0);

  /* A pattern with \g in it is finished by resolve_calls(), which appends
     the trampolines after the RE_MATCH just emitted; see there. */
  if (c.has_call) resolve_calls(&c);

  /* code_len is the last field written, at the end of this function: the
     Regexp has been holding this pattern since before the compile started,
     and a non-zero code_len is what tells the rest of the gem that what it
     holds can be run (see re_uninitialized_p()). Everything below reads the
     local instead. */
  uint32_t code_len = c.code_len;
  pat->num_captures = c.num_captures;
  pat->num_named = c.num_named;

  /* Copy capture names into an owned arena. Until this point the names point
     into the pattern source, or into the preprocessed copy of it, which the
     GC arena owns and drops once this frame is gone. After this loop the
     regexp owns its names. */
  if (c.num_named > 0) {
    size_t total = 0;
    for (uint16_t i = 0; i < c.num_named; i++) total += pat->named_captures[i].name_len;
    /* total is zero only when every registered name is empty, which the
       parser rejects, so today the arena is always taken. Allocate a byte
       for that case anyway rather than skipping the copy: skipping it leaves
       name borrowing memory the pattern does not own, and nulling name
       instead would hand a NULL to the memcmp() in matchdata_name_to_group(),
       which is declared nonnull even for a zero length. */
    pat->named_arena = (char*)mrb_malloc(mrb, total ? total : 1);
    size_t off = 0;
    for (uint16_t i = 0; i < c.num_named; i++) {
      uint32_t n = pat->named_captures[i].name_len;
      memcpy(pat->named_arena + off, pat->named_captures[i].name, n);
      pat->named_captures[i].name = pat->named_arena + off;
      off += n;
    }
  }
  pat->has_backref = c.has_backref;
  pat->needs_backtrack = c.needs_backtrack;

  /* The anchor every branch asserts before consuming input, if any: the
     engines then scan only the positions it can pass (line starts for ^, the
     string start alone for \A) instead of proposing every position; see
     skip_to_line_start(). Under \A the string is never scanned at all, which
     is why a pattern carrying it leaves the prefix and the first-byte set
     below unbuilt: they exist to move a scan along, and there is none. */
  pat->anchor = compute_anchor(mrb, pat->code, code_len);

  /* Extract literal prefix for fast search skip.
     Walk bytecode from the start, skipping zero-width instructions,
     collecting RE_CHAR. A zero-width test consumes nothing, so the literal
     bytes after it still begin at the position a match would start at; the
     skip only proposes candidate positions, and the engine still runs the
     test there. */
  pat->prefix = NULL;
  pat->prefix_len = 0;
  if (pat->anchor != RE_ANCHOR_BOT) {
    uint8_t pbuf[256];
    int plen = 0;
    for (uint32_t i = 0; i < code_len && plen < 255; i++) {
      uint8_t op = pat->code[i].op;
      if (op == RE_SAVE ||
          op == RE_BOL || op == RE_EOL || op == RE_BOT || op == RE_EOT || op == RE_GPOS ||
          op == RE_EOTNL || op == RE_WBOUND || op == RE_NWBOUND) {
        continue;
      }
      if (op == RE_CHAR) {
        pbuf[plen++] = pat->code[i].a;
        continue;
      }
      break;
    }
    if (plen > 0) {
      pat->prefix = (uint8_t*)mrb_malloc(mrb, plen);
      memcpy(pat->prefix, pbuf, plen);
      pat->prefix_len = (uint8_t)plen;
    }
  }

  /* Check if pattern is pure literal: SAVE CHAR* SAVE MATCH only.
     prefix_len already holds the literal char count if so. */
  pat->is_literal = FALSE;
  if (pat->prefix_len > 0 && pat->num_captures == 1 &&
      !pat->has_backref && !pat->needs_backtrack) {
    /* bytecode should be: SAVE(0), CHAR*N, SAVE(1), MATCH
       = 2 + prefix_len + 2 = prefix_len + 2 instructions
       (SAVE(0) at 0, CHARs at 1..N, SAVE(1) at N+1, MATCH at N+2) */
    if (code_len == (uint32_t)(pat->prefix_len + 3) &&
        pat->code[0].op == RE_SAVE &&
        pat->code[code_len - 2].op == RE_SAVE &&
        pat->code[code_len - 1].op == RE_MATCH) {
      pat->is_literal = TRUE;
    }
  }

  /* Compute first-byte bitmap: set of bytes that could start a match.
     Used when prefix is empty (e.g. alternation, character class patterns). */
  pat->has_first_bytes = FALSE;
  if (pat->anchor != RE_ANCHOR_BOT) {
    uint8_t bm[32];
    memset(bm, 0, sizeof(bm));
    pat->has_first_bytes = compute_first_set(mrb, pat->code, code_len,
                                             pat->classes, bm);
    if (pat->has_first_bytes) {
      memcpy(pat->first_bytes, bm, sizeof(bm));
      /* A set of up to three bytes is also kept enumerated, so the skip can
         ask memchr for each member instead of walking the subject a byte at
         a time; see skip_to_first_byte(). Three covers the common shapes: an
         alternation on one letter is one byte, a case-folded letter under /i
         is two, and three with the lead of a counterpart outside ASCII ('k'
         and U+212A KELVIN SIGN). */
      int n = 0;
      for (int b = 0; b < 256; b++) {
        if (bm[b >> 3] & (1 << (b & 7))) {
          if (n == 3) { n = 0; break; }
          pat->first_byte[n++] = (uint8_t)b;
        }
      }
      pat->first_byte_count = (uint8_t)n;
    }
  }

  pat->loop_depth = mark_empty_loops(mrb, pat->code, code_len);

  /* Pre-allocate VM state cache for pike_vm */
  {
    int list_capa = RE_LIST_CAPA(code_len, pat->loop_depth);
    pat->cached_visited = (uint32_t*)mrb_calloc(mrb, code_len + 1, sizeof(uint32_t));
    pat->cached_threads[0] = mrb_malloc(mrb, sizeof(re_thread_cache) * list_capa);
    pat->cached_threads[1] = mrb_malloc(mrb, sizeof(re_thread_cache) * list_capa);
    pat->cached_list_capa = list_capa;
    pat->cache_in_use = FALSE;
  }

  /* Nothing above allocates any more, so the pattern is complete: publish
     the length that says so. */
  pat->code_len = code_len;
}

void
mrb_re_free(mrb_state *mrb, mrb_regexp_pattern *pat)
{
  if (pat) {
    mrb_free(mrb, pat->code);
    if (pat->classes) {
      for (uint16_t i = 0; i < pat->num_classes; i++) {
        mrb_free(mrb, pat->classes[i].ranges);
      }
      mrb_free(mrb, pat->classes);
    }
    mrb_free(mrb, pat->named_captures);
    mrb_free(mrb, pat->named_arena);
    mrb_free(mrb, pat->prefix);
    mrb_free(mrb, pat->cached_visited);
    mrb_free(mrb, pat->cached_threads[0]);
    mrb_free(mrb, pat->cached_threads[1]);
    mrb_free(mrb, pat);
  }
}
