/* Cold, out-of-line helpers extracted from spinel_rt.h.
 *
 * Functions that are large and not on any hot path were `static` in
 * spinel_rt.h, so every translation unit that includes the header (every
 * generated program, plus each lib TU) compiled its own copy. Moving them here
 * -- a single TU that includes the full runtime header -- gives one linked copy
 * and shrinks per-TU compile work. spinel_rt.h keeps an `extern` declaration
 * so all callers still resolve. Only functions that call no program-generated
 * static (sp_sym_to_s / sp_sym_intern / ...) can live here, and each includes
 * only the low-level headers its dependencies need -- NOT spinel_rt.h, which
 * is a monolithic definition header meant to be compiled once (into the
 * generated program), so including it here would multiply-define the runtime. */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE   /* statx / STATX_BTIME for File.birthtime on Linux */
#endif
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>   /* sp_sprintf */
#include <unistd.h>
#include "sp_alloc.h"   /* sp_str_alloc / sp_str_set_len / sp_raise_cls */
#include "sp_array.h"   /* sp_StrArray for Dir.glob */
#include <dirent.h>
#if defined(_WIN32)
#include <spawn.h>
#endif
#include <fnmatch.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/resource.h>   /* getpriority for Process.getpriority */
#include <fcntl.h>      /* AT_FDCWD for statx */
#include <errno.h>
#include "sp_time.h"   /* sp_Time for File.mtime */
#include "sp_io.h"     /* sp_file_directory prototype */
#include "sp_str.h"
#include "sp_string.h"
#include "sp_system.h" /* sp_last_status for backtick */
#include "sp_format.h" /* sp_float_to_rational for sp_float_denominator/numerator */
#include <sys/select.h>  /* IO.select and the IO#wait_* readiness family */
#include <poll.h>        /* POLLIN/POLLOUT for the scheduler park behind them */
#include <sys/socket.h> /* SOCK_STREAM / SOCK_DGRAM for Addrinfo */

/* lib/sp_gc.c. Declared here rather than in sp_gc.h: that header is included
   by every generated TU, so adding to it recompiles the whole suite. */
extern int sp_gc_full_runs;
extern int sp_gc_rem_peak;   /* lib/sp_gc.c: high-water mark of the remembered set */

/* execinfo.h (backtrace_symbols) is a glibc/Apple extension; not all libc
   implementations ship it. Detect availability by the toolchain macros so we
   can guard the header inclusion. Where it is missing we still provide
   no-op struct/macro shims below so the backtrace code compiles unchanged. */
#if defined(__has_include)
#  if __has_include(<execinfo.h>)
#    define HAVE_EXECINFO_H 1
#  endif
#elif defined(__GLIBC__) || defined(__APPLE__) || defined(__FreeBSD__)
#  define HAVE_EXECINFO_H 1
#endif

/* printf into a fresh heap string: the error-message and interpolation
   formatter every runtime TU and the generated program call. */
const char*sp_sprintf(const char*fmt,...){char _sp_tmp[4096];va_list ap;va_start(ap,fmt);int _sp_n=vsnprintf(_sp_tmp,sizeof(_sp_tmp),fmt,ap);va_end(ap);if(_sp_n<0)_sp_n=0;char*b=sp_str_alloc((size_t)_sp_n);if(_sp_n<(int)sizeof(_sp_tmp)){memcpy(b,_sp_tmp,(size_t)_sp_n);}
else{/* result didn't fit the stack temp; re-render at full width (sp_str_alloc gives _sp_n bytes + NUL) so long string interpolations aren't truncated. re-arm the va_list rather than va_copy so the common fast path pays nothing */va_start(ap,fmt);vsnprintf(b,(size_t)_sp_n+1,fmt,ap);va_end(ap);}return b;}

/* Integer#% / Kernel#format "%b"/"%B"/"%o"/"%x"/"%X": non-decimal formatting
   with Ruby's flag, width, precision, and two's-complement-for-negative rules.
   C's printf drops the '+' and ' ' flags on these conversions and has no
   two's-complement form, so none of it can be delegated to libc. */
int sp_fmt_binary(const char *spec, size_t sl, char conv, long long val,
                  char *out, size_t osz) {
  int base = (conv == 'o') ? 8 : (conv == 'x' || conv == 'X') ? 16 : 2;
  int upper = (conv == 'X' || conv == 'B');
  char topd = (char)(base == 8 ? '7' : base == 2 ? '1' : (upper ? 'F' : 'f'));
  /* parse "%<flags><width>.<prec>b" out of spec[0..sl-1] (spec[sl-1] == conv) */
  int f_minus = 0, f_plus = 0, f_space = 0, f_hash = 0, f_zero = 0;
  size_t i = 1;
  for (; i < sl; i++) {
    if (spec[i] == '-') f_minus = 1;
    else if (spec[i] == '+') f_plus = 1;
    else if (spec[i] == ' ') f_space = 1;
    else if (spec[i] == '#') f_hash = 1;
    else if (spec[i] == '0') f_zero = 1;
    else break;
  }
  int width = 0;
  for (; i < sl && spec[i] >= '0' && spec[i] <= '9'; i++) width = (width * 10) + (spec[i] - '0');
  int prec = -1;
  if (i < sl && spec[i] == '.') {
    i++; prec = 0;
    for (; i < sl && spec[i] >= '0' && spec[i] <= '9'; i++) prec = (prec * 10) + (spec[i] - '0');
  }

  int neg = val < 0;
  /* Ruby shows the two's-complement ".." body only for a negative value with no
     sign flag; a + or space flag switches to signed magnitude ("-101"). */
  int twos = neg && !f_plus && !f_space;
  char digits[256]; int dn = 0;
  if (twos) {
    /* the digits that differ from the infinite run of sign digits, plus one
       leading sign digit: -255 in base 16 is "..f01" */
    char t[80]; int tn = 0;
    long long w = val;
    while (w != -1 && tn < (int)sizeof t) {
      long long d = w % base;
      if (d < 0) d += base;
      t[tn++] = (char)(d < 10 ? '0' + d : (upper ? 'A' : 'a') + (d - 10));
      w = (w - d) / base;
    }
    digits[dn++] = topd;
    while (tn) digits[dn++] = t[--tn];
  }
  else {
    /* signed magnitude: |val| in the base. 0 has no significant digits, so it
       contributes a single '0' only when precision is not 0. */
    unsigned long long mag = neg ? (unsigned long long)(-(val + 1)) + 1 : (unsigned long long)val;
    if (mag == 0) { if (prec != 0) digits[dn++] = '0'; }
    else { char t[80]; int tn = 0;
           while (mag) { int d = (int)(mag % (unsigned)base);
                         t[tn++] = (char)(d < 10 ? '0' + d : (upper ? 'A' : 'a') + (d - 10));
                         mag /= (unsigned)base; }
           while (tn) digits[dn++] = t[--tn]; }
  }
  /* precision: minimum digit count. The ".." body counts as 2 toward it and pads
     with sign digits; signed magnitude pads with 0. */
  if (prec >= 0) {
    int target = twos ? (prec - 2) : prec;
    char padc = twos ? topd : '0';
    int t2 = target - dn;
    if (t2 > 0) {
      /* clamp to the digits buffer (output is capped at osz anyway) */
      if (t2 + dn >= (int)sizeof(digits)) t2 = (int)sizeof(digits) - dn - 1;
      memmove(digits + t2, digits, (size_t)dn);  /* shift body right */
      memset(digits, padc, (size_t)t2);           /* leading padding */
      dn += t2;
    }
    f_zero = 0;  /* precision disables 0-flag for integer conversions */
  }
  /* assemble sign/prefix + body, then apply width padding */
  char body[300]; int bn = 0;
  char sign = twos ? 0 : (neg ? '-' : (f_plus ? '+' : (f_space ? ' ' : 0)));
  char prefix0 = 0, prefix1 = 0;
  if (f_hash && base == 8) {
    /* octal's alternate form has no letter: it just guarantees a leading 0,
       so it adds nothing to a body that already starts with one (and nothing
       at all to the two's-complement form, where a 0 would misread) */
    if (!twos) {
      if (dn == 0) digits[dn++] = '0';
      else if (digits[0] != '0') prefix0 = '0';
    }
  }
  else if (f_hash && val != 0) {
    prefix0 = '0';
    prefix1 = (base == 2) ? (upper ? 'B' : 'b') : (upper ? 'X' : 'x');
  }
  if (sign) body[bn++] = sign;
  if (prefix0) { body[bn++] = prefix0; if (prefix1) body[bn++] = prefix1; }
  if (twos) { body[bn++] = '.'; body[bn++] = '.'; }
  for (int k = 0; k < dn; k++) body[bn++] = digits[k];

  int o = 0;
  int pad = width - bn;
  if (pad > 0 && !f_minus && f_zero) {
    /* zero-pad: emit sign/prefix/".." first, then fill, then the rest. A two's-
       complement body fills with the sign bit (1); signed magnitude with 0. */
    int head = (sign ? 1 : 0) + (prefix0 ? (prefix1 ? 2 : 1) : 0) + (twos ? 2 : 0);
    char fillc = twos ? topd : '0';
    for (int k = 0; k < head && o < (int)osz; k++) out[o++] = body[k];
    for (int k = 0; k < pad && o < (int)osz; k++) out[o++] = fillc;
    for (int k = head; k < bn && o < (int)osz; k++) out[o++] = body[k];
  }
  else {
    if (pad > 0 && !f_minus) for (int k = 0; k < pad && o < (int)osz; k++) out[o++] = ' ';
    for (int k = 0; k < bn && o < (int)osz; k++) out[o++] = body[k];
    if (pad > 0 && f_minus) for (int k = 0; k < pad && o < (int)osz; k++) out[o++] = ' ';
  }
  return o;
}

/* File.expand_path(path[, base]): absolute, `.`/`..`/`//`-normalized path.
   Depends only on sp_alloc.h + libc; no program-generated symbols. */
const char *sp_file_expand_path(const char *path, const char *base) {
  char raw[8192];
  char cwd[4096];
  const char *home = getenv("HOME");
#if defined(_WIN32)
  /* Windows: a backslash separates too, and the answer spells it as a
     slash, as CRuby's does; the home is %USERPROFILE% when HOME is unset */
  char pbuf[4096], bbuf[4096], hbuf[4096];
  if (!home) home = getenv("USERPROFILE");
  if (home) { snprintf(hbuf, sizeof hbuf, "%s", home); for (char *c = hbuf; *c; c++) if (*c == '\\') *c = '/'; home = hbuf; }
  if (path) { snprintf(pbuf, sizeof pbuf, "%s", path); for (char *c = pbuf; *c; c++) if (*c == '\\') *c = '/'; path = pbuf; }
  if (base) { snprintf(bbuf, sizeof bbuf, "%s", base); for (char *c = bbuf; *c; c++) if (*c == '\\') *c = '/'; base = bbuf; }
#endif
  if (!home) home = "";
  if (!path) path = "";

  /* The `%.4000s` precision caps each component so the compiler can
     prove the combined output (<= 8001) fits in the 8192 buffer -- this
     silences -Wformat-truncation (an error under the test harness's
     -Werror). 4000 chars/component is well past PATH_MAX, so real paths
     never truncate. */
  if (path[0] == '~' && (path[1] == '\0' || path[1] == '/')) {
    snprintf(raw, sizeof(raw), "%.4000s%.4000s", home, path + 1);
  }
#if defined(_WIN32)
  else if (sp_file_path_root_len(path)) {   /* "/", or a drive's "C:/" */
#else
  else if (path[0] == '/') {
#endif
    snprintf(raw, sizeof(raw), "%.4000s", path);
  }
  else {
    char basebuf[8192];
    const char *b;
    if (base && base[0]) {
      if (base[0] == '~' && (base[1] == '\0' || base[1] == '/')) {
        snprintf(basebuf, sizeof(basebuf), "%.4000s%.4000s", home, base + 1);
        b = basebuf;
      }
#if defined(_WIN32)
      else if (sp_file_path_root_len(base)) {
#else
      else if (base[0] == '/') {
#endif
        b = base;
      }
      else {
        if (!getcwd(cwd, sizeof(cwd))) cwd[0] = 0;
        snprintf(basebuf, sizeof(basebuf), "%.4000s/%.4000s", cwd, base);
        b = basebuf;
      }
    }
    else {
      if (!getcwd(cwd, sizeof(cwd))) cwd[0] = 0;
      b = cwd;
    }
    snprintf(raw, sizeof(raw), "%.4000s/%.4000s", b, path);
  }

  /* Normalize: walk segments, collapsing `.`/`..`/`//`. seg_start[k]
     records the output length to roll back to when a `..` pops the
     k-th kept segment. */
#if defined(_WIN32)
  /* "/x" is the current drive's: Windows has no root above the drives */
  if (raw[0] == '/' && raw[1] != '/') {
    char drv[4096];
    if (getcwd(drv, sizeof drv) && sp_file_path_root_len(drv) == 3) {
      char t[8192];
      snprintf(t, sizeof t, "%c:%.8000s", drv[0], raw);
      snprintf(raw, sizeof raw, "%s", t);
    }
  }
#endif
  size_t rawlen = strlen(raw);
  char *out = sp_str_alloc(rawlen + 1);
  size_t seg_start[1024];
  int nseg = 0;
  size_t olen = 0;
#if defined(_WIN32)
  /* a drive's root ("C:/") as it is, then the segments */
  size_t rootn = sp_file_path_root_len(raw);
  if (rootn > 1) { memcpy(out, raw, rootn - 1); olen = rootn - 1; }
  out[olen++] = '/';
  size_t root_end = olen;
  const char *p = raw + rootn;
#else
  out[olen++] = '/';
  const char *p = raw;
#endif
  while (*p) {
    if (*p == '/') { p++; continue; }
    const char *q = p;
    while (*q && *q != '/') q++;
    size_t slen = (size_t)(q - p);
    if (slen == 1 && p[0] == '.') {
      /* current dir -- skip */
    }
    else if (slen == 2 && p[0] == '.' && p[1] == '.') {
      if (nseg > 0) { nseg--; olen = seg_start[nseg]; }
    }
    else {
      size_t mark = olen;
#if defined(_WIN32)
      if (olen > root_end) out[olen++] = '/';
#else
      if (olen > 1) out[olen++] = '/';
#endif
      memcpy(out + olen, p, slen);
      olen += slen;
      if (nseg < 1024) seg_start[nseg++] = mark;
    }
    p = q;
  }
  out[olen] = 0;
  sp_str_set_len(out, olen);
  return out;
}

/* File.readlink(path): the symlink target as a fresh spinel string (#3005) */
const char *sp_file_readlink(const char *path) {SP_GC_ROOT_STR(path);
  char buf[4096];
  ssize_t n = readlink(path ? path : "", buf, sizeof(buf) - 1);
  if (n < 0) {
    sp_raise_cls(errno == ENOENT ? "Errno::ENOENT" :
                 errno == EINVAL ? "Errno::EINVAL" : "SystemCallError",
                 sp_sprintf("%s @ readlink - %s", strerror(errno), path ? path : ""));
    return "";
  }
  char *out = sp_str_alloc((size_t)n + 1);
  memcpy(out, buf, (size_t)n);
  out[n] = 0;
  sp_str_set_len(out, (size_t)n);
  return out;
}

/* ---- String#to_c parse + Dir.glob (cold; moved from spinel_rt.h) ---- */

/* `exception: false` asks Kernel#Complex / #Rational for nil rather than a
   raise on an unparseable String. The parsers below set this instead of
   raising while it is on; the caller reads it back and answers nil (#3893). */
sp_bool sp_convert_soft = 0;
sp_bool sp_convert_failed = 0;
/* A rational-syntax denominator written as digits that reads zero raises
   ZeroDivisionError, as CRuby's does, with `exception: false` too. The raise
   leaves the parse before its caller clears sp_convert_soft, so it is
   cleared here first. */
static void sp_str_to_c_zero_den(const char *dp, double d) {
  if (d == 0.0 && *dp >= '0' && *dp <= '9') {
    sp_convert_soft = 0;
    sp_raise_cls("ZeroDivisionError", "divided by 0");
  }
}
static sp_Complex sp_str_to_c_impl(const char *s, int strict) {
  double re = 0, im = 0;
  int parsed = 0;
  const char *fin = s;   /* first byte NOT consumed by the parse */
  if (s) {
    const char *p = s;
    while (*p == ' ' || *p == '\t') p++;
    char *end = NULL;
    double a = strtod(p, &end);
    if (end != p) {
      parsed = 1;
      /* rational-syntax component "n/d" */
      if (*end == '/') { const char *dp = end + 1; char *de = NULL; double d = strtod(dp, &de); if (de != dp) { sp_str_to_c_zero_den(dp, d); a /= d; end = de; } }
      if (*end == 'i') { im = a; fin = end + 1; }
      else {
        re = a;
        const char *q = end;
        double b2 = strtod(q, &end);
        if (end != q) {
          if (*end == '/') { const char *dp = end + 1; char *de = NULL; double d = strtod(dp, &de); if (de != dp) { sp_str_to_c_zero_den(dp, d); b2 /= d; end = de; } }
          if (*end == 'i') { im = b2; fin = end + 1; }
          else fin = q;   /* an imaginary number without the 'i' suffix ("1+2") is invalid */
        }
        else if ((*q == '+' || *q == '-') && q[1] == 'i') { im = (*q == '-') ? -1.0 : 1.0; fin = q + 2; }
        else fin = q;        /* "1+" and other incomplete forms leave the operator unconsumed */
      }
    }
    else if (*p == 'i') { im = 1; parsed = 1; fin = p + 1; }
    else if ((*p == '+' || *p == '-') && p[1] == 'i') { im = (*p == '-') ? -1.0 : 1.0; parsed = 1; fin = p + 2; }
  }
  /* Kernel#Complex(str) must consume the whole string (only trailing
     whitespace allowed): an incomplete form like "1+" is invalid, not silently
     (1+0i) (#2617). String#to_c does the opposite -- it reads a leading
     complex and ignores the rest, and answers (0+0i) when nothing parses.
     String#to_r has had that pair (sp_str_to_r / sp_str_to_r_strict) all
     along; to_c had only the strict half, and #to_c was pointed at it, so
     `"abc".to_c` raised where CRuby answers (0+0i). */
  if (parsed && strict) { while (*fin == ' ' || *fin == '\t') fin++; if (*fin != '\0') parsed = 0; }
  if (!parsed) {
    if (!strict) return (sp_Complex){ 0.0, 0.0 };
    if (sp_convert_soft) { sp_convert_failed = 1; return (sp_Complex){ 0.0, 0.0 }; }
    sp_raise_cls("ArgumentError", sp_sprintf("invalid value for convert(): \"%s\"", s ? s : ""));
  }
  return (sp_Complex){ (sp_float)re, (sp_float)im };
}
/* String#to_c: a leading complex, the rest ignored, (0+0i) when none. */
sp_Complex sp_str_to_c(const char *s) { return sp_str_to_c_impl(s, 0); }
/* Kernel#Complex(String): the whole string or an ArgumentError. */
sp_Complex sp_str_to_c_strict(const char *s) { return sp_str_to_c_impl(s, 1); }

/* FNM_DOTMATCH mode for the walk below: hidden entries (and ".") match a
   non-dot pattern; ".." never does, as CRuby's glob. Set by the _dot wrapper. */
static int sp_glob_dotmatch = 0;
/* A glob walk holds open directories and brace buffers (as File.fnmatch's
   FNM_EXTGLOB holds the latter), so the matcher's ArgumentError waits until
   they are let go: under sp_glob_defer
   it sets sp_glob_bad and fails the match, the walk stops, and
   sp_glob_finish raises. */
static int sp_glob_defer = 0, sp_glob_bad = 0;

int sp_fnmatch1(const char *pat, const char *str) {
  while (*pat) {
    if (*pat == '*') {
      pat++;
      if (!*pat) return 1;
      while (*str) { if (sp_fnmatch1(pat, str)) return 1; str++; }
      return sp_fnmatch1(pat, str);
    }
else if (*pat == '?') {
      if (!*str) return 0;
      pat++; str++;
    }
else {
      if (*pat != *str) return 0;
      pat++; str++;
    }
  }
  return *str == 0;
}

/* File.fnmatch, by CRuby's rules rather than the system fnmatch's. The flags
   are CRuby's values (File::FNM_NOESCAPE 1, FNM_PATHNAME 2, FNM_DOTMATCH 4,
   FNM_CASEFOLD 8, FNM_EXTGLOB 16). With no flags a wildcard crosses "/", and
   only a period that starts the whole string has to be matched by one in
   the pattern; FNM_PATHNAME keeps wildcards inside one component, holds
   every component's leading period to that rule, and lets "**" + "/" match
   any number of directories. Case folding is ASCII only, as CRuby's
   rb_enc_toupper is. A character is one valid UTF-8 sequence, so "?" takes
   "é" whole; an invalid byte is a character of its own, which a range
   refuses with ArgumentError, as CRuby's does. */
/* The length of the character at s: a valid UTF-8 sequence whole, any
   other byte (a stray continuation, an overlong or surrogate form, a lead
   byte past U+10FFFF) alone, as CRuby's precise length counts it. Answers a
   negative length for such a byte, which never matches literally. */
static int sp_fnm_clen_v(const char *s, int *valid) {
  const unsigned char *u = (const unsigned char *)s;
  int n = u[0] < 0x80 ? 1 : (u[0] >= 0xc2 && u[0] <= 0xdf) ? 2 : (u[0] >= 0xe0 && u[0] <= 0xef) ? 3 :
          (u[0] >= 0xf0 && u[0] <= 0xf4) ? 4 : 0;
  int ok = n > 0;
  for (int i = 1; ok && i < n; i++) if ((u[i] & 0xc0) != 0x80) ok = 0;
  if (ok && n == 3 && ((u[0] == 0xe0 && u[1] < 0xa0) || (u[0] == 0xed && u[1] >= 0xa0))) ok = 0;
  if (ok && n == 4 && ((u[0] == 0xf0 && u[1] < 0x90) || (u[0] == 0xf4 && u[1] >= 0x90))) ok = 0;
  if (valid) *valid = ok;
  return ok ? n : 1;
}
static int sp_fnm_clen(const char *s) { return sp_fnm_clen_v(s, NULL); }
static unsigned int sp_fnm_code(const char *s, int nocase) {
  unsigned char c = (unsigned char)*s;
  int n = sp_fnm_clen(s);
  unsigned int cp = n == 1 ? c : n == 2 ? (c & 0x1f) : n == 3 ? (c & 0x0f) : (c & 0x07);
  for (int i = 1; i < n; i++) cp = (cp << 6) | ((unsigned char)s[i] & 0x3f);
  if (nocase && cp >= 'a' && cp <= 'z') cp -= 'a' - 'A';
  return cp;
}
/* "[...]" against the character at s; p is past the "[". Answers the pattern
   past the "]" on a match, NULL otherwise or when the class never closes. */
static const char *sp_fnm_bracket(const char *p, const char *s, int flags) {
  const int nocase = flags & SP_FNM_CASEFOLD, escape = !(flags & SP_FNM_NOESCAPE);
  int ok = 0, neg = 0;
  if (*p == '!' || *p == '^') { neg = 1; p++; }
  int sv = 0;
  (void)sp_fnm_clen_v(s, &sv);
  unsigned int c = sp_fnm_code(s, nocase);
  while (*p != ']') {
    const char *t1 = p;
    if (escape && *t1 == '\\') t1++;
    if (!*t1) return NULL;
    p = t1 + sp_fnm_clen(t1);
    if (!*p) return NULL;
    if (p[0] == '-' && p[1] != ']') {
      const char *t2 = p + 1;
      if (escape && *t2 == '\\') t2++;
      if (!*t2) return NULL;
      p = t2 + sp_fnm_clen(t2);
      if (ok) continue;
      /* an endpoint is a match whatever the order, as CRuby's byte compare
         makes it: "[z-a]" takes "z" */
      int l1 = sp_fnm_clen(t1), l2 = sp_fnm_clen(t2);
      if (strncmp(t1, s, (size_t)l1) == 0 || strncmp(t2, s, (size_t)l2) == 0) { ok = 1; continue; }
      /* a range reads the character as a code point, which an invalid
         byte has none of: CRuby's ArgumentError */
      if (!sv) {
        if (sp_glob_defer) { sp_glob_bad = 1; return NULL; }
        sp_raise_cls("ArgumentError", (&("\xff" "invalid byte sequence in UTF-8")[1]));
      }
      if (c >= sp_fnm_code(t1, nocase) && c <= sp_fnm_code(t2, nocase)) ok = 1;
    }
    else if (!ok) {
      int l1 = sp_fnm_clen(t1);
      if (strncmp(t1, s, (size_t)l1) == 0) ok = 1;
      /* CRuby folds a lone member against the character AFTER it (p, not
         t1), so under FNM_CASEFOLD "[ab]" takes "B" and not "A", and "[a]"
         takes neither; kept as CRuby answers it */
      else if (nocase && sv && c == sp_fnm_code(p, 1)) ok = 1;
    }
  }
  return ok == neg ? NULL : p + 1;
}
/* One component (or, without FNM_PATHNAME, the whole string): CRuby's
   fnmatch_helper. Leaves *pcur/*scur where the match stopped. */
static int sp_fnm_helper(const char **pcur, const char **scur, int flags) {
  const int period = !(flags & SP_FNM_DOTMATCH), pathname = flags & SP_FNM_PATHNAME;
  const int escape = !(flags & SP_FNM_NOESCAPE), nocase = flags & SP_FNM_CASEFOLD;
  const char *ptmp = NULL, *stmp = NULL;
  const char *p = *pcur, *s = *scur;
#define SP_FNM_UNESC(q) ((escape && *(q) == '\\') ? (q) + 1 : (q))
#define SP_FNM_END(q) (!*(q) || (pathname && *(q) == '/'))
#define SP_FNM_RET(v) do { *pcur = p; *scur = s; return (v); } while (0)
  if (period && *s == '.' && *SP_FNM_UNESC(p) != '.') SP_FNM_RET(0);
  for (;;) {
    if (*p == '*') {
      do { p++; } while (*p == '*');
      if (SP_FNM_END(SP_FNM_UNESC(p))) { p = SP_FNM_UNESC(p); SP_FNM_RET(1); }
      if (SP_FNM_END(s)) SP_FNM_RET(0);
      ptmp = p; stmp = s;
      continue;
    }
    if (*p == '?') {
      if (SP_FNM_END(s)) SP_FNM_RET(0);
      p++; s += sp_fnm_clen(s);
      continue;
    }
    if (*p == '[') {
      if (SP_FNM_END(s)) SP_FNM_RET(0);
      const char *t = sp_fnm_bracket(p + 1, s, flags);
      if (t) { p = t; s += sp_fnm_clen(s); continue; }
      goto failed;
    }
    p = SP_FNM_UNESC(p);
    if (SP_FNM_END(s)) SP_FNM_RET(SP_FNM_END(p));
    if (SP_FNM_END(p)) goto failed;
    {
      int pv = 0, pl = sp_fnm_clen_v(p, &pv), sl = sp_fnm_clen(s);
      if (pv && pl == sl && (memcmp(p, s, (size_t)pl) == 0 ||
                       (nocase && sp_fnm_code(p, 1) == sp_fnm_code(s, 1)))) {
        p += pl; s += sl;
        continue;
      }
    }
  failed:
    if (ptmp && stmp) { p = ptmp; stmp += sp_fnm_clen(stmp); s = stmp; continue; }
    SP_FNM_RET(0);
  }
#undef SP_FNM_UNESC
#undef SP_FNM_END
#undef SP_FNM_RET
}
/* CRuby's fnmatch: component by component under FNM_PATHNAME, where a run
   of "**" + "/" retries the rest of the pattern at each later directory,
   never descending into a hidden one unless FNM_DOTMATCH. */
static int sp_fnm_match(const char *p, const char *s, int flags) {
  const int period = !(flags & SP_FNM_DOTMATCH);
  const char *ptmp = NULL, *stmp = NULL;
  if (!(flags & SP_FNM_PATHNAME)) return sp_fnm_helper(&p, &s, flags);
  for (;;) {
    if (p[0] == '*' && p[1] == '*' && p[2] == '/') {
      do { p += 3; } while (p[0] == '*' && p[1] == '*' && p[2] == '/');
      ptmp = p; stmp = s;
    }
    if (sp_fnm_helper(&p, &s, flags)) {
      while (*s && *s != '/') s += sp_fnm_clen(s);
      if (*p && *s) { p++; s++; continue; }
      if (!*p && !*s) return 1;
    }
    if (ptmp && stmp && !(period && *stmp == '.')) {
      while (*stmp && *stmp != '/') stmp += sp_fnm_clen(stmp);
      if (*stmp) { p = ptmp; stmp++; s = stmp; continue; }
    }
    return 0;
  }
}
/* One pattern COMPONENT against one directory entry name, by the matcher
   File.fnmatch answers with, so a character class, an escape or a
   multibyte character means the same thing in both (#4252). No
   FNM_PATHNAME: the component holds no separator by construction. A
   leading dot is hidden unless the pattern asks for one or the glob runs
   under FNM_DOTMATCH, which is CRuby's rule. */
static int sp_glob_comp_match(const char *comp, const char *name) {
  return sp_fnm_match(comp, name, sp_glob_dotmatch ? SP_FNM_DOTMATCH : 0);
}

static int sp_glob_has_meta(const char *comp) {
  for (const char *p = comp; *p; p++)
    if (*p == '*' || *p == '?' || *p == '[') return 1;
  return 0;
}

static void sp_glob_push(sp_StrArray *a, const char *path) {
  char *copy = sp_str_alloc(strlen(path));
  strcpy(copy, path);
  sp_StrArray_push(a, copy);
}

static int sp_glob_is_dir(const char *path) {
  struct stat st;
  return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

static int sp_glob_exists(const char *path) {
  struct stat st;
  return lstat(path, &st) == 0;
}

/* Walk the components from index `ci`. `fsdir` is the directory to read (""
   means the process's own), `outprefix` is what the answers are spelled with.
   Every component is handled the same way -- literal, metacharacter, or ** --
   which is what lets a wildcard sit anywhere rather than only last: the old
   walk split the pattern at its LAST slash and opendir'd the part before it, so
   a wildcard middle component opened a directory literally named with it,
   and found nothing. */
/* The separator between a directory the walk is in and a name under it, and
   the root an absolute pattern's walk starts from. On Windows a root is "/"
   or a drive's "C:/", and one that already ends in a separator takes none
   (the shim reads "//tmp" as a UNC name, not as /tmp). Elsewhere they spell
   exactly what the walk always wrote. */
#if defined(_WIN32)
static const char *sp_glob_sep(const char *fsdir) {
  size_t n = strlen(fsdir);
  return (n == 0 || fsdir[n - 1] == '/') ? "" : "/";
}
#define SP_GLOB_SEP(fsdir) sp_glob_sep(fsdir)
#define SP_GLOB_ROOT root
#else
#define SP_GLOB_SEP(fsdir) fsdir[0] ? "/" : ""
#define SP_GLOB_ROOT "/"
#endif

static void sp_glob_walk(const char *fsdir, const char *outprefix,
                         char **comps, int ncomp, int ci, sp_StrArray *a) {
  if (ci >= ncomp) return;
  const char *comp = comps[ci];
  int last = (ci == ncomp - 1);
  char fspath[2048], outpath[2048];

  /* A TRAILING double star is not recursive in CRuby: Dir.glob("a" + SEP +
     "**") answers what a single star answers, and only the form with a
     separator AFTER the stars descends. The recursion lives in that
     separator, not in the stars. */
  if (strcmp(comp, "**") == 0 && last) comp = "*";

  if (strcmp(comp, "**") == 0) {
    /* ** matches zero or more directories. Zero first: the rest of the pattern
       applies right here. */
    if (!last) sp_glob_walk(fsdir, outprefix, comps, ncomp, ci + 1, a);
    DIR *d = opendir(fsdir[0] ? fsdir : ".");
    if (!d) return;
    struct dirent *e;
    while (!sp_glob_bad && (e = readdir(d)) != NULL) {
      const char *name = e->d_name;
      if (name[0] == '.' && (name[1] == 0 || (name[1] == '.' && name[2] == 0))) continue;
      if (name[0] == '.' && !sp_glob_dotmatch) continue;
      snprintf(fspath, sizeof fspath, "%s%s%s", fsdir, SP_GLOB_SEP(fsdir), name);
      snprintf(outpath, sizeof outpath, "%s%s", outprefix, name);
      /* A trailing ** answers every entry beneath it, directories included --
         `Dir.glob("a/**")` is ["a/b", "a/top.rs"] in CRuby. */
      if (last) sp_glob_push(a, outpath);
      /* lstat, not stat: a recursive walk does not follow a symlinked
         directory, which is CRuby's rule and what keeps a link back up the
         tree from looping forever (#4258). */
      { struct stat lst;
        if (lstat(fspath, &lst) == 0 && S_ISDIR(lst.st_mode)) {
          char sub[sizeof outpath + 1];   /* outpath and its trailing slash, whatever outpath holds */
          snprintf(sub, sizeof sub, "%s%s/", outprefix, name);
          /* stay on the same component: ** consumes any number of levels */
          sp_glob_walk(fspath, sub, comps, ncomp, ci, a);
        } }
    }
    closedir(d);
    return;
  }

  if (!sp_glob_has_meta(comp)) {
    /* A literal component needs no readdir: ask the filesystem directly. */
    snprintf(fspath, sizeof fspath, "%s%s%s", fsdir, SP_GLOB_SEP(fsdir), comp);
    snprintf(outpath, sizeof outpath, "%s%s", outprefix, comp);
    if (last) { if (sp_glob_exists(fspath)) sp_glob_push(a, outpath); return; }
    if (sp_glob_is_dir(fspath)) {
      char sub[sizeof outpath + 1];   /* outpath and its trailing slash, whatever outpath holds */
      snprintf(sub, sizeof sub, "%s/", outpath);
      sp_glob_walk(fspath, sub, comps, ncomp, ci + 1, a);
    }
    return;
  }

  DIR *d = opendir(fsdir[0] ? fsdir : ".");
  if (!d) return;
  struct dirent *e;
  while (!sp_glob_bad && (e = readdir(d)) != NULL) {
    const char *name = e->d_name;
    /* "." is an answer under FNM_DOTMATCH -- CRuby lists it for `*` there --
       while ".." never is. Both stay hidden without the flag. */
    if (name[0] == '.' && name[1] == '.' && name[2] == 0) continue;
    if (name[0] == '.' && name[1] == 0 && !sp_glob_dotmatch) continue;
    if (!sp_glob_comp_match(comp, name)) continue;
    if (sp_glob_bad) break;
    snprintf(fspath, sizeof fspath, "%s%s%s", fsdir, SP_GLOB_SEP(fsdir), name);
    snprintf(outpath, sizeof outpath, "%s%s", outprefix, name);
    if (last) { sp_glob_push(a, outpath); continue; }
    if (sp_glob_is_dir(fspath)) {
      char sub[sizeof outpath + 1];   /* outpath and its trailing slash, whatever outpath holds */
      snprintf(sub, sizeof sub, "%s/", outpath);
      sp_glob_walk(fspath, sub, comps, ncomp, ci + 1, a);
    }
  }
  closedir(d);
}

static void sp_glob_start(void) { sp_glob_defer = 1; sp_glob_bad = 0; }
/* The walk is over and has closed what it opened: raise the matcher's
   deferred error, with FNM_DOTMATCH off again as a finished glob leaves it */
static void sp_glob_finish(void) {
  sp_glob_defer = 0;
  if (!sp_glob_bad) return;
  sp_glob_bad = 0;
  sp_glob_dotmatch = 0;
  sp_raise_cls("ArgumentError", (&("\xff" "invalid byte sequence in UTF-8")[1]));
}

/* The old entry point, kept for its callers: everything under `fsdir` whose
   basename matches `tail`. */
void sp_dir_glob_rec(const char *fsdir, const char *outprefix,
                     const char *tail, sp_StrArray *a) {
  char *comps[2];
  char sstar[3] = "**";
  char tbuf[1024];
  snprintf(tbuf, sizeof tbuf, "%s", tail && tail[0] ? tail : "*");
  comps[0] = sstar; comps[1] = tbuf;
  sp_glob_start();
  sp_glob_walk(fsdir && fsdir[0] && strcmp(fsdir, ".") ? fsdir : "", outprefix, comps, 2, 0, a);
  sp_glob_finish();
}

sp_StrArray *sp_dir_glob(const char *pattern);
/* Dir.glob(pat, File::FNM_DOTMATCH) (#2828) */
sp_StrArray *sp_dir_glob_dot(const char *pattern) {SP_GC_ROOT_STR(pattern);
  sp_glob_dotmatch = 1;
  sp_StrArray *a = sp_dir_glob(pattern);
  sp_glob_dotmatch = 0;
  return a;
}

/* One pattern, already brace-free, into `a`. A relative pattern is walked
   from `base` (NULL or "" is the current directory), and its answers are
   spelled relative to it, as Dir.glob(pattern, base:) answers. */
static void sp_dir_glob_one(const char *pattern, const char *base, sp_StrArray *a) {
  char buf[2048];
  snprintf(buf, sizeof buf, "%s", pattern);
  char *comps[64];
  int ncomp = 0;
  /* A pattern ending in a separator names DIRECTORIES, and CRuby keeps the
     separator on the answer: "a/" is ["a/"] and "a/t.rs/" is [] because a
     regular file is not one. Without this the trailing separator was dropped
     as an empty component and a file answered as if it were a directory
     (#4258). */
  size_t blen = strlen(buf);
  int dir_only = blen > 1 && buf[blen - 1] == '/';
  if (dir_only) buf[blen - 1] = 0;
#if defined(_WIN32)
  size_t rootn = sp_file_path_root_len(buf);
  int absolute = rootn > 0;
  /* the root a walk starts from: "/", or a drive's "C:/" */
  char root[4] = "/";
  if (rootn > 1) { memcpy(root, buf, rootn); root[rootn] = 0; root[rootn - 1] = '/'; }
  char *p = buf + rootn;
#else
  int absolute = (buf[0] == '/');
  char *p = buf + (absolute ? 1 : 0);
#endif
  for (char *tok = p; ncomp < 64; ) {
    char *sl = strchr(tok, '/');
    if (sl) *sl = 0;
    if (*tok) comps[ncomp++] = tok;      /* a doubled slash contributes nothing */
    if (!sl) break;
    tok = sl + 1;
  }
  if (ncomp == 0) return;
  /* Stripping the separator turned a trailing recursive component into the
     one-level form; it is the SEPARATOR that makes it descend, so put the
     level back by asking for everything under it. */
  char dstar[3] = "*";
  if (dir_only && ncomp > 0 && strcmp(comps[ncomp - 1], "**") == 0 && ncomp < 64) {
    comps[ncomp++] = dstar;   /* ** + / + *  -- every entry at every depth */
  }
  const char *start = absolute ? SP_GLOB_ROOT : (base ? base : "");
  if (!dir_only) { sp_glob_walk(start, absolute ? SP_GLOB_ROOT : "", comps, ncomp, 0, a); return; }
  /* A symlink to a directory IS one of the answers for a non-recursive form
     ("*" + SEP lists it) and is not for the recursive one, which does not
     follow links at all -- the same split the walk itself makes. */
  { int recursive = 0;
    for (int i = 0; i < ncomp; i++) if (strcmp(comps[i], "**") == 0) recursive = 1;
    sp_StrArray *tmp = sp_StrArray_new();
    SP_GC_ROOT(tmp);
    sp_glob_walk(start, absolute ? SP_GLOB_ROOT : "", comps, ncomp, 0, tmp);
    for (sp_int i = 0; i < tmp->len; i++) {
      const char *e = tmp->data[i];
      /* lstat, for the reason the recursive walk uses it: a symlink to a
         directory is not one of the directories this form answers. */
      struct stat lst;
      if (!e) continue;
      char fspath[4096];
      if (start[0] && !absolute) snprintf(fspath, sizeof fspath, "%s%s%s", start, SP_GLOB_SEP(start), e);
      else snprintf(fspath, sizeof fspath, "%s", e);
      if (recursive) { if (lstat(fspath, &lst) != 0 || !S_ISDIR(lst.st_mode)) continue; }
      else if (!sp_glob_is_dir(fspath)) continue;
      char withslash[2048];
      snprintf(withslash, sizeof withslash, "%s/", e);
      sp_glob_push(a, withslash);
    } }
}

/* CRuby expands `{a,b}` before matching, and the system matcher does not do it
   at all, so it is expanded here: one alternative at a time, recursively, so
   nested and multiple braces both work, to any depth. `each` takes every brace-free pattern
   in turn; a nonzero answer from it stops the expansion and is the answer.
   Dir.glob collects from every alternative, File.fnmatch with FNM_EXTGLOB
   stops at the first that matches. */
typedef int (*sp_brace_fn)(const char *pattern, void *ctx);
/* `escape` is whether a backslash escapes (FNM_NOESCAPE turns it off for
   File.fnmatch). A "{" that never closes: Dir.glob matches the pattern as
   it is, File.fnmatch (`unclosed_fails`) answers no match, as CRuby's
   brace expansion never reaches its matcher then. */
static int sp_brace_expand(const char *pattern, int escape, int unclosed_fails, sp_brace_fn each, void *ctx) {
  const char *open = NULL;
  int nest = 0;
  for (const char *q = pattern; *q; q++) {
    if (escape && *q == '\\' && q[1]) { q++; continue; }
    if (*q == '{') { open = q; break; }
  }
  if (!open) return each(pattern, ctx);
  const char *close = NULL;
  for (const char *q = open; *q; q++) {
    if (escape && *q == '\\' && q[1]) { q++; continue; }
    if (*q == '{') nest++;
    else if (*q == '}') { nest--; if (nest == 0) { close = q; break; } }
  }
  if (!close) return unclosed_fails ? 0 : each(pattern, ctx);
  size_t prelen = (size_t)(open - pattern), postlen = strlen(close + 1);
  const char *alt = open + 1;
  nest = 0;
  for (const char *q = open + 1; q <= close; q++) {
    if (escape && *q == '\\' && q[1]) { q++; continue; }
    if (*q == '{') nest++;
    else if (*q == '}' && nest > 0) nest--;
    if ((*q == ',' && nest == 0) || q == close) {
      size_t altlen = (size_t)(q - alt);
      char *expanded = (char *)malloc(prelen + altlen + postlen + 1);
      if (!expanded) sp_oom_die();
      memcpy(expanded, pattern, prelen);
      memcpy(expanded + prelen, alt, altlen);
      memcpy(expanded + prelen + altlen, close + 1, postlen + 1);
      int r = sp_brace_expand(expanded, escape, unclosed_fails, each, ctx);
      free(expanded);
      if (r) return r;
      alt = q + 1;
    }
  }
  return 0;
}

typedef struct { const char *base; sp_StrArray *a; } sp_glob_ctx;
static int sp_dir_glob_each(const char *pattern, void *ctx) {
  sp_glob_ctx *g = (sp_glob_ctx *)ctx;
  sp_dir_glob_one(pattern, g->base, g->a);
  return sp_glob_bad;
}
static void sp_dir_glob_braces(const char *pattern, const char *base, sp_StrArray *a) {
  sp_glob_ctx g = { base, a };
  (void)sp_brace_expand(pattern, 1, 0, sp_dir_glob_each, &g);
}

/* Dir.glob(pattern, base: dir) */
sp_StrArray *sp_dir_glob_base(const char *pattern, const char *base) {
  /* the pattern is often a fresh interpolation temp, unrooted at the call
     site; the per-match sp_str_allocs below can collect it mid-walk */
  SP_GC_ROOT_STR(pattern);
  SP_GC_ROOT_STR(base);
  sp_StrArray *a = sp_StrArray_new();
  /* every matched entry sp_str_allocs inside the walk below, and enough of
     them trigger a collection mid-build -- root the result like
     sp_dir_entries_impl or it (and its pushed names) get swept under us */
  SP_GC_ROOT(a);
  if (!pattern) return a;
  sp_glob_start();
  sp_dir_glob_braces(pattern, base, a);
  sp_glob_finish();
  sp_StrArray_sort_bang(a);
  /* Two or more recursive components can reach the same path by different
     splits -- "a" + SEP + "**" + SEP + "**" + SEP + "*.rs" found each file
     once per way of dividing the levels between them -- and CRuby answers a
     path once. The list is sorted, so equal entries are adjacent (#4258). */
  { sp_int w = 0;
    for (sp_int r = 0; r < a->len; r++) {
      if (w > 0 && a->data[r] && a->data[w - 1] &&
          sp_str_cmp_bytes(a->data[w - 1], a->data[r]) == 0) continue;
      a->data[w++] = a->data[r];
    }
    a->len = w; }
  return a;
}

sp_StrArray *sp_dir_glob(const char *pattern) { return sp_dir_glob_base(pattern, NULL); }

/* ---- File.read/size/mtime/join/readlines + Math.lgamma (cold) ---- */

const char *sp_file_join(const char **parts, int n) {
  /* CRuby boundary rule (#2785): exactly one separator joins adjacent
     components -- when the accumulated path already ends with '/', the next
     component's leading '/'s are dropped; otherwise one is inserted. */
  /* The parts are read in full before the result is allocated: a part may
     be a String nothing else holds -- a #to_path's fresh answer -- and the
     allocation can collect it. */
  size_t total = 0;
  for (int i = 0; i < n; i++) { if (parts[i]) total += strlen(parts[i]); total++; }
  char *tmp = (char *)malloc(total + 1);
  if (!tmp) sp_oom_die();
  size_t off = 0;
  for (int i = 0; i < n; i++) {
    const char *p = parts[i] ? parts[i] : "";
    if (i > 0) {
      if (off > 0 && tmp[off - 1] == '/') { while (*p == '/') p++; }
      else if (*p != '/') tmp[off++] = '/';
    }
    size_t l = strlen(p);
    memcpy(tmp + off, p, l); off += l;
  }
  char *r = sp_str_alloc((sp_int)off);
  memcpy(r, tmp, off);
  free(tmp);
  r[off] = 0;
  sp_str_set_len(r, off);
  return r;
}

sp_StrArray *sp_file_readlines(const char *path) {SP_GC_ROOT_STR(path);
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  FILE *_fp = fopen(path ? path : "", "r");
  /* a file that can't be opened raises, as CRuby's (Errno::ENOENT, ...) */
  if (!_fp) sp_file_raise_errno("rb_sysopen", path);
  /* getline answers each line whole, however long, as ARGF's gets reads it */
  char *_buf = NULL;
  size_t _cap = 0;
  ssize_t _n;
  while ((_n = getline(&_buf, &_cap, _fp)) >= 0) {
    size_t _l = (size_t)_n;
    char *_r = sp_str_alloc_raw(_l + 1);
    memcpy(_r, _buf, _l); _r[_l] = '\0';
    sp_str_set_len(_r, _l);
    sp_StrArray_push(a, _r);
  }
  free(_buf);
  fclose(_fp);
  return a;
}

sp_StrArray *sp_file_readlines_chomp(const char *path) {SP_GC_ROOT_STR(path);
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  FILE *_fp = fopen(path ? path : "", "r");
  /* a file that can't be opened raises, as CRuby's (Errno::ENOENT, ...) */
  if (!_fp) sp_file_raise_errno("rb_sysopen", path);
  char *_buf = NULL;
  size_t _cap = 0;
  ssize_t _n;
  while ((_n = getline(&_buf, &_cap, _fp)) >= 0) {
    size_t _l = (size_t)_n;
    if (_l > 0 && _buf[_l-1] == '\n') { _buf[--_l] = '\0'; }
    if (_l > 0 && _buf[_l-1] == '\r') { _buf[--_l] = '\0'; }
    char *_r = sp_str_alloc_raw(_l + 1);
    memcpy(_r, _buf, _l); _r[_l] = '\0';
    sp_str_set_len(_r, _l);
    sp_StrArray_push(a, _r);
  }
  free(_buf);
  fclose(_fp);
  return a;
}

double sp_lgamma_pos(double x) {  /* x > 0 */
  if (x == 1.0 || x == 2.0) return 0.0;
  double corr = 0.0;
  while (x < 12.0) { corr -= log(x); x += 1.0; }
  double inv = 1.0 / x, inv2 = inv * inv;
  /* sum_{k>=1} B_2k / (2k(2k-1) x^(2k-1)) up to the 1/x^11 term */
  double series = (1.0/12.0) + (inv2 * (-(1.0/360.0) + (inv2 * ((1.0/1260.0)
                  + (inv2 * (-(1.0/1680.0) + (inv2 * (1.0/1188.0))))))));
  return corr + ((x - 0.5) * log(x)) - x + (0.5 * log(2.0 * M_PI)) + (series * inv);
}

sp_PolyArray *sp_math_lgamma(double x) {
  int sign = 1; double v;
  if (x > 0.0) {
    v = sp_lgamma_pos(x);
  }
  else if (x == floor(x)) {
    /* pole at every non-positive integer -- detect it directly, since
       sin(M_PI * x) is not exactly 0 there in floating point (#3016).
       gamma approaches -inf from the -0 side, so -0.0 alone reports sign
       -1 (CRuby/C99 lgamma_r) (#3116). */
    v = INFINITY;
    if (x == 0.0 && signbit(x)) sign = -1;
  }
  else {
    double s = sin(M_PI * x);
    if (s < 0.0) sign = -1;
    v = log(M_PI / fabs(s)) - sp_lgamma_pos(1.0 - x);
  }
  sp_PolyArray *r = sp_PolyArray_new(); SP_GC_ROOT(r);
  sp_PolyArray_push(r, sp_box_float(v));
  sp_PolyArray_push(r, sp_box_int(sign));
  return r;
}

/* Read from the stream's current position to EOF.
   The seek size is a HINT, never the length: /proc and /sys entries, FIFOs and
   character devices all report 0 and still yield bytes, and an ordinary file
   can grow between the size query and the read. Sizing the buffer from it and
   stopping there answered "" for the whole of /proc -- silently, since a short
   read is indistinguishable from an empty file (#3411). The hint only picks
   the initial capacity, so the common case is still one allocation and one
   fread. */
const char *sp_slurp_stream(FILE *fp) {
  if (!fp) return &("\xff" "")[1];
  size_t cap = 8192;
  long pos = ftell(fp);
  if (pos >= 0 && fseek(fp, 0, SEEK_END) == 0) {
    long end = ftell(fp);
    if (fseek(fp, pos, SEEK_SET) != 0) { /* unseekable after all: start over */ }
    if (end > pos) cap = (size_t)(end - pos) + 1;
  }
  char *buf = (char *)malloc(cap);
  if (!buf) return &("\xff" "")[1];
  size_t len = 0;
  for (;;) {
    if (len + 1 >= cap) {
      size_t ncap = cap * 2;
      char *nb = (char *)realloc(buf, ncap);
      if (!nb) { free(buf); return &("\xff" "")[1]; }
      buf = nb; cap = ncap;
    }
    size_t got = fread(buf + len, 1, cap - len - 1, fp);
    len += got;
    if (got == 0) break;
  }
  char *r = sp_str_alloc(len);
  if (len) memcpy(r, buf, len);
  r[len] = 0;
  sp_str_set_len(r, len);
  free(buf);
  return r;
}

/* IO#read with no count on a handle whose read can BLOCK -- a pipe, a socket,
   a tty. sp_slurp_stream asks fread for a whole buffer at a time, and fread
   does not come back until it has that many bytes or EOF: on a pipe that is a
   sit in the kernel between the writer's chunks, holding the OS worker, so a
   green thread slurping a pipe another green thread is still writing to never
   finished on SPINEL_WORKERS=1 -- the writer had nowhere to run.

   Park, then take exactly what arrived. The park frees the worker; the fgetc
   after it triggers the read(2) that fills stdio's buffer; and draining
   exactly what stdio then holds cannot block. Round again. (#4307) */
const char *sp_slurp_stream_parked(sp_File *f) {SP_GC_ROOT(f);
  if (!f || !f->fp) return &("\xff" "")[1];
  size_t cap = 8192, len = 0;
  char *buf = (char *)malloc(cap);
  if (!buf) return &("\xff" "")[1];
  for (;;) {
    sp_io_wait_readable(f);
    int ch = fgetc(f->fp);
    if (ch == EOF) break;
    if (len + 2 >= cap) {
      char *nb = (char *)realloc(buf, cap * 2);
      if (!nb) { free(buf); return &("\xff" "")[1]; }
      buf = nb; cap *= 2;
    }
    buf[len++] = (char)ch;
    /* whatever the same read(2) already delivered: no kernel wait for these */
    for (size_t avail; (avail = sp_io_stdio_buffered(f->fp)) > 0; ) {
      while (len + avail + 1 >= cap) {
        char *nb = (char *)realloc(buf, cap * 2);
        if (!nb) { free(buf); return &("\xff" "")[1]; }
        buf = nb; cap *= 2;
      }
      size_t got = fread(buf + len, 1, avail, f->fp);
      len += got;
      if (got == 0) break;
    }
  }
  char *r = sp_str_alloc(len);
  if (len) memcpy(r, buf, len);
  r[len] = 0;
  sp_str_set_len(r, len);
  free(buf);
  return r;
}

const char *sp_file_read(const char *path) {SP_GC_ROOT_STR(path);
  if (sp_file_directory(path)) {
    sp_raise_cls("Errno::EISDIR", sp_sprintf("Is a directory @ io_fread - %s", path));
  }
  FILE *f = fopen(path, "r");
  if (!f) {
    sp_raise_cls(errno == ENOENT ? "Errno::ENOENT" : errno == EACCES ? "Errno::EACCES" : "RuntimeError",
                 sp_sprintf("%s @ rb_sysopen - %s", strerror(errno), path));
    return &("\xff" "")[1];
  }
  const char *r = sp_slurp_stream(f);
  fclose(f);
  return r;
}

sp_Time sp_file_atime(const char *path) {SP_GC_ROOT_STR(path);
  if (!path) { sp_raise_cls("TypeError", "no implicit conversion of nil into String"); return (sp_Time){0, 0, 0}; }
  struct stat st;
  if (stat(path, &st) == -1) {
    sp_file_raise_errno("rb_file_s_atime", path);
    return (sp_Time){0, 0, 0};
  }
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__) || defined(__DragonFly__)
  return (sp_Time){(int64_t)st.st_atimespec.tv_sec, (int32_t)st.st_atimespec.tv_nsec, 0};
#else
  return (sp_Time){(int64_t)st.st_atim.tv_sec, (int32_t)st.st_atim.tv_nsec, 0};
#endif
}
sp_Time sp_file_ctime(const char *path) {SP_GC_ROOT_STR(path);
  if (!path) { sp_raise_cls("TypeError", "no implicit conversion of nil into String"); return (sp_Time){0, 0, 0}; }
  struct stat st;
  if (stat(path, &st) == -1) {
    sp_file_raise_errno("rb_file_s_ctime", path);
    return (sp_Time){0, 0, 0};
  }
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__) || defined(__DragonFly__)
  return (sp_Time){(int64_t)st.st_ctimespec.tv_sec, (int32_t)st.st_ctimespec.tv_nsec, 0};
#else
  return (sp_Time){(int64_t)st.st_ctim.tv_sec, (int32_t)st.st_ctim.tv_nsec, 0};
#endif
}
sp_Time sp_file_mtime(const char *path) {SP_GC_ROOT_STR(path);
  if (!path) {
    sp_raise_cls("TypeError", "no implicit conversion of nil into String");
    return (sp_Time){0, 0, 0};
  }
  struct stat st;
  if (stat(path, &st) == -1) {
    sp_file_raise_errno("rb_file_s_mtime", path);
    return (sp_Time){0, 0, 0};
  }
#if defined(__APPLE__)
  return (sp_Time){(int64_t)st.st_mtimespec.tv_sec, (int32_t)st.st_mtimespec.tv_nsec, 0};
#elif defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__) || defined(__DragonFly__)
  return (sp_Time){(int64_t)st.st_mtimespec.tv_sec, (int32_t)st.st_mtimespec.tv_nsec, 0};
#else
  /* Linux / others with st_mtim */
  return (sp_Time){(int64_t)st.st_mtim.tv_sec, (int32_t)st.st_mtim.tv_nsec, 0};
#endif
}
sp_Time sp_file_birthtime(const char *path) {SP_GC_ROOT_STR(path);  /* (#2985) */
  if (!path) { sp_raise_cls("TypeError", "no implicit conversion of nil into String"); return (sp_Time){0, 0, 0}; }
  /* OpenBSD's struct stat keeps the birth time only as the private
     __st_birthtim, so CRuby has no File.birthtime there either: the #else */
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__NetBSD__) || defined(__DragonFly__)
  struct stat st;
  if (stat(path, &st) == -1) sp_file_raise_errno("rb_file_s_birthtime", path);
  return (sp_Time){(int64_t)st.st_birthtimespec.tv_sec, (int32_t)st.st_birthtimespec.tv_nsec, 0};
#elif defined(__linux__) && defined(STATX_BTIME)
  /* a statx that fails is the path's Errno (a missing file is ENOENT, as in
     CRuby's rb_file_s_birthtime); only a filesystem that answers without a
     birth time is the NotImplementedError */
  struct statx stx;
  if (statx(AT_FDCWD, path, AT_STATX_SYNC_AS_STAT, STATX_BTIME, &stx) != 0)
    sp_file_raise_errno("rb_file_s_birthtime", path);
  if (stx.stx_mask & STATX_BTIME)
    return (sp_Time){(int64_t)stx.stx_btime.tv_sec, (int32_t)stx.stx_btime.tv_nsec, 0};
  sp_raise_cls("NotImplementedError", "birthtime() function is unimplemented on this filesystem");
  return (sp_Time){0, 0, 0};
#elif defined(_WIN32)
  /* the creation time Windows keeps (lib/win32's struct stat) */
  struct stat st;
  if (stat(path, &st) == -1) sp_file_raise_errno("rb_file_s_birthtime", path);
  return (sp_Time){(int64_t)st.st_birthtim.tv_sec, (int32_t)st.st_birthtim.tv_nsec, 0};
#else
  sp_raise_cls("NotImplementedError", "birthtime() function is unimplemented");
  return (sp_Time){0, 0, 0};
#endif
}
sp_int sp_process_getpriority(sp_int which, sp_int who) {  /* (#3046) */
  errno = 0;
  int r = getpriority((int)which, (id_t)who);
  if (r == -1 && errno != 0)
    sp_raise_cls(errno == EINVAL ? "Errno::EINVAL" : (errno == ESRCH ? "Errno::ESRCH" : "SystemCallError"),
                 strerror(errno));
  return (sp_int)r;
}
sp_IntArray *sp_process_groups(void) {  /* (#3046) */
  sp_IntArray *a = sp_IntArray_new();
  int n = getgroups(0, NULL);
  if (n <= 0) return a;
  gid_t *buf = (gid_t *)malloc(sizeof(gid_t) * (size_t)n);
  if (!buf) return a;
  n = getgroups(n, buf);
  for (int i = 0; i < n; i++) sp_IntArray_push(a, (sp_int)buf[i]);
  free(buf);
  return a;
}

sp_int sp_file_size(const char *path) {SP_GC_ROOT_STR(path);
  if (!path) {
    sp_raise_cls("TypeError", "no implicit conversion of nil into String");
    return 0;
  }
  struct stat st;
  if (stat(path, &st) == -1) {
    sp_file_raise_errno("rb_file_s_size", path);
    return 0;
  }
  /* off_t (typically 64-bit) into sp_int (intptr_t -> 32-bit on a 32-bit
     build): guard the narrowing, as spinel does for int arithmetic. */
  if ((off_t)(sp_int)st.st_size != st.st_size) {
    sp_raise_cls("RangeError", "file size out of range for Integer");
    return 0;
  }
  return (sp_int)st.st_size;
}

sp_IntArray *sp_file_binread_bytes(const char *path) {SP_GC_ROOT_STR(path);
  if (sp_file_directory(path)) {
    sp_raise_cls("Errno::EISDIR", sp_sprintf("Is a directory @ io_fread - %s", path));
  }
  FILE *f = fopen(path, "rb");
  sp_IntArray *a = sp_IntArray_new();
  if (!f) {
    sp_raise_cls(errno == ENOENT ? "Errno::ENOENT" : errno == EACCES ? "Errno::EACCES" : "RuntimeError",
                 sp_sprintf("%s @ rb_sysopen - %s", strerror(errno), path));
    return a;
  }
  fseek(f, 0, SEEK_END);
  long sz = ftell(f);
  fseek(f, 0, SEEK_SET);
  unsigned char *buf = (unsigned char *)malloc(sz > 0 ? (size_t)sz : 1);
  if (buf && sz > 0) {
    /* Use fread's actual byte count, not the raw file size -- a
       partial read otherwise pushes uninitialized memory. */
    size_t r = fread(buf, 1, (size_t)sz, f);
    for (size_t i = 0; i < r; i++) sp_IntArray_push(a, (sp_int)buf[i]);
  }
  free(buf);
  fclose(f);
  return a;
}

/* ---- more cold helpers: string/File/Dir/poly-combinatorics/misc ---- */

/* String#sum: the byte checksum modulo 2**bits (bits <= 0 or >= 64 leaves the
   sum untruncated, like CRuby). The typed emitter inlines this same loop; the
   boxed receiver reaches it through sp_poly_sum. */
sp_int sp_str_sum_bits(const char *s, sp_int bits) {
  sp_int acc = 0;
  size_t bl = s ? sp_str_byte_len(s) : 0;   /* every byte, a NUL included (#4527) */
  for (size_t i = 0; i < bl; i++) acc += (unsigned char)s[i];
  return (bits <= 0 || bits >= (sp_int)(sizeof(sp_int) * 8)) ? acc : (acc & ((((sp_int)1) << bits) - 1));
}

const char *sp_str_splice_at(const char *s, sp_int from, sp_int n, const char *val, int range_form) {SP_GC_ROOT_STR(s);SP_GC_ROOT_STR(val);
  if (!s) s = "";
  if (!val) val = "";
  sp_int len = (sp_int)sp_str_length(s);
  if (n < 0) { sp_raise_cls("IndexError", sp_sprintf("negative length %lld", (long long)n)); return s; }
  sp_int from0 = from;
  if (from < 0) from += len;
  if (from < 0 || from > len) {
    if (range_form) sp_raise_cls("RangeError", sp_sprintf("%lld out of range", (long long)from0));
    else sp_raise_cls("IndexError", sp_sprintf("index %lld out of string", (long long)from0));
    return s;
  }
  if (from + n > len) n = len - from;
  /* Root each piece as soon as it exists. As one nested expression, whichever
     argument C evaluates first sits in an unrooted temporary while the other
     one allocates -- sp_str_sub_range and sp_str_concat both do -- since
     sp_str_concat roots its parameters only once entered, and by then both are
     already computed. A collection in that window frees the piece still in
     flight, and the splice reads it back: the result takes its length from
     recycled memory, or faults where the allocator had already returned the
     span to the OS. */
  const char *head = sp_str_sub_range(s, 0, from);
  SP_GC_ROOT_STR(head);
  const char *tail = sp_str_sub_range(s, from + n, len - from - n);
  SP_GC_ROOT_STR(tail);
  const char *pre = sp_str_concat(head, val);
  SP_GC_ROOT_STR(pre);
  return sp_str_concat(pre, tail);
}

sp_int sp_poly_cmp_int_arrays(sp_RbVal a, sp_RbVal b, sp_bool *comparable) {
  if (a.tag != SP_TAG_OBJ || b.tag != SP_TAG_OBJ ||
      a.cls_id != SP_BUILTIN_INT_ARRAY || b.cls_id != SP_BUILTIN_INT_ARRAY) { *comparable = FALSE; return 0; }
  sp_IntArray *x = (sp_IntArray *)a.v.p, *y = (sp_IntArray *)b.v.p;
  if (!x || !y) { *comparable = FALSE; return 0; }
  sp_int n = x->len < y->len ? x->len : y->len;
  for (sp_int i = 0; i < n; i++) {
    sp_int xe = x->data[x->start + i], ye = y->data[y->start + i];
    if (xe != ye) { *comparable = TRUE; return xe < ye ? -1 : 1; }
  }
  *comparable = TRUE;
  return (x->len > y->len) - (x->len < y->len);
}

sp_int sp_int_round_half(sp_int v, sp_int nd, int mode) {
  if (nd >= 0) return v;
  sp_int f = 1;
  for (sp_int i = 0; i < -nd; i++) f *= 10;
  sp_int q = v / f, rem = v % f;
  sp_int arem = rem < 0 ? -rem : rem;
  sp_int half = f / 2;
  int up;
  if (arem > half) up = 1;
  else if (arem < half) up = 0;
  else up = mode == 1 ? 1 : mode == 2 ? 0 : (q % 2 != 0);  /* :even ties to even */
  if (up) q += (v < 0 ? -1 : 1);
  return q * f;
}

sp_RbVal sp_poly_replace(sp_RbVal recv, sp_RbVal src);

static const char *sp_typed_elem_class(sp_RbVal v) {
  switch (v.tag) {
    case SP_TAG_INT: case SP_TAG_BIGINT: return "Integer";
    case SP_TAG_FLT: return "Float";
    case SP_TAG_STR: return "String";
    case SP_TAG_SYM: return "Symbol";
    case SP_TAG_BOOL: return v.v.i ? "true" : "false";
    default: return "Object";
  }
}

SP_NORETURN static void sp_typed_replace_elem_error(sp_RbVal v, const char *kind) {
  char msg[160];
  snprintf(msg, sizeof msg, "cannot store %s into an Array[%s]: a typed array holds one kind of element",
           sp_typed_elem_class(v), kind);
  sp_raise_cls("TypeError", msg);
  abort();
}

/* the contents of a shared String buffer as a String of their own, embedded
   NULs and a binary encoding included */
static const char *sp_strbuf_copy(sp_String *b) {
  size_t n = (size_t)b->len;
  char *c = sp_str_alloc(n);
  memcpy(c, b->data, n);
  c[n] = '\0';
  sp_str_set_len(c, n);
  if (b->binary) sp_str_mark_binary(c);
  return c;
}

/* A typed array replaced from an array of another kind takes each element as
   the boxed []= stores one: its own kind, nil as its nil, an Integer into a
   Float array; any other element raises before the receiver changes. */
static void sp_typed_array_replace_boxed(sp_RbVal recv, sp_RbVal src) {
  SP_GC_ROOT_RBVAL(recv); SP_GC_ROOT_RBVAL(src);
  sp_int frozen = recv.cls_id == SP_BUILTIN_INT_ARRAY ? ((sp_IntArray *)recv.v.p)->frozen
                : recv.cls_id == SP_BUILTIN_FLT_ARRAY ? ((sp_FloatArray *)recv.v.p)->frozen
                : recv.cls_id == SP_BUILTIN_STR_ARRAY ? ((sp_StrArray *)recv.v.p)->frozen
                : ((sp_PtrArray *)recv.v.p)->frozen;
  if (frozen) { sp_raise_frozen_array_at(recv.v.p, recv.cls_id); return; }
  sp_PolyArray *els = sp_PolyArray_new(); SP_GC_ROOT(els);
  sp_poly_replace(sp_box_poly_array(els), src);
  switch (recv.cls_id) {
    case SP_BUILTIN_INT_ARRAY: {
      sp_IntArray *st = sp_IntArray_new(); SP_GC_ROOT(st);
      for (sp_int i = 0; i < els->len; i++) {
        sp_RbVal e = els->data[i];
        if (e.tag == SP_TAG_INT) sp_IntArray_push(st, e.v.i);
        else if (e.tag == SP_TAG_NIL) sp_IntArray_push_nil(st);
        else sp_typed_replace_elem_error(e, "Integer");
      }
      sp_IntArray_replace((sp_IntArray *)recv.v.p, st);
      break;
    }
    case SP_BUILTIN_FLT_ARRAY: {
      sp_FloatArray *st = sp_FloatArray_new(); SP_GC_ROOT(st);
      for (sp_int i = 0; i < els->len; i++) {
        sp_RbVal e = els->data[i];
        if (e.tag == SP_TAG_FLT) sp_FloatArray_push(st, e.v.f);
        else if (e.tag == SP_TAG_INT) sp_FloatArray_push(st, (sp_float)e.v.i);
        else if (e.tag == SP_TAG_NIL) sp_FloatArray_push_nil(st);
        else sp_typed_replace_elem_error(e, "Float");
      }
      sp_FloatArray_replace((sp_FloatArray *)recv.v.p, st);
      break;
    }
    case SP_BUILTIN_STR_ARRAY: {
      sp_StrArray *st = sp_StrArray_new(); SP_GC_ROOT(st);
      for (sp_int i = 0; i < els->len; i++) {
        sp_RbVal e = els->data[i];
        if (e.tag == SP_TAG_STR) sp_StrArray_push(st, e.v.s);
        else if (e.tag == SP_TAG_OBJ && e.cls_id == SP_BUILTIN_STRBUF)
          sp_StrArray_push(st, sp_strbuf_copy((sp_String *)e.v.p));
        else if (e.tag == SP_TAG_NIL) sp_StrArray_push(st, NULL);
        else sp_typed_replace_elem_error(e, "String");
      }
      sp_StrArray_replace((sp_StrArray *)recv.v.p, st);
      break;
    }
    case SP_BUILTIN_PTR_ARRAY: {
      sp_PtrArray *d = (sp_PtrArray *)recv.v.p;
      for (sp_int i = 0; i < els->len; i++) (void)sp_PtrArray_elem_unbox(d, els->data[i]);
      sp_gc_wb((void *)d);
      d->len = 0;
      for (sp_int i = 0; i < els->len; i++) sp_PtrArray_push(d, sp_PtrArray_elem_unbox(d, els->data[i]));
      break;
    }
  }
}

sp_RbVal sp_poly_replace(sp_RbVal recv, sp_RbVal src) {SP_GC_ROOT_RBVAL(recv);SP_GC_ROOT_RBVAL(src);
  if (recv.tag != SP_TAG_OBJ) return recv;
  /* String#replace on a shared-mutable handle: swap the buffer contents in
     place, from a plain string box or another handle (#3227). */
  if (recv.cls_id == SP_BUILTIN_STRBUF) {
    sp_String *m = (sp_String *)recv.v.p;
    const char *s2 = NULL;
    if (src.tag == SP_TAG_STR) s2 = src.v.s;
    else if (src.tag == SP_TAG_OBJ && src.cls_id == SP_BUILTIN_STRBUF)
      s2 = sp_String_cstr((sp_String *)src.v.p);
    if (s2) sp_String_set_bin(m, s2);
    return recv;
  }
  if (src.tag != SP_TAG_OBJ) return recv;
  if (recv.cls_id == SP_BUILTIN_INT_ARRAY && src.cls_id == SP_BUILTIN_INT_ARRAY)
    sp_IntArray_replace((sp_IntArray *)recv.v.p, (sp_IntArray *)src.v.p);
  else if (recv.cls_id == SP_BUILTIN_FLT_ARRAY && src.cls_id == SP_BUILTIN_FLT_ARRAY)
    sp_FloatArray_replace((sp_FloatArray *)recv.v.p, (sp_FloatArray *)src.v.p);
  else if (recv.cls_id == SP_BUILTIN_STR_ARRAY && src.cls_id == SP_BUILTIN_STR_ARRAY)
    sp_StrArray_replace((sp_StrArray *)recv.v.p, (sp_StrArray *)src.v.p);
  else if (recv.cls_id == SP_BUILTIN_PTR_ARRAY && src.cls_id == SP_BUILTIN_PTR_ARRAY) {
    /* a pointer array takes another's elements when they are of its kind (#4486) */
    sp_PtrArray *d = (sp_PtrArray *)recv.v.p, *sa = (sp_PtrArray *)src.v.p;
    if (d == sa) return recv;
    if (d->frozen) { sp_raise_frozen_array_at(d, SP_BUILTIN_PTR_ARRAY); return recv; }
    for (sp_int i = 0; i < sa->len; i++) (void)sp_PtrArray_elem_unbox(d, sp_PtrArray_elem_box(sa, sa->data[i]));
    sp_gc_wb((void *)d);
    d->len = 0;
    for (sp_int i = 0; i < sa->len; i++) sp_PtrArray_push(d, sa->data[i]);
  }
  else if ((recv.cls_id == SP_BUILTIN_INT_ARRAY || recv.cls_id == SP_BUILTIN_FLT_ARRAY ||
            recv.cls_id == SP_BUILTIN_STR_ARRAY || recv.cls_id == SP_BUILTIN_PTR_ARRAY) &&
           (src.cls_id == SP_BUILTIN_INT_ARRAY || src.cls_id == SP_BUILTIN_FLT_ARRAY ||
            src.cls_id == SP_BUILTIN_STR_ARRAY || src.cls_id == SP_BUILTIN_PTR_ARRAY ||
            src.cls_id == SP_BUILTIN_POLY_ARRAY))
    sp_typed_array_replace_boxed(recv, src);
  else if (recv.cls_id == SP_BUILTIN_POLY_ARRAY) {
    sp_PolyArray *d = (sp_PolyArray *)recv.v.p;
    d->len = 0;
    switch (src.cls_id) {
      case SP_BUILTIN_INT_ARRAY: { sp_IntArray *s = (sp_IntArray *)src.v.p; for (sp_int i = 0; i < s->len; i++) sp_PolyArray_push(d, sp_IntArray_box_elem(s, i)); break; }
      case SP_BUILTIN_FLT_ARRAY: { sp_FloatArray *s = (sp_FloatArray *)src.v.p; for (sp_int i = 0; i < s->len; i++) sp_PolyArray_push(d, sp_FloatArray_box_elem(s, i)); break; }
      case SP_BUILTIN_STR_ARRAY: { sp_StrArray *s = (sp_StrArray *)src.v.p; for (sp_int i = 0; i < s->len; i++) sp_PolyArray_push(d, sp_box_str(s->data[i])); break; }
      case SP_BUILTIN_POLY_ARRAY: { sp_PolyArray *s = (sp_PolyArray *)src.v.p; for (sp_int i = 0; i < s->len; i++) sp_PolyArray_push(d, s->data[i]); break; }
      case SP_BUILTIN_PTR_ARRAY: { sp_PtrArray *s = (sp_PtrArray *)src.v.p; for (sp_int i = 0; i < s->len; i++) sp_PolyArray_push(d, sp_PtrArray_elem_box(s, s->data[i])); break; }
      default: break;
    }
  }
  return recv;
}

void sp_poly_combination_recur(sp_PolyArray *src, sp_int start, sp_int k, sp_PolyArray *acc, sp_PolyArray *out) {SP_GC_ROOT(src);SP_GC_ROOT(acc);SP_GC_ROOT(out);
  if (k == 0) {
    sp_PolyArray *cp = sp_PolyArray_new(); SP_GC_ROOT(cp);
    for (sp_int i = 0; i < acc->len; i++) sp_PolyArray_push(cp, acc->data[i]);
    sp_PolyArray_push(out, sp_box_poly_array(cp));
    return;
  }
  for (sp_int i = start; i <= src->len - k; i++) {
    sp_PolyArray_push(acc, src->data[i]);
    sp_poly_combination_recur(src, i + 1, k - 1, acc, out);
    acc->len--;
  }
}

void sp_poly_repeated_combination_recur(sp_PolyArray *src, sp_int start, sp_int k, sp_PolyArray *acc, sp_PolyArray *out) {SP_GC_ROOT(src);SP_GC_ROOT(acc);SP_GC_ROOT(out);
  if (k == 0) {
    sp_PolyArray *cp = sp_PolyArray_new(); SP_GC_ROOT(cp);
    for (sp_int i = 0; i < acc->len; i++) sp_PolyArray_push(cp, acc->data[i]);
    sp_PolyArray_push(out, sp_box_poly_array(cp));
    return;
  }
  for (sp_int i = start; i < src->len; i++) {
    sp_PolyArray_push(acc, src->data[i]);
    sp_poly_repeated_combination_recur(src, i, k - 1, acc, out);
    acc->len--;
  }
}

void sp_poly_permutation_recur(sp_PolyArray *src, sp_int k, sp_IntArray *used, sp_PolyArray *acc, sp_PolyArray *out) {SP_GC_ROOT(src);SP_GC_ROOT(used);SP_GC_ROOT(acc);SP_GC_ROOT(out);
  if (k == 0) {
    sp_PolyArray *cp = sp_PolyArray_new(); SP_GC_ROOT(cp);
    for (sp_int i = 0; i < acc->len; i++) sp_PolyArray_push(cp, acc->data[i]);
    sp_PolyArray_push(out, sp_box_poly_array(cp));
    return;
  }
  for (sp_int i = 0; i < src->len; i++) {
    if (used->data[used->start + i]) continue;
    used->data[used->start + i] = 1;
    sp_PolyArray_push(acc, src->data[i]);
    sp_poly_permutation_recur(src, k - 1, used, acc, out);
    acc->len--;
    used->data[used->start + i] = 0;
  }
}

void sp_poly_repeated_permutation_recur(sp_PolyArray *src, sp_int k, sp_PolyArray *acc, sp_PolyArray *out) {SP_GC_ROOT(src);SP_GC_ROOT(acc);SP_GC_ROOT(out);
  if (k == 0) {
    sp_PolyArray *cp = sp_PolyArray_new(); SP_GC_ROOT(cp);
    for (sp_int i = 0; i < acc->len; i++) sp_PolyArray_push(cp, acc->data[i]);
    sp_PolyArray_push(out, sp_box_poly_array(cp));
    return;
  }
  for (sp_int i = 0; i < src->len; i++) {
    sp_PolyArray_push(acc, src->data[i]);
    sp_poly_repeated_permutation_recur(src, k - 1, acc, out);
    acc->len--;
  }
}

int sp_json_kind(sp_RbVal v) {
  if (v.tag != SP_TAG_OBJ) return 0;
  switch (v.cls_id) {
    case SP_BUILTIN_INT_ARRAY: case SP_BUILTIN_FLT_ARRAY:
    case SP_BUILTIN_STR_ARRAY: case SP_BUILTIN_SYM_ARRAY:
    case SP_BUILTIN_POLY_ARRAY: case SP_BUILTIN_PTR_ARRAY: return 1;
    case SP_BUILTIN_STR_INT_HASH: case SP_BUILTIN_STR_STR_HASH:
    case SP_BUILTIN_INT_STR_HASH: case SP_BUILTIN_STR_POLY_HASH:
    case SP_BUILTIN_SYM_POLY_HASH: case SP_BUILTIN_POLY_POLY_HASH:
    case SP_BUILTIN_INT_INT_HASH:
      return 2;
    default: return 0;
  }
}

sp_bool sp_poly_cbi_p(sp_RbVal v) {
  if (v.tag == SP_TAG_OBJ) {
    switch (v.cls_id) {
    case SP_BUILTIN_STR_INT_HASH: case SP_BUILTIN_STR_STR_HASH:
    case SP_BUILTIN_INT_STR_HASH: case SP_BUILTIN_STR_POLY_HASH:
    case SP_BUILTIN_SYM_POLY_HASH: case SP_BUILTIN_POLY_POLY_HASH:
    case SP_BUILTIN_INT_INT_HASH:
      return FALSE;
    default: break;
    }
  }
  sp_raise_cls("NoMethodError", "undefined method 'compare_by_identity?' for poly");
  return FALSE;
}

/* File.write(path, data): answers the byte count it wrote, measured by the
   same rule that sizes the write, so an embedded NUL in a stringified value
   counts once in both places. */
sp_int sp_file_write(const char *path, const char *data) {SP_GC_ROOT_STR(path);SP_GC_ROOT_STR(data);
  if (sp_file_directory(path)) {
    sp_raise_cls("Errno::EISDIR", sp_sprintf("Is a directory @ rb_sysopen - %s", path));
  }
  FILE *f = fopen(path, "wb");
  if (!f) {
    sp_raise_cls(errno == ENOENT ? "Errno::ENOENT" : errno == EACCES ? "Errno::EACCES" : "RuntimeError",
                 sp_sprintf("%s @ rb_sysopen - %s", strerror(errno), path));
    return 0;
  }
  size_t n = sp_str_byte_len(data);
  /* a short write or a failed close is the write's error, not a count:
     CRuby raises the errno (a full disk is Errno::ENOSPC) */
  size_t w = fwrite(data, 1, n, f);
  int err = (w < n || ferror(f)) ? (errno ? errno : EIO) : 0;
  if (fclose(f) != 0 && !err) err = errno ? errno : EIO;
  if (err) {
    errno = err;
    sp_raise_cls(err == ENOSPC ? "Errno::ENOSPC" : "SystemCallError",
                 sp_sprintf("%s @ rb_sys_fail_on_write - %s", strerror(err), path));
    return 0;
  }
  return (sp_int)w;
}

/* `cmd`: the child's whole standard output, and its wait status in $?. This
   was one popen + one fread of 4095 bytes, which was two things at once:
   the output was cut at 4 KB, and the fread and the pclose behind it sat in
   the kernel on the calling OS worker for as long as the command ran -- a
   worker in a syscall never reaches a safepoint, so every other thread's
   next allocation waited on the command too (#4528). The child is forked
   here with its stdout on a pipe; the read parks on that pipe like any read
   from a pipe does, and the wait is the scheduler's polling one, as
   Kernel#system's is. */
const char *sp_backtick(const char *cmd) {SP_GC_ROOT_STR(cmd);
  int fds[2];
  if (pipe(fds) != 0) { sp_last_status = -1; return sp_str_empty; }
  fflush(NULL);
#if defined(_WIN32)
  /* posix_spawn where there is no fork (see sp_process.c) */
  pid_t pid = 0;
  {
    posix_spawn_file_actions_t fa;
    posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_addclose(&fa, fds[0]);
    if (fds[1] != 1) { posix_spawn_file_actions_adddup2(&fa, fds[1], 1); posix_spawn_file_actions_addclose(&fa, fds[1]); }
    char *av[] = { (char *)"sh", (char *)"-c", (char *)cmd, NULL };
    int rc = posix_spawn(&pid, "/bin/sh", &fa, NULL, av, environ);
    posix_spawn_file_actions_destroy(&fa);
    if (rc != 0) { close(fds[0]); close(fds[1]); sp_last_status = 127 << 8; return sp_str_empty; }
  }
#else
  pid_t pid = fork();
  if (pid < 0) { close(fds[0]); close(fds[1]); sp_last_status = -1; return sp_str_empty; }
  if (pid == 0) {
    close(fds[0]);
    if (fds[1] != 1) { dup2(fds[1], 1); close(fds[1]); }
    execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
    _exit(127);
  }
#endif
  close(fds[1]);
  size_t cap = 4096, len = 0;
  char *buf = (char *)malloc(cap);
  if (buf) for (;;) {
    if (len + 1 >= cap) {
      char *nb = (char *)realloc(buf, cap * 2);
      if (!nb) break;
      buf = nb; cap *= 2;
    }
    sp_io_wait_fd_readable(fds[0]);
    ssize_t got = read(fds[0], buf + len, cap - len - 1);
    if (got < 0 && errno == EINTR) continue;
    if (got <= 0) break;
    len += (size_t)got;
  }
  close(fds[0]);
  int st = 0;
  { extern int sp_sched_wait_child(int pid, int *status);
    if (sp_sched_wait_child((int)pid, &st) < 0) st = -1; }
  /* the same wait-status layout sp_system_args leaves in $? */
  sp_last_status = st;
  sp_last_pid = (int)pid;
  char *r = sp_str_alloc(len);
  if (len) memcpy(r, buf, len);
  r[len] = 0;
  sp_str_set_len(r, len);
  free(buf);
  return r;
}

const char *sp_file_basename(const char *path) {SP_GC_ROOT_STR(path);
  /* CRuby: trailing separators are ignored ("/a/b/" -> "b"); an all-separator
     path is "/" (#2784). */
  size_t end = strlen(path);
  while (end > 0 && path[end - 1] == '/') end--;
  if (end == 0) {
    if (path[0] == '/') { char *r = sp_str_alloc(1); r[0] = '/'; r[1] = 0; return r; }
    return sp_str_alloc(0);
  }
  size_t start = end;
  while (start > 0 && path[start - 1] != '/') start--;
  /* sp_gc_mark looks at byte[-1] to distinguish heap strings (`\xfe`)
     from literals (`\xff`). A mid-path pointer has whatever byte came
     before it, so return a fresh sp_str_alloc'd copy with the right marker. */
  size_t n = end - start;
  char *buf = sp_str_alloc((sp_int)n);
  memcpy(buf, path + start, n);
  buf[n] = 0;
  return buf;
}
/* File.basename(path, suffix): ".*" strips the (non-leading) last extension,
   any other suffix strips a literal tail match (#2774). */
const char *sp_file_basename2(const char *path, const char *suffix) {SP_GC_ROOT_STR(path);SP_GC_ROOT_STR(suffix);
  const char *base = sp_file_basename(path);
  size_t n = strlen(base);
  if (suffix && strcmp(suffix, ".*") == 0) {
    const char *dot = strrchr(base, '.');
    if (dot && dot != base) n = (size_t)(dot - base);
  }
  else if (suffix && suffix[0]) {
    size_t sl = strlen(suffix);
    if (n > sl && strcmp(base + n - sl, suffix) == 0) n -= sl;
  }
  if (n == strlen(base)) return base;
  char *r = sp_str_alloc((sp_int)n);
  memcpy(r, base, n); r[n] = 0;
  return r;
}

const char *sp_file_extname(const char *path) {
  const char *base = strrchr(path, '/');
  base = base ? base + 1 : path;
  const char *dot = strrchr(base, '.');
  /* CRuby: leading-dot files (".bashrc") return "". Trailing-dot
     paths ("foo.") keep the dot since Ruby 2.7. */
  if (!dot || dot == base) return sp_str_empty;
  size_t n = strlen(dot);
  char *buf = sp_str_alloc(n);
  memcpy(buf, dot, n + 1);
  return buf;
}

sp_StrArray *sp_dir_entries_impl(const char *path, int children) {
  SP_GC_ROOT_STR(path);
  if (!path) sp_raise_cls("TypeError", "no implicit conversion of nil into String");
  DIR *d = opendir(path);
  if (!d) sp_raise_cls("Errno::ENOENT", sp_sprintf("No such file or directory @ dir_initialize - %s", path));
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  struct dirent *e;
  while ((e = readdir(d)) != NULL) {
    const char *name = e->d_name;
    if (children && name[0] == '.' &&
        (name[1] == 0 || (name[1] == '.' && name[2] == 0))) continue;
    char *copy = sp_str_alloc(strlen(name));
    strcpy(copy, name);
    sp_StrArray_push(a, copy);
  }
  closedir(d);
  sp_StrArray_sort_bang(a);
  return a;
}

/* The rows of a transpose are Arrays; a row that is not is CRuby's TypeError,
   named by the class of what was there. This unit sees the tags alone, so the
   naming is by tag. */
static int sp_transpose_row_p(sp_RbVal rv) {
  return rv.tag == SP_TAG_OBJ &&
         (rv.cls_id == SP_BUILTIN_INT_ARRAY || rv.cls_id == SP_BUILTIN_FLT_ARRAY ||
          rv.cls_id == SP_BUILTIN_STR_ARRAY || rv.cls_id == SP_BUILTIN_SYM_ARRAY ||
          rv.cls_id == SP_BUILTIN_POLY_ARRAY || rv.cls_id == SP_BUILTIN_PTR_ARRAY);
}
static const char *sp_transpose_row_class(sp_RbVal rv) {
  switch (rv.tag) {
    case SP_TAG_NIL: return "nil";
    case SP_TAG_BOOL: return rv.v.i ? "true" : "false";
    case SP_TAG_INT: return "Integer";
    case SP_TAG_FLT: return "Float";
    case SP_TAG_STR: return "String";
    case SP_TAG_SYM: return "Symbol";
    default: return "Object";
  }
}
sp_PolyArray *sp_poly_array_transpose(sp_PolyArray *rows) {
  SP_GC_SAVE();
  SP_GC_ROOT(rows);
  if (!rows || rows->len == 0) return sp_PolyArray_new();
  sp_int nrows = rows->len;
  /* Keep typed columns only when all rows have the same representation. */
  sp_int ncols = -1;   /* -1 until the first row fixes it; ragged rows raise (#2979) */
  int16_t kind = 0; /* 0=unknown, SP_BUILTIN_INT_ARRAY, SP_BUILTIN_FLT_ARRAY, SP_BUILTIN_STR_ARRAY */
  /* an Integer column holds nil where a row may (its may_nil) or where a row
     of another kind leaves the slot's nil: decided once per call */
  for (sp_int r = 0; r < nrows; r++) {
    sp_RbVal rv = rows->data[r];
    /* a row that is no Array is CRuby's TypeError, not a row of nothing */
    if (!sp_transpose_row_p(rv))
      sp_raise_cls("TypeError", sp_sprintf("no implicit conversion of %s into Array", sp_transpose_row_class(rv)));
    sp_int rlen = 0;
    if (rv.cls_id == SP_BUILTIN_INT_ARRAY)  { rlen = ((sp_IntArray *)rv.v.p)->len; if(!kind) kind = SP_BUILTIN_INT_ARRAY; }
    else if (rv.cls_id == SP_BUILTIN_FLT_ARRAY) { rlen = ((sp_FloatArray *)rv.v.p)->len; if(!kind) kind = SP_BUILTIN_FLT_ARRAY; }
    else if (rv.cls_id == SP_BUILTIN_STR_ARRAY) { rlen = ((sp_StrArray *)rv.v.p)->len; if(!kind) kind = SP_BUILTIN_STR_ARRAY; }
    else if (rv.cls_id == SP_BUILTIN_POLY_ARRAY) { rlen = ((sp_PolyArray *)rv.v.p)->len; if(!kind) kind = SP_BUILTIN_POLY_ARRAY; }
    else if (rv.cls_id == SP_BUILTIN_PTR_ARRAY) { rlen = ((sp_PtrArray *)rv.v.p)->len; if(!kind) kind = SP_BUILTIN_POLY_ARRAY; }   /* a row of rows or objects reads generically (#4486) */
    else if (rv.cls_id == SP_BUILTIN_SYM_ARRAY) { rlen = ((sp_IntArray *)rv.v.p)->len; if(!kind) kind = SP_BUILTIN_POLY_ARRAY; }
    if (kind != rv.cls_id) kind = SP_BUILTIN_POLY_ARRAY;
    if (ncols < 0) ncols = rlen;
    else if (rlen != ncols)
      sp_raise_cls("IndexError", sp_sprintf("element size differs (%lld should be %lld)",
                                            (long long)rlen, (long long)ncols));
  }
  if (ncols < 0) ncols = 0;
  sp_PolyArray *result = sp_PolyArray_new();
  SP_GC_ROOT(result);
  for (sp_int c = 0; c < ncols; c++) {
    sp_RbVal cv = sp_box_nil();
    if (kind == SP_BUILTIN_INT_ARRAY) {
      sp_IntArray *col = sp_IntArray_new();
      SP_GC_ROOT(col);
      for (sp_int r = 0; r < nrows; r++) {
        sp_RbVal rv = rows->data[r];
        sp_oint val = sp_oint_nil();
        if (rv.tag == SP_TAG_OBJ && rv.cls_id == SP_BUILTIN_INT_ARRAY) {
          sp_IntArray *row = (sp_IntArray *)rv.v.p;
          if (c < row->len) val = sp_IntArray_oget(row, c);
        }
        sp_IntArray_push_o(col, val);
      }
      cv.tag = SP_TAG_OBJ; cv.cls_id = SP_BUILTIN_INT_ARRAY; cv.v.p = col;
    }
else if (kind == SP_BUILTIN_FLT_ARRAY) {
      sp_FloatArray *col = sp_FloatArray_new();
      SP_GC_ROOT(col);
      for (sp_int r = 0; r < nrows; r++) {
        sp_RbVal rv = rows->data[r];
        sp_ofloat val = sp_ofloat_nil();
        if (rv.tag == SP_TAG_OBJ && rv.cls_id == SP_BUILTIN_FLT_ARRAY) {
          sp_FloatArray *row = (sp_FloatArray *)rv.v.p;
          if (c < row->len) val = sp_FloatArray_oget(row, c);
        }
        sp_FloatArray_push_o(col, val);
      }
      cv.tag = SP_TAG_OBJ; cv.cls_id = SP_BUILTIN_FLT_ARRAY; cv.v.p = col;
    }
else if (kind == SP_BUILTIN_STR_ARRAY) {
      sp_StrArray *col = sp_StrArray_new();
      SP_GC_ROOT(col);
      for (sp_int r = 0; r < nrows; r++) {
        sp_RbVal rv = rows->data[r];
        const char *val = sp_str_empty;
        if (rv.tag == SP_TAG_OBJ && rv.cls_id == SP_BUILTIN_STR_ARRAY) {
          sp_StrArray *row = (sp_StrArray *)rv.v.p;
          if (c < row->len && row->data[c]) val = row->data[c];
        }
        sp_StrArray_push(col, val);
      }
      cv.tag = SP_TAG_OBJ; cv.cls_id = SP_BUILTIN_STR_ARRAY; cv.v.p = col;
    }
    else if (kind == SP_BUILTIN_POLY_ARRAY) {
      /* Mixed row kinds need boxed columns; read each row in its own
         representation, preserving nils and pointer-array elements. */
      sp_PolyArray *col = sp_PolyArray_new();
      SP_GC_ROOT(col);
      for (sp_int r = 0; r < nrows; r++) {
        sp_RbVal rv = rows->data[r];
        sp_RbVal val = sp_box_nil();
        if (rv.tag == SP_TAG_OBJ && rv.cls_id == SP_BUILTIN_POLY_ARRAY) {
          sp_PolyArray *row = (sp_PolyArray *)rv.v.p;
          if (c < row->len) val = row->data[c];
        }
        else if (rv.cls_id == SP_BUILTIN_INT_ARRAY)
          val = sp_box_oint(sp_IntArray_oget((sp_IntArray *)rv.v.p, c));
        else if (rv.cls_id == SP_BUILTIN_SYM_ARRAY)
          val = sp_box_sym((sp_sym)sp_IntArray_get((sp_IntArray *)rv.v.p, c));
        else if (rv.cls_id == SP_BUILTIN_FLT_ARRAY)
          val = sp_box_ofloat(sp_FloatArray_oget((sp_FloatArray *)rv.v.p, c));
        else if (rv.cls_id == SP_BUILTIN_STR_ARRAY)
          val = sp_box_str(sp_StrArray_get((sp_StrArray *)rv.v.p, c));
        else if (rv.tag == SP_TAG_OBJ && rv.cls_id == SP_BUILTIN_PTR_ARRAY)
          val = sp_PtrArray_get_box((sp_PtrArray *)rv.v.p, c);
        sp_PolyArray_push(col, val);
      }
      cv.tag = SP_TAG_OBJ; cv.cls_id = SP_BUILTIN_POLY_ARRAY; cv.v.p = col;
    }
    sp_PolyArray_push(result, cv);
  }
  return result;
}

sp_PolyArray *sp_str_chars_poly(const char *s) {SP_GC_ROOT_STR(s);
  sp_PolyArray *a = sp_PolyArray_new();
  SP_GC_ROOT(a);
  if (!s) sp_nil_recv("chars");
  /* to the recorded byte length, not to the first NUL: a NUL is an ordinary
     character and the ones after it are real (#3473) */
  int bin = sp_str_is_binary(s);
  const char *end = s + sp_str_byte_len(s);
  for (const char *p = s; p < end; ) {
    int n = bin ? 1 : sp_utf8_advance(p);
    if (p + n > end) n = (int)(end - p);
    char *c = sp_str_alloc(n); memcpy(c, p, n); c[n] = 0;
    sp_PolyArray_push(a, sp_box_str(c));
    p += n;
  }
  return a;
}

/* ---- Native backtrace formatting (spinel --debug) ----
   Moved from spinel_rt.h. The capture itself (backtrace() at raise time)
   stays in the header next to sp_raise_cls; only the cold symbol->Ruby-frame
   formatting lives here. The two flag globals are defined here so the
   debug-build main() (generated TU) and the header callers share one copy. */
#ifdef HAVE_EXECINFO_H
#include <execinfo.h>
#else
/* No execinfo.h: provide no-op shims so the formatting code below compiles
   and links unchanged. backtrace_symbols returns NULL, which the formatter
   treats as "nothing to format" -- the backtrace is simply empty. */
#define backtrace_symbols(buf, n) ((char **)0)
#endif
#include "sp_exc.h"     /* sp_bt_block */
int sp_bt_enabled = 0;          /* set to 1 by debug-build main() */
const char *sp_bt_srcfile = ""; /* toplevel .rb path, set by debug main() */
const char *const *sp_bt_files = 0;
const sp_bt_block *sp_bt_blocks = 0;
int sp_bt_nblocks = 0;
static int sp_bt_is_runtime(const char *n) {
  static const char *pfx[] = {
    "int_", "str_", "float_", "sym_", "gc_", "bigint", "sprintf", "raise",
    "exc_", "range", "utf8", "oom", "bt_", "backtrace", "caller", "StrArray",
    "IntArray", "FloatArray", "PtrArray", "PolyArray", "Str", "Int", "Float",
    "Hash", "Range", "Complex", "Rational", "Sym", "alloc", "free", "to_s",
    "dup", "new", "pack", "unpack", "regex", "re_",
    /* arithmetic/runtime helpers that can raise and sit between the raise
       and the user frame (ZeroDivisionError via sp_idiv/sp_imod, etc.) */
    "idiv", "imod", "gcd", "fdiv", "ipow", "iclamp", "div_", "mod_",
    /* the trampoline that puts the body on its own stack: runtime, not a
       Ruby frame, and it sits below every frame of the program */
    "main_stack", 0
  };
  for (int i = 0; pfx[i]; i++) {
    size_t l = strlen(pfx[i]);
    if (strncmp(n, pfx[i], l) == 0) return 1;
  }
  return 0;
}

/* Extract the symbol token from a backtrace_symbols line. Two formats:
     - glibc/Linux: "<module>(<symbol>+0x<off>) [0x<addr>]". The symbol is
       empty for unresolved frames (static or stripped fns) -> skip.
     - macOS:       "<idx> <image> <addr> <symbol> + <off>".
   Returns NULL if it isn't a keepable user frame. Detect Linux by the '('
   that delimits the symbol (the macOS format has none). */
static const char *sp_bt_symbol(const char *line, char *raw, size_t rawcap) {
  char sym[256];
  const char *lp = strchr(line, '(');
  if (lp) {                                       /* glibc/Linux paren form */
    const char *p = lp + 1;
    const char *end = p;
    while (*end && *end != '+' && *end != ')') end++;
    size_t len = (size_t)(end - p);
    if (len == 0 || len > 250) return 0;          /* unresolved (static/stripped) */
    memcpy(sym, p, len); sym[len] = 0;
  }
else {                                        /* macOS: "<idx> <image> <addr> <symbol> + <off>" */
    /* The symbol is the token just before the " + <off>" delimiter. Parse
       backward from the last " + " rather than forward from "0x" -- an image
       path containing "0x" (e.g. /path/0x_proj/bin) would otherwise misparse. */
    const char *plus = 0, *q = line;
    while ((q = strstr(q, " + ")) != 0) { plus = q; q += 3; }
    if (!plus) return 0;
    const char *end = plus;
    const char *p = end;
    while (p > line && p[-1] != ' ') p--;          /* back up to the symbol's start */
    size_t len = (size_t)(end - p);
    if (len == 0 || len > 250) return 0;
    memcpy(sym, p, len); sym[len] = 0;
  }
  if (raw && rawcap) snprintf(raw, rawcap, "%s", sym);
  /* The top level runs in the emitted body function, which the compiler
     hands to sp_main_stack_run (see lib/sp_fiber.c). That frame IS `<main>`;
     the C `main` beside it is the trampoline, on the other stack, and an
     unwinder that reaches it would name the same Ruby frame twice. */
  if (strcmp(sym, "main") == 0 || strcmp(sym, "_sp_main_body") == 0)
    return strdup("<main>");
  if (strncmp(sym, "sp_", 3) != 0) return 0;     /* skip non-Spinel frames */
  const char *name = sym + 3;
  if (sp_bt_is_runtime(name)) return 0;
  /* De-mangle sp_<Class>_<method> back to Ruby. A Spinel symbol is a path of
     CamelCase class segments (each from a `::`, joined by `_`) followed by the
     method; the method is the first segment that starts lowercase. A literal
     `s` (what the emitter writes) or `cls` segment marks a singleton method:
       sp_Helper_s_boom            -> Helper.boom
       sp_Helper_cls_boom          -> Helper.boom
       sp_Tep_Url_parse_query      -> Tep::Url#parse_query
       sp_Tep_AuthOAuth2_cls_find  -> Tep::AuthOAuth2.find
       sp_toplevel                 -> toplevel   (top-level method, no class)
     (Method names stay sanitized -- e.g. enabled? is enabled_p; reversing that
     needs the emitted name table, a separate refinement.) */
  const char *mstart = 0;   /* first lowercase-starting segment = the method */
  for (const char *p = name; *p; p++) {
    int seg_start = (p == name) || (p[-1] == '_');
    if (seg_start && *p >= 'a' && *p <= 'z') { mstart = p; break; }
  }
  if (!mstart) return strdup(name);            /* all-uppercase: leave as-is */
  if (mstart == name) {                        /* no class path: top-level */
    if (strncmp(name, "cls_", 4) == 0) return strdup(name + 4);  /* top-level singleton */
    if (strncmp(name, "s_", 2) == 0) return strdup(name + 2);
    return strdup(name);
  }
  char out[256]; size_t o = 0;
  const char *meth; char sep;
  if (strncmp(mstart, "cls_", 4) == 0) { meth = mstart + 4; sep = '.'; }  /* singleton */
  else if (strncmp(mstart, "s_", 2) == 0) { meth = mstart + 2; sep = '.'; }
  else                                 { meth = mstart;     sep = '#'; }  /* instance */
  for (const char *p = name; p < mstart - 1 && o + 2 < sizeof(out); p++) {
    if (*p == '_') { out[o++] = ':'; out[o++] = ':'; }   /* class-path `_` was a `::` */
    else out[o++] = *p;
  }
  if (o + 1 < sizeof(out)) out[o++] = sep;
  size_t ml = strlen(meth);
  if (o + ml < sizeof(out)) { memcpy(out + o, meth, ml); o += ml; }
  out[o] = 0;
  return strdup(out);
}

#if defined(__linux__) && defined(HAVE_EXECINFO_H)
#include <dlfcn.h>
#include <elf.h>
#include <link.h>
/* The source line of each return address, from the DWARF the debug build
   carries: addr2line reads the program's own file, and the generated C's #line
   directives make the line one of the .rb source. Run once per backtrace, for
   every frame, only under --debug; a build without addr2line, or an address
   without a line, leaves the frame without one (lines[i] stays 0). A return
   address is one past the call, so the call's own line is asked at addr - 1.
   The file of the line goes to files[i] (malloc'd), for sp_bt_block_depth. */
static void sp_bt_lines(void **buf, int n, int *lines, char **files) {
  char exe[1024];
  ssize_t el = readlink("/proc/self/exe", exe, sizeof exe - 1);
  if (el <= 0) return;
  exe[el] = 0;   /* readlink writes no NUL: end the path before searching it */
  if (strchr(exe, '\'')) return;
  Dl_info di;
  if (!dladdr(buf[0], &di) || !di.dli_fbase) return;
  const ElfW(Ehdr) *eh = (const ElfW(Ehdr) *)di.dli_fbase;
  uintptr_t bias = eh->e_type == ET_DYN ? (uintptr_t)di.dli_fbase : 0;
  char cmd[4096];
  int o = snprintf(cmd, sizeof cmd, "addr2line -e '%s'", exe);
  for (int i = 0; i < n && o < (int)sizeof cmd - 32; i++)
    o += snprintf(cmd + o, sizeof cmd - (size_t)o, " 0x%lx", (unsigned long)((uintptr_t)buf[i] - 1 - bias));
  FILE *p = popen(cmd, "r");
  if (!p) return;
  char line[2048];
  for (int i = 0; i < n && fgets(line, sizeof line, p); i++) {
    char *c = strrchr(line, ':');
    if (c && c[1] >= '1' && c[1] <= '9') {
      lines[i] = atoi(c + 1);
      if (files) files[i] = strndup(line, (size_t)(c - line));
    }
  }
  pclose(p);
}
#elif defined(__APPLE__) && defined(HAVE_EXECINFO_H)
#include <mach-o/dyld.h>
/* The same on macOS through atos, which reads the dSYM a debug build leaves
   beside the program (clang writes it when it compiles and links in one
   step). The main image's load address is handed over with -l, so the
   run-time addresses are asked as they are; each answer line ends in
   "(file:line)". */
static void sp_bt_lines(void **buf, int n, int *lines, char **files) {
  char exe[1024];
  uint32_t el = sizeof exe;
  if (_NSGetExecutablePath(exe, &el) != 0 || strchr(exe, '\'')) return;
  const struct mach_header *mh = _dyld_get_image_header(0);
  if (!mh) return;
  char cmd[4096];
  int o = snprintf(cmd, sizeof cmd, "atos -o '%s' -l 0x%lx", exe, (unsigned long)(uintptr_t)mh);
  for (int i = 0; i < n && o < (int)sizeof cmd - 32; i++)
    o += snprintf(cmd + o, sizeof cmd - (size_t)o, " 0x%lx", (unsigned long)((uintptr_t)buf[i] - 1));
  if (o < (int)sizeof cmd - 16) snprintf(cmd + o, sizeof cmd - (size_t)o, " 2>/dev/null");
  FILE *p = popen(cmd, "r");
  if (!p) return;
  char line[2048];
  for (int i = 0; i < n && fgets(line, sizeof line, p); i++) {
    char *close = strrchr(line, ')');
    char *open = close ? strrchr(line, '(') : NULL;
    char *c = open ? strrchr(open, ':') : NULL;
    if (c && c < close && c[1] >= '1' && c[1] <= '9') {
      lines[i] = atoi(c + 1);
      if (files) files[i] = strndup(open + 1, (size_t)(c - open - 1));
    }
  }
  pclose(p);
}
#else
static void sp_bt_lines(void **buf, int n, int *lines, char **files) { (void)buf; (void)n; (void)lines; (void)files; }
#endif

/* Do two spellings name one source file? addr2line answers the path the
   #line directive gave, atos only its base name: equal, or the longer ends
   in "/" + the shorter. */
static int sp_bt_same_file(const char *a, const char *b) {
  size_t la = strlen(a), lb = strlen(b);
  if (la < lb) { const char *t = a; a = b; b = t; size_t tl = la; la = lb; lb = tl; }
  if (strcmp(a + (la - lb), b) != 0) return 0;
  return la == lb || a[la - lb - 1] == '/';
}

/* How many blocks deep the frame of C symbol sym is at file:line, from the
   table codegen emits (bt_block_table); 0 for a line not in it. */
static int sp_bt_block_depth(const char *sym, const char *file, int line) {
  if (!file || line <= 0) return 0;
  for (int i = 0; i < sp_bt_nblocks; i++) {
    const sp_bt_block *b = &sp_bt_blocks[i];
    if (b->line == line && strcmp(b->sym, sym) == 0 && sp_bt_same_file(b->file, file)) return b->depth;
  }
  return 0;
}

sp_StrArray *sp_bt_format(void **buf, int n) {
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  if (!sp_bt_enabled || n <= 0) return a;
  char **syms = backtrace_symbols(buf, n);
  if (!syms) return a;
  const char *src = (sp_bt_srcfile && sp_bt_srcfile[0]) ? sp_bt_srcfile : "(spinel)";
  int *lines = (int *)calloc((size_t)n, sizeof *lines);
  char **lfiles = (char **)calloc((size_t)n, sizeof *lfiles);
  if (lines) sp_bt_lines(buf, n, lines, lfiles);
  for (int i = 0; i < n; i++) {
    char raw[256]; raw[0] = 0;
    char *name = (char *)sp_bt_symbol(syms[i], raw, sizeof raw);  /* always strdup'd; free after use */
    if (!name) continue;
    /* a method of a required file names that file, not the entry script */
    const char *file = src;
    if (sp_bt_files)
      for (const char *const *f = sp_bt_files; f[0]; f += 2)
        if (strcmp(f[0], raw) == 0) { file = f[1]; break; }
    /* a line inside a block run in the method's own function: CRuby's
       `block in X`, `block (2 levels) in X` */
    int depth = (lines && lfiles) ? sp_bt_block_depth(raw, lfiles[i], lines[i]) : 0;
    if (depth > 0) {
      char bn[320];
      if (depth == 1) snprintf(bn, sizeof bn, "block in %s", name);
      else snprintf(bn, sizeof bn, "block (%d levels) in %s", depth, name);
      free(name);
      name = strdup(bn);
    }
    if (lines && lines[i] > 0) sp_StrArray_push(a, sp_sprintf("%s:%d:in `%s'", file, lines[i], name));
    else sp_StrArray_push(a, sp_sprintf("%s:in `%s'", file, name));
    free(name);
  }
  if (lfiles) for (int i = 0; i < n; i++) free(lfiles[i]);
  free(lfiles);
  free(lines);
  free(syms);
  return a;
}

#include <fcntl.h>
#include <sys/file.h>
#include <pwd.h>
#include "sp_sched.h"   /* sp_native_enter / sp_native_leave for a waiting flock */
#include <sys/wait.h>

/* ---- File / Dir surface ops moved from spinel_rt.h ----
   Path-level libc wrappers (stat family, Dir handle ops, FileTest
   helpers): cold, and every dependency is lib-visible. Prototypes
   first: the bodies keep their original header order, but a few
   helpers were forward-referenced there. */
const char *sp_File_gets_sep(sp_File *f, const char *sep, sp_int limit, sp_bool chomp);
sp_StrArray *sp_File_readlines_sep(sp_File *f, const char *sep, sp_bool chomp);
sp_StrArray *sp_file_readlines_sep(const char *path, const char *sep, sp_bool chomp);
const char *sp_File_readline_sep(sp_File *f, const char *sep, sp_int limit, sp_bool chomp);
const char *sp_File_getc(sp_File *f);
const char *sp_File_readchar(sp_File *f);
sp_oint sp_File_getbyte(sp_File *f);
sp_RbVal sp_File_ungetc(sp_File *f, sp_RbVal v);
const char *sp_File_readpartial(sp_File *f, sp_int n);
sp_int sp_File_sysseek(sp_File *f, sp_int off, sp_int whence);
sp_RbVal sp_File_flock(sp_File *f, sp_int op);
sp_int sp_File_fsync(sp_File *f);
sp_RbVal sp_File_putc(sp_File *f, sp_RbVal v);
SP_NORETURN void sp_raise_nil_to_int(int of_wording);
const char *sp_file_ftype(const char *path);
sp_bool sp_file_readable(const char *path);
sp_bool sp_file_writable(const char *path);
sp_bool sp_file_executable(const char *path);
sp_bool sp_file_readable_real(const char *path);
sp_bool sp_file_writable_real(const char *path);
sp_bool sp_file_executable_real(const char *path);
const char *sp_file_realdirpath(const char *path);
sp_Addrinfo *sp_addrinfo_new(const char *ip, sp_int port, sp_int stype, sp_int is_unix);
const char *sp_addrinfo_inspect(sp_Addrinfo *a);
sp_SockOpt *sp_sockopt_new(sp_int family, sp_int level, sp_int optname, sp_int value);
const char *sp_sockopt_inspect(sp_SockOpt *o);
sp_File *sp_io_for_fd(sp_int fd, const char *mode, sp_bool autoclose);
sp_File *sp_io_wait_events(sp_File *f, double timeout, sp_int kind);
sp_RbVal sp_io_select(sp_PolyArray *rd, sp_PolyArray *wr, sp_PolyArray *er, double timeout);
sp_oint sp_file_size_q(const char *path);
sp_bool sp_file_pipe(const char *path);
sp_bool sp_file_identical(const char *a, const char *b);
const char *sp_file_realpath(const char *path);
const char *sp_file_read_len(const char *path, sp_int n);
sp_int sp_file_chmod(sp_int mode, const char *path);
sp_int sp_file_truncate(const char *path, sp_int n);
sp_int sp_file_write_at(const char *path, const char *data, sp_int off);
sp_int sp_file_write_mode(const char *path, const char *data, const char *mode);
sp_int sp_file_write_perm(const char *path, const char *data, const char *mode, sp_oint perm);
sp_File *sp_File_open_flags(const char *path, sp_int fl);
sp_File *sp_File_open_flags_perm(const char *path, sp_int fl, sp_oint perm);
void sp_file_stat_scan(void *p);
sp_File *sp_file_stat_handle(const char *path);
sp_int sp_file_stat_mode(const char *path);
sp_bool sp_file_fnmatch(const char *pat, const char *path, sp_int flags);
sp_StrArray *sp_file_split(const char *path);
sp_bool sp_file_zero(const char *path);
const char *sp_file_dirname(const char *path);
const char *sp_dir_pwd(void);
sp_int sp_dir_mkdir(const char *path);
sp_int sp_dir_rmdir(const char *path);
sp_int sp_dir_chdir(const char *path);
const char *sp_dir_home(void);
void sp_Dir_fin(void *p);
void sp_Dir_scan(void *p);
sp_Dir *sp_Dir_new(const char *path);
sp_Dir *sp_Dir_for_fd(sp_int fd);
sp_StrArray *sp_Dir_entries_h(sp_Dir *d, sp_int children);
sp_int sp_Dir_fchdir(sp_int fd);
const char *sp_Dir_read(sp_Dir *d);
const char *sp_Dir_path(sp_Dir *d);
sp_RbVal sp_Dir_close(sp_Dir *d);
sp_Dir *sp_Dir_rewind(sp_Dir *d);
sp_int sp_Dir_tell(sp_Dir *d);
sp_Dir *sp_Dir_seek(sp_Dir *d, sp_int pos);
sp_int sp_Dir_fileno(sp_Dir *d);
sp_StrArray *sp_dir_entries(const char *path);
sp_bool sp_dir_empty(const char *path);
const char *sp_dir_home_user(const char *user);
sp_StrArray *sp_dir_children(const char *path);

/* Does the UTF-8 text s[0..len) end inside a valid character, one that more
   bytes could complete? A lead byte that can start no character (C0, C1, F5
   and up), or a second byte out of the range its lead allows, is invalid at
   once and is not waited for. */
static int sp_File_tail_incomplete(const unsigned char *s, size_t len) {
  size_t i = len;
  int back = 0;
  while (i > 0 && back < 3 && (s[i - 1] & 0xC0) == 0x80) { i--; back++; }
  if (i == 0) return 0;
  unsigned char lead = s[i - 1];
  if (lead < 0xC2 || lead > 0xF4) return 0;
  if (back >= 1) {
    unsigned char lo = 0x80, hi = 0xBF, c1 = s[i];
    if (lead == 0xE0) lo = 0xA0;
    else if (lead == 0xED) hi = 0x9F;
    else if (lead == 0xF0) lo = 0x90;
    else if (lead == 0xF4) hi = 0x8F;
    if (c1 < lo || c1 > hi) return 0;
  }
  int need = lead >= 0xF0 ? 4 : lead >= 0xE0 ? 3 : 2;
  return need > back + 1;
}

const char *sp_File_gets_sep(sp_File *f, const char *sep, sp_int limit, sp_bool chomp) {SP_GC_ROOT(f);SP_GC_ROOT_STR(sep);
  SP_IO_OPEN(f);
  sp_io_wait_readable(f);
  SP_IO_OPEN(f);   /* the park can return after another thread closed the handle */
  /* an empty separator is paragraph mode, a nil one (NULL) reads to the end;
     a separator that starts with a NUL byte is not empty (strlen cannot tell) */
  int para = sep && sep[0] == '\0' && sp_str_byte_len(sep) == 0;
  if (para) sep = "\n\n";
  size_t sl = para ? 2 : sp_str_byte_len(sep);
  /* fast path: the default "\n" separator with no limit reads via getline
     (the byte-wise loop below costs a call per character). getline answers
     the line whole, however long, with its byte count, so a NUL inside it
     neither ends the line nor drops what follows, and its buffer is on the
     heap, off the 64KB fiber stack. */
  if (sl == 1 && sep[0] == '\n' && limit <= 0) {
    char *buf = NULL;
    size_t bcap = 0;
    ssize_t got = getline(&buf, &bcap, f->fp);
    if (got < 0) { free(buf); return NULL; }
    size_t n = (size_t)got;
    /* chomp takes the "\r\n" of a line as well as its "\n" */
    if (chomp && n && buf[n - 1] == '\n') { n--; if (n && buf[n - 1] == '\r') n--; }
    char *r = sp_str_alloc(n);
    memcpy(r, buf, n); r[n] = 0;
    free(buf);
    sp_str_set_len(r, n);
    f->lineno++;
    return r;
  }
  size_t cap = 256, len = 0;
  char *buf = (char *)malloc(cap);
  if (!buf) return NULL;
  int ch;
  /* a paragraph does not start with blank lines */
  if (para) {
    while ((ch = fgetc(f->fp)) == '\n') { }
    if (ch != EOF) ungetc(ch, f->fp);
  }
  int ended = 0, extra = 16;
  sp_int lim = limit;
  while ((ch = fgetc(f->fp)) != EOF) {
    if (len + 2 > cap) { cap *= 2; char *nb = (char *)realloc(buf, cap); if (!nb) { free(buf); return NULL; } buf = nb; }
    buf[len++] = (char)ch;
    /* as CRuby's getline: a byte that ends the separator is not checked
       against the limit while fewer bytes than the separator are read, or
       while the separator would start inside a character, and a limit
       passed unchecked never stops that line */
    if (sl && (unsigned char)ch == (unsigned char)sep[sl - 1]) {
      if (len < sl) continue;
      if (((unsigned char)buf[len - sl] & 0xC0) == 0x80 && len > sl) continue;
      if (memcmp(buf + len - sl, sep, sl) == 0) { ended = 1; break; }
    }
    if (lim > 0 && (sp_int)len == lim) {
      /* as CRuby's getline: a limit that falls inside a character reads on to
         its end (by up to 16 bytes) */
      if (extra > 0 && sp_File_tail_incomplete((const unsigned char *)buf, len)) { lim = (sp_int)len + 1; extra--; continue; }
      break;
    }
  }
  /* and the blank lines after one are not part of the next */
  if (para && ended) {
    while ((ch = fgetc(f->fp)) == '\n') { }
    if (ch != EOF) ungetc(ch, f->fp);
  }
  if (len == 0) { free(buf); return NULL; }
  if (chomp && ended && sl && len >= sl && memcmp(buf + len - sl, sep, sl) == 0) {
    len -= sl;
    if (sl == 1 && sep[0] == '\n' && len && buf[len - 1] == '\r') len--;
  }
  char *r = sp_str_alloc(len);
  memcpy(r, buf, len); r[len] = 0;
  sp_str_set_len(r, len);
  free(buf);
  f->lineno++;
  return r;
}
sp_StrArray *sp_File_readlines_sep(sp_File *f, const char *sep, sp_bool chomp) {SP_GC_ROOT(f);SP_GC_ROOT_STR(sep);
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  const char *l;
  while ((l = sp_File_gets_sep(f, sep, 0, chomp)) != NULL) sp_StrArray_push(a, l);
  return a;
}
sp_StrArray *sp_file_readlines_sep(const char *path, const char *sep, sp_bool chomp) {SP_GC_ROOT_STR(path);SP_GC_ROOT_STR(sep);
  sp_File *f = sp_File_open(path, "r");
  SP_GC_ROOT(f);
  sp_StrArray *a = sp_File_readlines_sep(f, sep, chomp);
  sp_File_close(f);
  return a;
}
const char *sp_File_readline_sep(sp_File *f, const char *sep, sp_int limit, sp_bool chomp) {SP_GC_ROOT(f);SP_GC_ROOT_STR(sep);
  const char *r = sp_File_gets_sep(f, sep, limit, chomp);
  if (!r) sp_raise_cls("EOFError", "end of file reached");
  return r;
}
const char *sp_File_getc(sp_File *f) {SP_GC_ROOT(f);
  SP_IO_OPEN(f);
  sp_io_wait_readable(f);
  int ch = fgetc(f->fp);
  if (ch == EOF) return NULL;
  /* A binary handle (a socket, a File opened "rb", one put in binmode or
     given ASCII-8BIT by set_encoding) has one-byte characters: reading on after a byte that looks like a UTF-8
     lead took the next bytes with it, and on a socket waited for bytes the
     peer had not sent (#7312). */
  int bin = sp_File_reads_binary(f);
  int extra = bin ? 0 : ((ch & 0xE0) == 0xC0) ? 1 : ((ch & 0xF0) == 0xE0) ? 2 : ((ch & 0xF8) == 0xF0) ? 3 : 0;
  char *r = sp_str_alloc((size_t)(1 + extra));
  size_t n = 0;
  r[n++] = (char)ch;
  for (int i = 0; i < extra; i++) {
    int c2 = fgetc(f->fp);
    if (c2 == EOF) break;
    r[n++] = (char)c2;
  }
  r[n] = 0;
  sp_str_set_len(r, n);
  if (bin) sp_str_mark_binary(r);
  return r;
}
const char *sp_File_readchar(sp_File *f) {SP_GC_ROOT(f);
  const char *r = sp_File_getc(f);
  if (!r) sp_raise_cls("EOFError", "end of file reached");
  return r;
}
sp_oint sp_File_getbyte(sp_File *f) {
  SP_IO_OPEN(f);
  sp_io_wait_readable(f);
  int ch = fgetc(f->fp);
  return ch == EOF ? sp_oint_nil() : sp_oint_of((sp_int)ch);
}
sp_RbVal sp_File_ungetc(sp_File *f, sp_RbVal v) {
  SP_IO_OPEN(f);
  if (v.tag == SP_TAG_STR && v.v.s && v.v.s[0]) {
    size_t n = sp_str_byte_len(v.v.s);
    for (size_t i = n; i > 0; i--) ungetc((unsigned char)v.v.s[i - 1], f->fp);
  }
  else if (v.tag == SP_TAG_INT) ungetc((int)v.v.i, f->fp);
  return sp_box_nil();
}
sp_int sp_File_sysseek(sp_File *f, sp_int off, sp_int whence) {
  SP_IO_OPEN(f);
  fseek(f->fp, (long)off, whence == 1 ? SEEK_CUR : whence == 2 ? SEEK_END : SEEK_SET);
  return (sp_int)ftell(f->fp);
}
/* A blocking flock may be waiting on another thread of this program,
   and that thread may need a GC before it can unlock. So we leave the
   world while we wait, like a `blocking: true` FFI call, and the GC
   doesn't wait for us. EINTR retries instead of failing. */
sp_RbVal sp_File_flock(sp_File *f, sp_int op) {
  SP_IO_OPEN(f);
  int fd = fileno(f->fp);
  int r;
  if (op & LOCK_NB) {
    r = flock(fd, (int)op);
  }
  else {
    sp_native_enter();
    while ((r = flock(fd, (int)op)) != 0 && errno == EINTR) {}
    int e = errno;   /* sp_native_leave may run GC work that changes it */
    sp_native_leave();
    errno = e;
  }
  if (r == 0) return sp_box_int(0);
  /* a LOCK_NB request on a held lock answers false, as CRuby's does */
  if ((op & LOCK_NB) && (errno == EWOULDBLOCK || errno == EAGAIN)) return sp_box_bool(0);
  sp_file_raise_errno("rb_file_flock", f->path);
}
sp_int sp_File_fsync(sp_File *f) {
  SP_IO_OPEN(f);
  fflush(f->fp);
  fsync(fileno(f->fp));
  return 0;
}
sp_RbVal sp_File_putc(sp_File *f, sp_RbVal v) {
  SP_IO_OPEN(f);
  if (v.tag == SP_TAG_INT) fputc((int)(v.v.i & 0xff), f->fp);
  else if (v.tag == SP_TAG_STR) { if (v.v.s && v.v.s[0]) fputc(v.v.s[0], f->fp); }
  /* anything else is no character: CRuby converts it as an Integer and
     raises for nil (the boxed nil wrote nothing and answered nil) */
  else if (v.tag == SP_TAG_NIL) sp_raise_nil_to_int(0);
  else if (v.tag == SP_TAG_FLT && v.v.f > -9.0e18 && v.v.f < 9.0e18) fputc((int)((sp_int)v.v.f & 0xff), f->fp);
  else if (v.tag == SP_TAG_BOOL)
    sp_raise_cls("TypeError", v.v.b ? "no implicit conversion of true into Integer" : "no implicit conversion of false into Integer");
  return v;
}
const char *sp_file_ftype(const char *path) {SP_GC_ROOT_STR(path);
  struct stat st;
  if (lstat(path ? path : "", &st) != 0)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ rb_file_s_ftype - %s", path ? path : ""));
  if (S_ISREG(st.st_mode)) return (&("\xff" "file")[1]);
  if (S_ISDIR(st.st_mode)) return (&("\xff" "directory")[1]);
  if (S_ISLNK(st.st_mode)) return (&("\xff" "link")[1]);
  if (S_ISFIFO(st.st_mode)) return (&("\xff" "fifo")[1]);
  if (S_ISCHR(st.st_mode)) return (&("\xff" "characterSpecial")[1]);
  if (S_ISBLK(st.st_mode)) return (&("\xff" "blockSpecial")[1]);
#ifdef S_ISSOCK
  if (S_ISSOCK(st.st_mode)) return (&("\xff" "socket")[1]);
#endif
  return (&("\xff" "unknown")[1]);
}
/* The `_real?` predicates test the real uid/gid, which is exactly what
   access(2) does; their plain counterparts test the effective ids, which needs
   AT_EACCESS. Routing both through access() would make File.readable? answer
   for the wrong identity in a setuid program. */
static sp_bool sp_file_access_eff(const char *path, int mode) {
  return faccessat(AT_FDCWD, path ? path : "", mode, AT_EACCESS) == 0;
}
sp_bool sp_file_readable(const char *path)   {SP_GC_ROOT_STR(path); return sp_file_access_eff(path, R_OK); }
sp_bool sp_file_writable(const char *path)   {SP_GC_ROOT_STR(path); return sp_file_access_eff(path, W_OK); }
sp_bool sp_file_executable(const char *path) {SP_GC_ROOT_STR(path); return sp_file_access_eff(path, X_OK); }
sp_bool sp_file_readable_real(const char *path)   { return access(path ? path : "", R_OK) == 0; }
sp_bool sp_file_writable_real(const char *path)   { return access(path ? path : "", W_OK) == 0; }
sp_bool sp_file_executable_real(const char *path) { return access(path ? path : "", X_OK) == 0; }
sp_oint sp_file_size_q(const char *path) {   /* Integer size, or nil for missing/empty */
  struct stat st;
  if (stat(path ? path : "", &st) != 0 || st.st_size == 0) return sp_oint_nil();
  return sp_oint_of((sp_int)st.st_size);
}
sp_bool sp_file_pipe(const char *path) {
  struct stat st;
  return stat(path ? path : "", &st) == 0 && S_ISFIFO(st.st_mode);
}
sp_bool sp_file_identical(const char *a, const char *b) {
  struct stat sa, sb;
  if (stat(a ? a : "", &sa) != 0 || stat(b ? b : "", &sb) != 0) return 0;
  return sa.st_dev == sb.st_dev && sa.st_ino == sb.st_ino;
}
const char *sp_file_realpath(const char *path) {SP_GC_ROOT_STR(path);
  char buf[4096];
  if (!realpath(path ? path : "", buf))
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ realpath_rec - %s", path ? path : ""));
  return sp_sprintf("%s", buf);
}
/* realdirpath resolves every component but the last, so it answers for a name
   that does not exist yet -- where realpath raises Errno::ENOENT. */
const char *sp_file_realdirpath(const char *path) {
  const char *p = path ? path : "";
  char buf[4096];
  if (realpath(p, buf)) return sp_sprintf("%s", buf);
  const char *slash = strrchr(p, '/');
  const char *base = slash ? slash + 1 : p;
  char dir[4096];
  if (!slash) snprintf(dir, sizeof dir, ".");
  else if (slash == p) snprintf(dir, sizeof dir, "/");
  else snprintf(dir, sizeof dir, "%.*s", (int)(slash - p), p);
  if (!realpath(dir, buf))
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ realpath_rec - %s", dir));
  if (!*base || strcmp(base, ".") == 0) return sp_sprintf("%s", buf);
  if (strcmp(buf, "/") == 0) return sp_sprintf("/%s", base);
  return sp_sprintf("%s/%s", buf, base);
}
#if defined(_WIN32)
sp_bool sp_file_absolute_path_p(const char *path) { return sp_file_path_root_len(path) > 0; }  /* "/", "C:/" */
#else
sp_bool sp_file_absolute_path_p(const char *path) { return path && path[0] == '/'; }  /* (#2988) */
#endif
sp_int sp_file_chown(const char *path, sp_int uid, sp_int gid) {SP_GC_ROOT_STR(path);  /* -1 leaves that id unchanged; returns the path count (#2987) */
  if (chown(path ? path : "", (uid_t)uid, (gid_t)gid) != 0)
    sp_raise_cls("Errno::ENOENT", sp_sprintf("No such file or directory - %s", path ? path : ""));
  return 1;
}
const char *sp_file_read_len(const char *path, sp_int n) {SP_GC_ROOT_STR(path);
  FILE *fp = fopen(path ? path : "", "rb");
  if (!fp)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ rb_sysopen - %s", path ? path : ""));
  if (n < 0) n = 0;
  char *r = sp_str_alloc(n);
  size_t got = fread(r, 1, (size_t)n, fp);
  fclose(fp);
  r[got] = 0;
  sp_str_set_len(r, got);
  return r;
}
sp_int sp_file_chmod(sp_int mode, const char *path) {SP_GC_ROOT_STR(path);
  if (chmod(path ? path : "", (mode_t)mode) != 0)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ apply2files - %s", path ? path : ""));
  return 1;
}
sp_int sp_file_truncate(const char *path, sp_int n) {SP_GC_ROOT_STR(path);
  sp_file_path_check(path);
  if (truncate(path, (off_t)n) != 0) sp_file_raise_errno("rb_file_s_truncate", path);
  return 0;
}
sp_int sp_file_write_at(const char *path, const char *data, sp_int off) {SP_GC_ROOT_STR(path);SP_GC_ROOT_STR(data);
  int fd = open(path ? path : "", O_WRONLY | O_CREAT, 0666);
  if (fd < 0)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ rb_sysopen - %s", path ? path : ""));
  size_t n = sp_str_byte_len(data ? data : sp_str_empty);
  ssize_t w = pwrite(fd, data ? data : "", n, (off_t)off);
  close(fd);
  return w < 0 ? 0 : (sp_int)w;
}
sp_int sp_file_write_mode(const char *path, const char *data, const char *mode) {SP_GC_ROOT_STR(path);SP_GC_ROOT_STR(data);
  FILE *fp = fopen(path ? path : "", mode && mode[0] ? mode : "w");
  if (!fp)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ rb_sysopen - %s", path ? path : ""));
  size_t n = sp_str_byte_len(data ? data : sp_str_empty);
  size_t w = fwrite(data ? data : "", 1, n, fp);
  int err = (w < n || ferror(fp)) ? (errno ? errno : EIO) : 0;
  if (fclose(fp) != 0 && !err) err = errno ? errno : EIO;
  if (err) {
    errno = err;
    sp_raise_cls(err == ENOSPC ? "Errno::ENOSPC" : "SystemCallError",
                 sp_sprintf("%s @ rb_sys_fail_on_write - %s", strerror(err), path ? path : ""));
    return 0;
  }
  return (sp_int)w;
}
sp_int sp_file_write_perm(const char *path, const char *data, const char *mode, sp_oint perm) {SP_GC_ROOT_STR(path);SP_GC_ROOT_STR(data);SP_GC_ROOT_STR(mode);
  sp_File *f = sp_File_open_perm(path, mode, perm);
  SP_GC_ROOT(f);
  size_t n = sp_str_byte_len(data ? data : sp_str_empty);
  size_t w = fwrite(data ? data : "", 1, n, f->fp);
  int err = (w < n || ferror(f->fp) || fflush(f->fp) != 0) ? (errno ? errno : EIO) : 0;
  sp_File_close(f);
  if (err) {
    errno = err;
    sp_raise_cls(err == ENOSPC ? "Errno::ENOSPC" : "SystemCallError",
                 sp_sprintf("%s @ rb_sys_fail_on_write - %s", strerror(err), path ? path : ""));
    return 0;
  }
  return (sp_int)w;
}
extern const char *sp_errno_class_name(int e);   /* lib/sp_exc.c: the Errno:: class for a C errno */
/* File.open(path, flags, perm): the flag word selects the fdopen mode; the
   permission bits reach open(2) only through this entry, so a created file
   carries the bits the caller asked for rather than 0666. */
static void sp_file_open_raise(const char *path) {
  int e = errno;
  sp_raise_cls(sp_errno_class_name(e), sp_sprintf("%s @ rb_sysopen - %s", strerror(e), path ? path : ""));
}
/* open(2) on a FIFO waits for the other end, and it waits in the kernel with
   no descriptor to wait on. A green thread is pinned to its OS worker, so
   that one syscall stalls every green thread pinned there, including the one
   counting a Thread#join timeout down: the reproducer in #4394 printed
   nothing at all, not even the join's answer.

   O_NONBLOCK is the door out. A read-only open of a FIFO returns at once with
   or without a writer, and a write-only one answers ENXIO rather than waiting,
   which turns the wait into a loop this side of the kernel where the other
   green threads can run. The flag is cleared before the handle is built, so
   every read and write after this behaves exactly as it did -- and they park
   rather than pin, because sp_io_parkable has counted a FIFO since #4307.

   stat(2) does not block on a FIFO, so asking first is safe. Anything else,
   including a path that does not exist yet, opens exactly as before and pays
   one stat: no other shape inherits O_NONBLOCK's different answers. */
static int sp_open_fifo_aware(const char *path, int fl, mode_t perm) {
  struct stat st;
  if (stat(path, &st) != 0 || !S_ISFIFO(st.st_mode))
    return open(path, fl, perm);
  extern void sp_Thread_pass(void);
  for (;;) {
    int fd = open(path, fl | O_NONBLOCK, perm);
    if (fd >= 0) {
      int g = fcntl(fd, F_GETFL);
      if (g >= 0) fcntl(fd, F_SETFL, g & ~O_NONBLOCK);
      return fd;
    }
    /* ENXIO on a write-only open is the one answer the non-blocking form
       invents: "no reader yet". Every other errno is the caller's, and is
       the same errno the blocking form would have given. */
    if (!(errno == ENXIO && (fl & O_ACCMODE) == O_WRONLY)) return -1;
    sp_Thread_pass();
    /* nothing else runnable: do not spin the worker. nanosleep rather than a
       zero-fd poll, which is not portable to macOS. */
    { struct timespec ts; ts.tv_sec = 0; ts.tv_nsec = 1000000; nanosleep(&ts, NULL); }
  }
}
sp_File *sp_File_open_flags_perm(const char *path, sp_int fl, sp_oint perm) {SP_GC_ROOT_STR(path);
  int fd = sp_open_fifo_aware(path ? path : "", (int)fl | O_CLOEXEC, (mode_t)(perm.nil ? 0666 : perm.v));
  if (fd < 0) sp_file_open_raise(path);
  int acc = (int)fl & O_ACCMODE;
  const char *m = (acc == O_RDONLY) ? "r"
                : (acc == O_WRONLY) ? (((int)fl & O_APPEND) ? "a" : "w")
                : (((int)fl & O_APPEND) ? "a+" : "r+");
  sp_File *f = sp_io_fdopen(fd, m);
  f->path = path;
  f->is_file = 1;
  return f;
}
sp_File *sp_File_open_flags(const char *path, sp_int fl) {
  return sp_File_open_flags_perm(path, fl, sp_oint_of(0666));
}
/* File.open(path, "w", perm): the mode string selects the open(2) flags the
   way fopen(3) reads it -- `+` for read-write, `x` for exclusive creation --
   so the permission bits reach the syscall as they do for the flag-word
   form. The mode is checked before the file is opened, so a bad one raises
   CRuby's ArgumentError and leaves no descriptor behind. A nil perm is
   CRuby's default, 0666. */
sp_File *sp_File_open_perm(const char *path, const char *mode, sp_oint perm) {SP_GC_ROOT_STR(path);SP_GC_ROOT_STR(mode);
  const char *m = mode && mode[0] ? mode : "r";
  int fl;
  switch (m[0]) {
    case 'r': fl = O_RDONLY; break;
    case 'w': fl = O_WRONLY | O_CREAT | O_TRUNC; break;
    case 'a': fl = O_WRONLY | O_CREAT | O_APPEND; break;
    default:  sp_raise_cls("ArgumentError", sp_sprintf("invalid access mode %s", m)); return NULL;
  }
  for (const char *q = m + 1; *q && *q != ':'; q++) {
    if (*q == '+') fl = (fl & ~O_ACCMODE) | O_RDWR;
    else if (*q == 'x' && m[0] == 'w') fl |= O_EXCL;  /* exclusive create is a w mode only */
    else if (*q != 'b' && *q != 't' && *q != 'e') {
      sp_raise_cls("ArgumentError", sp_sprintf("invalid access mode %s", m)); return NULL;
    }
  }
  int fd = sp_open_fifo_aware(path ? path : "", fl | O_CLOEXEC, (mode_t)(perm.nil ? 0666 : perm.v));
  if (fd < 0) sp_file_open_raise(path);
  /* fdopen reads its own mode grammar ("wx+" is write-only to it): hand it
     the access mode the flag word says, as the flags form does */
  int acc = fl & O_ACCMODE;
  const char *fm = (acc == O_RDONLY) ? "r"
                 : (acc == O_WRONLY) ? ((fl & O_APPEND) ? "a" : "w")
                 : ((fl & O_APPEND) ? "a+" : (m[0] == 'w') ? "w+" : "r+");
  sp_File *f = sp_io_fdopen(fd, fm);
  f->path = path;
  f->mode = m;
  f->is_file = 1;
  return f;
}
void sp_file_stat_scan(void *p) {
  sp_File *f = (sp_File *)p;
  if (f->path) sp_mark_string(f->path);
  if (f->mode) sp_mark_string(f->mode);
}
sp_File *sp_file_stat_handle(const char *path) {SP_GC_ROOT_STR(path);
  struct stat st;
  /* the errno's own class and message, as File.atime and File.mtime raise */
  if (stat(path ? path : "", &st) != 0) sp_file_raise_errno("rb_file_s_stat", path ? path : "");
  sp_File *f = (sp_File *)sp_gc_alloc(sizeof(sp_File), NULL, sp_file_stat_scan);
  SP_GC_ROOT(f);   /* the sprintf below allocates, and nothing else holds the fresh handle */
  f->fp = NULL;
  f->path = sp_sprintf("%s", path ? path : "");
  sp_gc_wb((void *)f);   /* the sprintf can promote the rooted handle */
  f->mode = (&("\xff" "stat")[1]);
  f->lineno = 0;
  return f;
}
/* File.lstat / File#lstat: like stat, but describing the link itself when the
   final component is a symlink. The handle records mode "lstat" so the
   accessors below read it with lstat(2). (#2986) */
sp_File *sp_file_lstat_handle(const char *path) {SP_GC_ROOT_STR(path);
  struct stat st;
  if (lstat(path ? path : "", &st) != 0) sp_file_raise_errno("rb_file_s_lstat", path ? path : "");
  sp_File *f = (sp_File *)sp_gc_alloc(sizeof(sp_File), NULL, sp_file_stat_scan);
  SP_GC_ROOT(f);
  f->fp = NULL;
  f->path = sp_sprintf("%s", path ? path : "");
  sp_gc_wb((void *)f);   /* the sprintf can promote the rooted handle */
  f->mode = (&("\xff" "lstat")[1]);
  f->lineno = 0;
  return f;
}
/* File::Stat#== is Comparable's, over <=>, which File::Stat defines on the
   modification time: two stats of one unchanged file are equal, and a stat
   handle is never equal to an open stream. Any other pair of handles compares
   by identity (Object#==). A pathless stat (IO#stat on a descriptor handle)
   carries its stream and is fstat(2)ed like its accessors. */
static int sp_stat_handle_p(sp_File *f) {
  return f && f->mode && (strcmp(f->mode, "stat") == 0 || strcmp(f->mode, "lstat") == 0);
}
static int sp_stat_handle_mtime(sp_File *f, struct stat *st) {
  if (f->path && f->path[0])
    return (strcmp(f->mode, "lstat") == 0 ? lstat(f->path, st) : stat(f->path, st)) == 0;
  return f->fp && fstat(fileno(f->fp), st) == 0;
}
sp_bool sp_io_eq(sp_File *a, sp_File *b) {
  if (a == b) return TRUE;
  if (!sp_stat_handle_p(a) || !sp_stat_handle_p(b)) return FALSE;
  struct stat sa, sb;
  if (!sp_stat_handle_mtime(a, &sa) || !sp_stat_handle_mtime(b, &sb)) return FALSE;
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__) || defined(__DragonFly__)
  return sa.st_mtimespec.tv_sec == sb.st_mtimespec.tv_sec && sa.st_mtimespec.tv_nsec == sb.st_mtimespec.tv_nsec;
#else
  return sa.st_mtim.tv_sec == sb.st_mtim.tv_sec && sa.st_mtim.tv_nsec == sb.st_mtim.tv_nsec;
#endif
}
/* Object#<=> on a handle against any operand (boxed): 0 for the same object,
   nil otherwise -- except two File::Stat handles, which Comparable orders by
   modification time, the reading sp_io_eq takes for ==. A NULL handle is nil,
   which is 0 against nil and nil against everything else. The answer is an
   Integer or nil, boxed. */
sp_RbVal sp_io_cmp(sp_File *a, sp_RbVal other) {
  if (other.tag == SP_TAG_NIL) return a ? sp_box_nil() : sp_box_int(0);
  if (other.tag != SP_TAG_OBJ || other.cls_id != SP_BUILTIN_IO) return sp_box_nil();
  sp_File *b = (sp_File *)other.v.p;
  if (a == b) return sp_box_int(0);
  if (!sp_stat_handle_p(a) || !sp_stat_handle_p(b)) return sp_box_nil();
  struct stat sa, sb;
  if (!sp_stat_handle_mtime(a, &sa) || !sp_stat_handle_mtime(b, &sb)) return sp_box_nil();
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__) || defined(__DragonFly__)
  struct timespec ma = sa.st_mtimespec, mb = sb.st_mtimespec;
#else
  struct timespec ma = sa.st_mtim, mb = sb.st_mtim;
#endif
  if (ma.tv_sec != mb.tv_sec) return sp_box_int(ma.tv_sec < mb.tv_sec ? -1 : 1);
  return sp_box_int(ma.tv_nsec < mb.tv_nsec ? -1 : ma.tv_nsec > mb.tv_nsec ? 1 : 0);
}
/* Object#to_s on a handle: #<Class:0xADDR> under the class the handle presents
   as -- a stat handle is a File::Stat, and sp_io_kind_name tells File, IO and
   the socket classes apart. #inspect keeps the handle's own render. A NULL
   handle is nil, whose to_s is the empty string. */
const char *sp_io_to_s(sp_File *f) {
  if (!f) return SPL("");
  return sp_sprintf("#<%s:0x%016llx>", sp_stat_handle_p(f) ? "File::Stat" : sp_io_kind_name(f),
                    (unsigned long long)(uintptr_t)f);
}
/* True when the handle came from lstat, so a final symlink is not followed. */
sp_bool sp_stat_nofollow(sp_File *f) {
  return f && f->mode && strcmp(f->mode, "lstat") == 0;
}
/* IO#stat. A handle opened from a descriptor (IO.new(fd) / IO.for_fd) has no
   path to stat, so the handle it answers carries the stream instead and the
   accessors below fstat(2) it. */
static int sp_stat_pathless(sp_File *f) {
  return f && f->fp && (!f->path || f->path[0] == 0);
}
sp_File *sp_io_stat_handle(sp_File *f) {SP_GC_ROOT(f);
  SP_IO_OPEN(f);
  /* a standard stream's "<STDOUT>" is a placeholder, not a path: fstat it,
     as a handle opened from a descriptor is; a File opened by a name that
     starts with '<' still goes by its path */
  if (f->path && f->path[0] && (f->path[0] != '<' || f->is_file)) return sp_file_stat_handle(f->path);
  struct stat st;
  if (fstat(fileno(f->fp), &st) != 0)
    sp_raise_cls("Errno::EBADF", "Bad file descriptor");
  sp_File *h = (sp_File *)sp_gc_alloc(sizeof(sp_File), NULL, sp_file_stat_scan);
  h->fp = f->fp;
  h->path = sp_str_empty;
  h->mode = (&("\xff" "stat")[1]);
  h->lineno = 0;
  return h;
}
/* One stat(2) field by index, so File::Stat's numeric accessors need one
   runtime entry rather than a dozen. 0=uid 1=gid 2=nlink 3=dev 4=ino
   5=blksize 6=blocks 7=rdev. nil when the stat itself fails. */
static sp_int sp_stat_field_n(sp_File *f, sp_int which, int *ok);
sp_oint sp_stat_field(sp_File *f, sp_int which) {SP_GC_ROOT(f); int ok = 1; sp_int n = sp_stat_field_n(f, which, &ok); return ok ? sp_oint_of(n) : sp_oint_nil(); }
static sp_int sp_stat_field_n(sp_File *f, sp_int which, int *ok) {SP_GC_ROOT(f);
  struct stat st;
  int r;
  if (sp_stat_pathless(f)) r = fstat(fileno(f->fp), &st);
  else {
    const char *p = (f && f->path) ? f->path : "";
    r = sp_stat_nofollow(f) ? lstat(p, &st) : stat(p, &st);
  }
  if (r != 0) { *ok = 0; return 0; }
  switch (which) {
    case 0: return (sp_int)st.st_uid;
    case 1: return (sp_int)st.st_gid;
    case 2: return (sp_int)st.st_nlink;
    case 3: return (sp_int)st.st_dev;
    case 4: return (sp_int)st.st_ino;
    case 5: return (sp_int)st.st_blksize;
    case 6: return (sp_int)st.st_blocks;
    default: return (sp_int)st.st_rdev;
  }
}
/* The TIME accessors of File::Stat, reading the struct the handle's own mode
   selects. Like the type predicates below, these went through the path
   helpers -- sp_file_mtime(path) always stat(2)s -- so an lstat handle
   reported the TARGET's times and File.lutime was invisible through it
   (#4616). birthtime keeps the path helper: it needs statx/st_birthtimespec,
   which the plain struct here does not carry portably. Kinds: 0=mtime
   1=atime 2=ctime. */
sp_Time sp_stat_handle_time(sp_File *f, sp_int kind) {SP_GC_ROOT(f);
  struct stat st;
  int r;
  if (sp_stat_pathless(f)) r = fstat(fileno(f->fp), &st);
  else {
    const char *p = (f && f->path) ? f->path : "";
    r = sp_stat_nofollow(f) ? lstat(p, &st) : stat(p, &st);
  }
  if (r != 0) {
    sp_file_raise_errno("rb_file_s_mtime", (f && f->path) ? f->path : "");
    return (sp_Time){0, 0, 0};
  }
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__) || defined(__DragonFly__)
  struct timespec ts = kind == 1 ? st.st_atimespec : kind == 2 ? st.st_ctimespec : st.st_mtimespec;
#else
  struct timespec ts = kind == 1 ? st.st_atim : kind == 2 ? st.st_ctim : st.st_mtim;
#endif
  return (sp_Time){(int64_t)ts.tv_sec, (int32_t)ts.tv_nsec, 0};
}
/* The TYPE predicates of File::Stat. These used to be answered from the
   handle's PATH -- sp_file_symlink(path), sp_file_file(path) -- which throws
   away which of stat(2) and lstat(2) made the handle: `File.stat(link)`
   answered symlink? true (the path helper lstats) and `File.lstat(link)`
   answered file? true (that one stats), both backwards (#4616). Read the
   struct once, the way every other accessor here picks it. Kinds: 0=file?
   1=directory? 2=symlink? 3=owned? 4=grpowned? 5=setuid? 6=setgid?
   7=sticky? 8=socket?. */
sp_int sp_stat_type_pred(sp_File *f, sp_int kind) {SP_GC_ROOT(f);
  struct stat st;
  int r;
  if (sp_stat_pathless(f)) r = fstat(fileno(f->fp), &st);
  else {
    const char *p = (f && f->path) ? f->path : "";
    r = sp_stat_nofollow(f) ? lstat(p, &st) : stat(p, &st);
  }
  if (r != 0) return 0;
  switch (kind) {
    case 0: return S_ISREG(st.st_mode) ? 1 : 0;
    case 1: return S_ISDIR(st.st_mode) ? 1 : 0;
    case 2: return S_ISLNK(st.st_mode) ? 1 : 0;
    case 3: return st.st_uid == geteuid() ? 1 : 0;
    case 4: return st.st_gid == getegid() ? 1 : 0;
    case 5: return (st.st_mode & S_ISUID) ? 1 : 0;
    case 6: return (st.st_mode & S_ISGID) ? 1 : 0;
    case 7: return (st.st_mode & S_ISVTX) ? 1 : 0;
    default: return S_ISSOCK(st.st_mode) ? 1 : 0;
  }
}
/* The mode-derived predicates of File::Stat that no path helper covers. Kinds:
   0=pipe? 1=zero? 2=readable? 3=writable? 4=executable? 5=blockdev?
   6=chardev? 7=size? (non-zero size, else nil). */
sp_int sp_stat_pred(sp_File *f, sp_int kind) {SP_GC_ROOT(f);
  struct stat st;
  int r;
  if (sp_stat_pathless(f)) r = fstat(fileno(f->fp), &st);
  else {
    const char *p = (f && f->path) ? f->path : "";
    r = sp_stat_nofollow(f) ? lstat(p, &st) : stat(p, &st);
  }
  if (r != 0) return 0;
  switch (kind) {
    case 0: return S_ISFIFO(st.st_mode) ? 1 : 0;
    case 1: return st.st_size == 0 ? 1 : 0;
    case 2: return (st.st_mode & (S_IRUSR | S_IRGRP | S_IROTH)) ? 1 : 0;
    case 3: return (st.st_mode & (S_IWUSR | S_IWGRP | S_IWOTH)) ? 1 : 0;
    case 4: return (st.st_mode & (S_IXUSR | S_IXGRP | S_IXOTH)) ? 1 : 0;
    case 5: return S_ISBLK(st.st_mode) ? 1 : 0;
    case 6: return S_ISCHR(st.st_mode) ? 1 : 0;
    default: return 0;
  }
}
/* File::Stat#size?: the size when the stat succeeds and it is not 0, else nil (was kind 7) */
sp_oint sp_stat_size(sp_File *f);
sp_oint sp_stat_size_q(sp_File *f) {SP_GC_ROOT(f);
  sp_oint n = sp_stat_size(f);
  return (n.nil || n.v == 0) ? sp_oint_nil() : n;
}
/* File#truncate(n): ftruncate(2) on the open descriptor, which is what CRuby
   does -- the class-method form truncates by path and cannot serve a handle
   whose path is gone or absent. Buffered bytes are flushed first so the file
   is cut at the size the program believes it has written. */
/* File#size on a handle: fstat(2) of the descriptor, as CRuby reads it --
   the path may have been renamed or unlinked since the open. */
sp_int sp_File_size(sp_File *f) {SP_GC_ROOT(f);
  SP_IO_OPEN(f);
  struct stat st;
  fflush(f->fp);
  if (fstat(fileno(f->fp), &st) != 0) sp_file_raise_errno("rb_file_size", f->path ? f->path : "");
  if ((off_t)(sp_int)st.st_size != st.st_size) {
    sp_raise_cls("RangeError", "file size out of range for Integer");
    return 0;
  }
  return (sp_int)st.st_size;
}
sp_int sp_File_truncate(sp_File *f, sp_int n) {SP_GC_ROOT(f);
  SP_IO_OPEN(f);
  if (!f || !f->fp) sp_raise_cls("IOError", "closed stream");
  fflush(f->fp);
  if (ftruncate(fileno(f->fp), (off_t)n) != 0)
    sp_raise_cls("Errno::EINVAL", "Invalid argument @ rb_file_truncate");
  return 0;
}
sp_oint sp_stat_size(sp_File *f) {SP_GC_ROOT(f);
  struct stat st;
  if (sp_stat_pathless(f))
    return fstat(fileno(f->fp), &st) == 0 ? sp_oint_of((sp_int)st.st_size) : sp_oint_nil();
  const char *p = (f && f->path) ? f->path : "";
  int r = sp_stat_nofollow(f) ? lstat(p, &st) : stat(p, &st);
  return r == 0 ? sp_oint_of((sp_int)st.st_size) : sp_oint_nil();
}
sp_int sp_stat_mode(sp_File *f) {SP_GC_ROOT(f);
  struct stat st;
  if (sp_stat_pathless(f))
    return fstat(fileno(f->fp), &st) == 0 ? (sp_int)st.st_mode : 0;
  const char *p = (f && f->path) ? f->path : "";
  int r = sp_stat_nofollow(f) ? lstat(p, &st) : stat(p, &st);
  return r == 0 ? (sp_int)st.st_mode : 0;
}
const char *sp_stat_ftype(sp_File *f) {SP_GC_ROOT(f);
  if (sp_stat_pathless(f)) {
    struct stat st;
    if (fstat(fileno(f->fp), &st) != 0) return sp_str_empty;
    if (S_ISDIR(st.st_mode))  return (&("\xff" "directory")[1]);
    if (S_ISCHR(st.st_mode))  return (&("\xff" "characterSpecial")[1]);
    if (S_ISBLK(st.st_mode))  return (&("\xff" "blockSpecial")[1]);
    if (S_ISFIFO(st.st_mode)) return (&("\xff" "fifo")[1]);
    if (S_ISSOCK(st.st_mode)) return (&("\xff" "socket")[1]);
    return (&("\xff" "file")[1]);
  }
  /* sp_file_ftype already lstat()s, so it is exactly the lstat answer; a
     following handle resolves the link first. */
  const char *p = (f && f->path) ? f->path : "";
  if (sp_stat_nofollow(f)) return sp_file_ftype(p);
  { const char *rp = sp_file_realpath(p); return sp_file_ftype(rp ? rp : p); }
}
sp_int sp_file_stat_mode(const char *path) {
  struct stat st;
  if (stat(path ? path : "", &st) != 0) return 0;
  return (sp_int)st.st_mode;
}
/* File.fnmatch: the matcher is sp_fnm_match, above Dir.glob, which shares it. */
typedef struct { const char *path; int flags; } sp_fnm_ctx;
static int sp_fnm_each(const char *pattern, void *ctx) {
  sp_fnm_ctx *f = (sp_fnm_ctx *)ctx;
  return sp_fnm_match(pattern, f->path, f->flags) || sp_glob_bad;
}
sp_bool sp_file_fnmatch(const char *pat, const char *path, sp_int flags) {
  int fl = (int)flags;
  if (!pat) pat = "";
  if (!path) path = "";
  if (fl & SP_FNM_EXTGLOB) {
    sp_fnm_ctx f = { path, fl };
    /* the expansion's buffers are freed before the matcher's error is raised */
    sp_glob_start();
    int r = sp_brace_expand(pat, !(fl & SP_FNM_NOESCAPE), 1, sp_fnm_each, &f);
    sp_glob_finish();
    return r != 0;
  }
  return sp_fnm_match(pat, path, fl) != 0;
}
sp_StrArray *sp_file_split(const char *path) {SP_GC_ROOT_STR(path);
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  sp_StrArray_push(a, sp_file_dirname(path));
  sp_StrArray_push(a, sp_file_basename(path));
  return a;
}
sp_bool sp_file_zero(const char *path) {
  struct stat st;
  if (stat(path ? path : "", &st) != 0) return 0;
  if (S_ISDIR(st.st_mode)) return 0;
  return st.st_size == 0;
}
const char *sp_file_dirname(const char *path) {SP_GC_ROOT_STR(path);
  const char *s = strrchr(path, '/');
  if (!s) { char *r = sp_str_alloc(1); r[0] = '.'; r[1] = 0; return r; }
  if (s == path) { char *r = sp_str_alloc(1); r[0] = '/'; r[1] = 0; return r; }
#if defined(_WIN32)
  /* the separator of a drive's root ("C:/x") stays: the dirname is the root */
  { size_t rn = sp_file_path_root_len(path);
    if (rn > 1 && (size_t)(s - path) < rn) { char *r = sp_str_alloc((sp_int)rn); memcpy(r, path, rn); r[rn] = 0; return r; } }
#endif
  size_t n = (size_t)(s - path);
  char *buf = sp_str_alloc(n);
  memcpy(buf, path, n); buf[n] = 0;
  return buf;
}
const char *sp_dir_pwd(void) {
  char tmp[4096];
  if (!getcwd(tmp, sizeof(tmp))) { return sp_str_empty; }
  size_t n = strlen(tmp);
  char *buf = sp_str_alloc(n);
  memcpy(buf, tmp, n + 1);
  return buf;
}
/* Dir.mkdir / Dir.rmdir / Dir.chdir: 0, or the Errno CRuby raises, under
   CRuby's labels; its block-form chdir says dir_chdir0 where this wrapper
   says chdir_path in both forms. A nil path (a NULL string at run time) is
   CRuby's TypeError, as it is for File.size and the time readers above. */
sp_int sp_dir_mkdir(const char *path) {SP_GC_ROOT_STR(path);
  sp_file_path_check(path);
  if (mkdir(path, 0777) != 0) sp_file_raise_errno("dir_s_mkdir", path);
  return 0;
}
sp_int sp_dir_rmdir(const char *path) {SP_GC_ROOT_STR(path);
  sp_file_path_check(path);
  if (rmdir(path) != 0) sp_file_raise_errno("dir_s_rmdir", path);
  return 0;
}
sp_int sp_dir_chdir(const char *path) {SP_GC_ROOT_STR(path);
  sp_file_path_check(path);
  if (chdir(path) != 0) sp_file_raise_errno("chdir_path", path);
  return 0;
}
/* the block form: the same switch under CRuby's label for it */
sp_int sp_dir_chdir0(const char *path) {SP_GC_ROOT_STR(path);
  sp_file_path_check(path);
  if (chdir(path) != 0) sp_file_raise_errno("dir_chdir0", path);
  return 0;
}
const char *sp_dir_home(void) {
  const char *h = getenv("HOME");
  if (!h) return sp_str_empty;
  return sp_str_dup_external(h);
}
void sp_Dir_fin(void *p) { sp_Dir *d = (sp_Dir *)p; if (d->dp) { closedir(d->dp); d->dp = NULL; } }
void sp_Dir_scan(void *p) { sp_Dir *d = (sp_Dir *)p; if (d->path) sp_mark_string(d->path); }
sp_Dir *sp_Dir_new(const char *path) {SP_GC_ROOT_STR(path);
  DIR *dp = opendir(path ? path : "");
  if (!dp)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ dir_initialize - %s", path ? path : ""));
  sp_Dir *d = (sp_Dir *)sp_gc_alloc(sizeof(sp_Dir), sp_Dir_fin, sp_Dir_scan);
  d->dp = dp;
  d->path = NULL;   /* set below: the sprintf may GC, and the scan reads path */
  SP_GC_ROOT(d);
  d->path = sp_sprintf("%s", path ? path : "");
  sp_gc_wb((void *)d);   /* the sprintf can promote the rooted handle */
  return d;
}
/* Dir.for_fd(fd): take over a descriptor already opened on a directory. The
   handle owns the fd from here, as CRuby's does. */
sp_Dir *sp_Dir_for_fd(sp_int fd) {
  DIR *dp = fd >= 0 ? fdopendir((int)fd) : NULL;
  if (!dp) sp_raise_cls("Errno::EBADF", "Bad file descriptor - fdopendir");
  sp_Dir *d = (sp_Dir *)sp_gc_alloc(sizeof(sp_Dir), sp_Dir_fin, sp_Dir_scan);
  d->dp = dp;
  /* CRuby's Dir.for_fd has no path: the descriptor carries no name. */
  d->path = NULL;
  return d;
}
/* #entries / #children read the OPEN handle: a Dir from Dir.for_fd has no path
   to re-open, and re-opening by path would miss a directory that has since been
   renamed. Rewinds first so the listing is complete however far #read got. */
sp_StrArray *sp_Dir_entries_h(sp_Dir *d, sp_int children) {SP_GC_ROOT(d);
  SP_DIR_OPEN(d);
  rewinddir(d->dp);
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  struct dirent *e;
  while ((e = readdir(d->dp)) != NULL) {
    if (children && (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0)) continue;
    sp_StrArray_push(a, sp_sprintf("%s", e->d_name));
  }
  rewinddir(d->dp);
  return a;
}
sp_int sp_Dir_fchdir(sp_int fd) {
  if (fd < 0 || fchdir((int)fd) != 0)
    sp_raise_cls("Errno::EBADF", "Bad file descriptor - fchdir");
  return 0;
}
SP_NORETURN SP_COLD void sp_dir_raise_closed(void) {
  sp_raise_cls("IOError", "closed directory");
}
const char *sp_Dir_read(sp_Dir *d) {
  SP_DIR_OPEN(d);
  struct dirent *e = readdir(d->dp);
  return e ? sp_sprintf("%s", e->d_name) : NULL;
}
/* NULL is Ruby nil in the string convention: a Dir from Dir.for_fd has no path,
   and CRuby answers nil for it rather than an empty string (#3365). */
const char *sp_Dir_path(sp_Dir *d) { return d ? d->path : NULL; }
/* Object#to_s: #<Dir:0xADDR>; #inspect is the #<Dir:PATH> above. */
const char *sp_Dir_to_s(sp_Dir *d) {
  return d ? sp_sprintf("#<Dir:0x%016llx>", (unsigned long long)(uintptr_t)d) : SPL("");
}
/* Object#<=>: 0 for the same object, nil otherwise (a NULL handle is nil:
   0 against nil, nil against everything else); boxed, like sp_io_cmp. */
sp_RbVal sp_Dir_cmp(sp_Dir *d, sp_RbVal other) {
  if (other.tag == SP_TAG_NIL) return d ? sp_box_nil() : sp_box_int(0);
  if (other.tag == SP_TAG_OBJ && other.cls_id == SP_BUILTIN_DIR && (sp_Dir *)other.v.p == d)
    return sp_box_int(0);
  return sp_box_nil();
}
sp_RbVal sp_Dir_close(sp_Dir *d) { if (d && d->dp) { closedir(d->dp); d->dp = NULL; } return sp_box_nil(); }
sp_Dir *sp_Dir_rewind(sp_Dir *d) { SP_DIR_OPEN(d); rewinddir(d->dp); return d; }
sp_int sp_Dir_tell(sp_Dir *d) { SP_DIR_OPEN(d); return (sp_int)telldir(d->dp); }
sp_Dir *sp_Dir_seek(sp_Dir *d, sp_int pos) { SP_DIR_OPEN(d); seekdir(d->dp, (long)pos); return d; }
sp_int sp_Dir_fileno(sp_Dir *d) { SP_DIR_OPEN(d); return (sp_int)dirfd(d->dp); }
sp_StrArray *sp_dir_entries(const char *path) {SP_GC_ROOT_STR(path); return sp_dir_entries_impl(path, 0); }
sp_bool sp_dir_empty(const char *path) {SP_GC_ROOT_STR(path);
  struct stat st;
  if (!path || stat(path, &st) != 0)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ rb_dir_s_empty_p - %s", path ? path : ""));
  if (!S_ISDIR(st.st_mode)) return FALSE;
  DIR *d = opendir(path);
  if (!d) return FALSE;
  struct dirent *e; sp_bool empty = TRUE;
  while ((e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    empty = FALSE; break;
  }
  closedir(d);
  return empty;
}
const char *sp_dir_home_user(const char *user) {SP_GC_ROOT_STR(user);
  if (!user || !*user) return sp_dir_home();
  struct passwd *pw = getpwnam(user);
  if (!pw || !pw->pw_dir)
    sp_raise_cls("ArgumentError", sp_sprintf("user %s doesn't exist", user));
  return sp_str_dup_external(pw->pw_dir);
}
sp_StrArray *sp_dir_children(const char *path) {SP_GC_ROOT_STR(path); return sp_dir_entries_impl(path, 1); }
/* Dir.entries / Dir.children with an encoding: keyword, the form Find.find
   lists a directory with. The name is checked first, as Encoding.find checks
   it (CRuby raises before it opens the directory), and nil keeps the
   default. A String tells only binary from text, so ASCII-8BIT marks the
   names binary and any other encoding leaves them as they are. */
sp_StrArray *sp_dir_entries_enc(const char *path, int children, sp_RbVal enc) {SP_GC_ROOT_STR(path);
  int binary = 0;
  if (enc.tag != SP_TAG_NIL) {
    sp_RbVal e = sp_encoding_find(enc);
    binary = e.tag == SP_TAG_ENCODING && e.v.s && strcmp(e.v.s, "ASCII-8BIT") == 0;
  }
  sp_StrArray *a = sp_dir_entries_impl(path, children);
  if (binary)
    for (sp_int i = 0; i < a->len; i++) sp_str_as_binary(a->data[i]);
  return a;
}

/* ---- Signal trap machinery + Enumerator cursor/generator ops moved from
   spinel_rt.h ----
   Only tiny TU-defined helpers are linked from here (sp_proc_call, the boxed
   proc constructor, the trap state, the proc argument/return slots): the heavy
   poly/hash/render helpers (sp_enum_items_from, sp_poly_each_elem, ...) stay
   `static` in the generated TU so -O1 still prunes them from programs that
   never use them -- de-externing those measurably bloats every test compile. */
#include <signal.h>
#include "sp_enum.h"
typedef struct sp_Proc sp_Proc;
extern char **environ;
extern sp_RbVal sp_box_proc(void *p);
extern const char *sp_trap_state[];
extern struct sp_Proc *sp_trap_proc[];
extern SP_NORETURN void sp_raise_stop_iteration(sp_RbVal result);
extern SP_TLS sp_RbVal _sp_proc_poly_ret;
extern SP_TLS sp_RbVal _sp_proc_poly_args[];
extern sp_int sp_proc_call(sp_Proc *p, sp_int argc, sp_int *args);
extern void sp_trap_call(sp_Proc *p, int no);
extern const char *sp_signal_signame(sp_int no);
extern SP_COLD int sp_signal_resolve(sp_RbVal sig);

sp_Enumerator *sp_Enumerator_dup(sp_Enumerator *e);
void sp_Enumerator_scan(void *p);
sp_Enumerator *sp_enum_with_src(sp_Enumerator *e, sp_RbVal src, const char *meth);
sp_Enumerator *sp_enum_as_gen(sp_Enumerator *e);
sp_RbVal sp_enum_with_index_value(sp_Enumerator *e);
sp_RbVal sp_enum_with_index_result(sp_Enumerator *e, sp_PolyArray *mapped);
sp_Enumerator *sp_Enumerator_new_from_items(sp_PolyArray *items);
sp_Enumerator *sp_Enumerator_with_index(sp_Enumerator *e, sp_int off);
sp_Enumerator *sp_Enumerator_new_gen(void (*gen)(sp_Fiber *), void *cap, sp_RbVal size);
sp_RbVal sp_enum_gen_pull(sp_Enumerator *e);
sp_RbVal sp_Enumerator_next(sp_Enumerator *e);
sp_RbVal sp_Enumerator_peek(sp_Enumerator *e);
sp_PolyArray *sp_enum_values_wrap(sp_RbVal v);
sp_PolyArray *sp_Enumerator_next_values(sp_Enumerator *e);
sp_PolyArray *sp_Enumerator_peek_values(sp_Enumerator *e);
sp_Enumerator *sp_Enumerator_rewind(sp_Enumerator *e);
sp_RbVal sp_Enumerator_feed(sp_Enumerator *e, sp_RbVal v);
sp_PolyArray *sp_Enumerator_take(sp_Enumerator *e, sp_int n);
sp_PolyArray *sp_Enumerator_to_a(sp_Enumerator *e);
void sp_sig_c_handler(int no);
void sp_exc_resignal(const char *cls, const char *msg);
void sp_sig_exit_dispatch(void);
sp_RbVal sp_signal_trap(sp_RbVal sig, sp_RbVal handler);
sp_int sp_process_kill1(sp_RbVal sig, sp_int pid);
sp_RbVal sp_Enumerator_size(sp_Enumerator *e);

sp_Enumerator *sp_Enumerator_dup(sp_Enumerator *e) {SP_GC_ROOT(e);
  if (!e) return e;
  if (SP_UNLIKELY(e->str_tail)) return sp_enum_str_dup(e);
  sp_Enumerator *d = (sp_Enumerator *)sp_gc_alloc(sizeof(sp_Enumerator), NULL, sp_Enumerator_scan);
  *d = *e;
  return d;
}
void sp_PolyArray_pack_scan(void *p) {
  sp_PolyArray *a = (sp_PolyArray *)p;
  for (sp_int i = 0; i < a->len; i++) sp_mark_rbval(a->data[i]);
}
/* never pooled: a recycled pack would come back as an ordinary array still
   carrying the pack's scan function */
sp_PolyArray *sp_PolyArray_new_pack(void) {
  sp_PolyArray *a = (sp_PolyArray *)sp_gc_alloc(sizeof(sp_PolyArray), NULL, sp_PolyArray_pack_scan);
  a->data = a->inl; a->cap = SP_POLYARR_INLINE; a->len = 0;
  return a;
}
void sp_Enumerator_scan(void *p) {
  sp_Enumerator *e = (sp_Enumerator *)p;
  if (e->items) sp_gc_mark(e->items);
  if (e->fib) sp_gc_mark(e->fib);
  if (e->gen_cap) sp_gc_mark(e->gen_cap);
  if (e->peeked) sp_mark_rbval(e->peek_val);
  if (e->is_bsearch) sp_mark_rbval(e->bsearch_result);
  sp_mark_rbval(e->size);
  if (e->has_feed) sp_mark_rbval(e->feed);
  sp_mark_rbval(e->gen_result);
  sp_mark_rbval(e->source);
  sp_mark_string(e->meth);
  if (e->walk_buf) sp_gc_mark(e->walk_buf);
}
sp_Enumerator *sp_enum_with_src(sp_Enumerator *e, sp_RbVal src, const char *meth) { sp_gc_wb((void*)e);
  e->source = src;
  e->has_src = TRUE;
  e->meth = meth;
  /* a String Range counts no members without walking them (Range#size is nil
     for it), so the Enumerators it answers (step, %) have no size either,
     though their members were materialized here */
  if (src.tag == SP_TAG_OBJ && src.cls_id == SP_BUILTIN_STR_RANGE) e->size_nil = TRUE;
  /* nor does a String's each_line (CRuby counts no lines without walking
     them), with a separator or chomp: or not */
  if (meth && strncmp(meth, "each_line", 9) == 0) e->size_nil = TRUE;
  return e;
}
sp_Enumerator *sp_enum_as_gen(sp_Enumerator *e) {
  e->gen_label = TRUE;
  return e;
}
/* Recognize the annotated materialized walks in the existing return
   dispatch; an inspect label must not turn a supported walk into an error. */
static int sp_enum_returns_source(sp_Enumerator *e) {
  const char *m = e->meth;
  return m && (strcmp(m, "each") == 0 || strcmp(m, "each_with_index") == 0 ||
               strncmp(m, "cycle(", 6) == 0 || strncmp(m, "combination(", 12) == 0 ||
               strcmp(m, "permutation") == 0 || strncmp(m, "permutation(", 12) == 0 ||
               strncmp(m, "repeated_combination(", 21) == 0 ||
               strncmp(m, "repeated_permutation(", 21) == 0);
}
sp_RbVal sp_enum_with_index_value(sp_Enumerator *e) {SP_GC_ROOT(e);
  if (sp_enum_returns_source(e))
    return e->source;
  sp_raise_cls("NotImplementedError",
               sp_sprintf("Enumerator#with_index return value for a stored %s enumerator",
                          e->meth ? e->meth : "generator"));
  return sp_box_nil();
}
sp_RbVal sp_enum_with_index_result(sp_Enumerator *e, sp_PolyArray *mapped) {SP_GC_ROOT(e);
  if (e->meth && (strcmp(e->meth, "map") == 0 || strcmp(e->meth, "collect") == 0))
    return sp_box_poly_array(mapped);
  if (sp_enum_returns_source(e))
    return e->source;
  sp_raise_cls("NotImplementedError",
               sp_sprintf("Enumerator#with_index return value for a stored %s enumerator",
                          e->meth ? e->meth : "generator"));
  return sp_box_nil();
}
/* `obj.then` / `obj.yield_self` with no block: an enumerator of exactly one
   element, the receiver, which is what CRuby answers (#4028). It renders as
   `#<Enumerator: 5:then>` and reports size 1. */
sp_Enumerator *sp_enum_of_one(sp_RbVal v, const char *meth) {
  SP_GC_ROOT_RBVAL(v);
  sp_PolyArray *a = sp_PolyArray_new();
  SP_GC_ROOT(a);
  sp_PolyArray_push(a, v);
  sp_Enumerator *e = sp_Enumerator_new_from_items(a);
  e->size = sp_box_int(1);
  return sp_enum_with_src(e, v, meth);
}
sp_Enumerator *sp_Enumerator_new_from_items(sp_PolyArray *items) {
  SP_GC_ROOT(items);
  sp_Enumerator *e = (sp_Enumerator *)sp_gc_alloc(sizeof(sp_Enumerator), NULL, sp_Enumerator_scan);
  e->items = items; e->cursor = 0; e->gen = NULL; e->gen_cap = NULL; e->fib = NULL; e->peeked = FALSE; e->size = sp_box_nil(); e->feed = sp_box_nil(); e->has_feed = FALSE; e->gen_result = sp_box_nil(); e->source = sp_box_nil(); e->meth = SPL("each");
  return e;
}
/* Lazy with_index over a generator-backed source (blockless Kernel#loop,
   external enumerators): pull one value at a time and pair it with the
   running index, so an infinite source stays drivable via #next (#3236). */
/* The walk is the pair's own: a fiber of its own over a generator source and
   an index of its own over a materialized one, so the source's #next cursor
   is neither read nor moved (`g.with_index.first(4)` then `g.next` answered
   the fifth element), and an endless cycle's round starts over. The source
   fiber belongs to this run of the pairing fiber, not to the capture every
   run shares: #next, to_a, first(n) and a walk each run it separately, and
   one run starting over replaced the fiber another was reading. */
typedef struct { sp_Enumerator *src; sp_int off; } sp_WiCap;
static void sp_wi_cap_scan(void *p) {
  sp_WiCap *cap = (sp_WiCap *)p;
  if (cap->src) sp_gc_mark(cap->src);
}
/* The next item of a run over source `s` that owns its fiber `*sf` (rooted
   by the caller) and its cursor `*j`; FALSE once the source is spent. */
static sp_bool sp_src_run_pull(sp_Enumerator *s, sp_Fiber **sf, sp_int *j, sp_RbVal *out) {
  if (s->gen) {
    if (!*sf) { *sf = sp_Fiber_new(s->gen); if (s->gen_cap) { sp_gc_wb((void*)*sf); (*sf)->user_data = s->gen_cap; } }
    if (!sp_Fiber_alive(*sf)) return FALSE;
    *out = sp_Fiber_resume(*sf, sp_box_nil());
    return sp_Fiber_alive(*sf);
  }
  if (s->endless && s->items && s->items->len > 0 && *j >= s->items->len) *j = 0;
  if (!s->items || *j >= s->items->len) return FALSE;
  *out = s->items->data[(*j)++];
  return TRUE;
}
static void sp_with_index_gen(sp_Fiber *f) {
  sp_WiCap *cap = (sp_WiCap *)f->user_data;
  sp_Enumerator *s = cap->src;
  sp_int i = cap->off, j = 0;
  sp_Fiber *sf = NULL;
  SP_GC_ROOT(sf);
  for (;;) {
    sp_RbVal v;
    if (!sp_src_run_pull(s, &sf, &j, &v)) break;
    sp_PolyArray *pair = sp_PolyArray_new();
    SP_GC_ROOT(pair);
    sp_PolyArray_push(pair, v);
    sp_PolyArray_push(pair, sp_box_int(i++));
    sp_Fiber_yield(sp_box_poly_array(pair));
  }
}
/* A countless cycle over a generator or endless Enumerator: a run pulls the
   source on a fiber of its own and yields each item as it arrives, keeping
   them; when the source ends it goes round the kept items forever. The
   source is never drained up front, so an endless one answers first(n). */
typedef struct { sp_Enumerator *src; } sp_CyCap;
static void sp_cy_cap_scan(void *p) {
  sp_CyCap *cap = (sp_CyCap *)p;
  if (cap->src) sp_gc_mark(cap->src);
}
static void sp_cycle_gen(sp_Fiber *f) {
  sp_CyCap *cap = (sp_CyCap *)f->user_data;
  sp_Enumerator *s = cap->src;
  sp_int j = 0;
  sp_Fiber *sf = NULL;
  SP_GC_ROOT(sf);
  sp_PolyArray *seen = sp_PolyArray_new();
  SP_GC_ROOT(seen);
  /* (a live source's run reads a copy of its own) */
  s = sp_enum_walk(s);
  SP_GC_ROOT(s);
  for (;;) {
    sp_RbVal v;
    if (s->gen) {
      if (!sf) { sf = sp_Fiber_new(s->gen); if (s->gen_cap) { sp_gc_wb((void*)sf); sf->user_data = s->gen_cap; } }
      if (!sp_Fiber_alive(sf)) break;
      v = sp_Fiber_resume(sf, sp_box_nil());
      if (!sp_Fiber_alive(sf)) break;
    }
    else {
      if (s->endless && s->items && s->items->len > 0 && j >= s->items->len) j = 0;
      if (!s->items || j >= s->items->len) break;
      v = s->items->data[j++];
    }
    sp_PolyArray_push(seen, v);
    sp_Fiber_yield(v);
  }
  if (seen->len == 0) return;
  for (sp_int i = 0;; i = (i + 1) % seen->len) sp_Fiber_yield(seen->data[i]);
}
sp_Enumerator *sp_Enumerator_cycle_gen(sp_Enumerator *e) {
  SP_GC_ROOT(e);
  sp_CyCap *cap = (sp_CyCap *)sp_gc_alloc(sizeof(sp_CyCap), NULL, sp_cy_cap_scan);
  SP_GC_ROOT(cap);
  cap->src = e;
  sp_Enumerator *r = sp_Enumerator_new_gen(sp_cycle_gen, cap, sp_box_nil());
  r->yields_pair = e->yields_pair;
  r->source = e->source;
  return sp_enum_inherit_size(r, e);
}
/* Blockless each_slice(n) / each_cons(n) over a generator or an endless
   source: the groups are made as a run pulls the source, one group per
   step, so an endless source answers first(n) (materializing it never
   returned). A run owns its source fiber, as with_index's does. */
typedef struct { sp_Enumerator *src; sp_int n; sp_bool cons; } sp_RgCap;
static void sp_rg_cap_scan(void *p) {
  sp_RgCap *cap = (sp_RgCap *)p;
  if (cap->src) sp_gc_mark(cap->src);
}
static void sp_regroup_gen(sp_Fiber *f) {
  sp_RgCap *cap = (sp_RgCap *)f->user_data;
  sp_Enumerator *s = cap->src;
  sp_int j = 0;
  sp_Fiber *sf = NULL;
  SP_GC_ROOT(sf);
  sp_PolyArray *win = sp_PolyArray_new();
  SP_GC_ROOT(win);
  for (;;) {
    sp_RbVal v;
    if (!sp_src_run_pull(s, &sf, &j, &v)) break;
    sp_PolyArray_push(win, v);
    if (win->len < cap->n) continue;
    sp_PolyArray *g = sp_PolyArray_new();
    SP_GC_ROOT(g);
    for (sp_int k = 0; k < win->len; k++) sp_PolyArray_push(g, win->data[k]);
    if (cap->cons) { memmove(win->data, win->data + 1, (size_t)(win->len - 1) * sizeof(sp_RbVal)); win->len--; }
    else win->len = 0;
    sp_Fiber_yield(sp_box_poly_array(g));
  }
  /* a slice run ends on its short last group, as each_slice's does */
  if (!cap->cons && win->len > 0) sp_Fiber_yield(sp_box_poly_array(win));
}
sp_Enumerator *sp_Enumerator_regroup_gen(sp_Enumerator *e, sp_int n, sp_bool cons) {
  SP_GC_ROOT(e);
  sp_RgCap *cap = (sp_RgCap *)sp_gc_alloc(sizeof(sp_RgCap), NULL, sp_rg_cap_scan);
  SP_GC_ROOT(cap);
  cap->src = e; cap->n = n; cap->cons = cons;
  sp_Enumerator *r = sp_Enumerator_new_gen(sp_regroup_gen, cap, sp_box_nil());
  SP_GC_ROOT(r);
  r->source = e->source;
  const char *m = sp_sprintf(cons ? "each_cons(%lld)" : "each_slice(%lld)", (long long)n);
  sp_gc_wb((void *)r);   /* the sprintf can promote the rooted enumerator */
  r->meth = m;
  return sp_enum_inherit_size(r, e);
}
sp_Enumerator *sp_Enumerator_with_index(sp_Enumerator *e, sp_int off) {
  /* one over a String handle pairs its items again at each walk */
  if (sp_enum_live(e)) return sp_enum_derive(e, SP_ENUM_DER_PAIRS, off);
  /* an endless source pairs lazily too: its pairs never run out */
  if (e && (e->gen || e->endless)) {
    /* Two allocations, and two things held in nothing but a C local across
       them. The source enumerator dies at the sp_WiCap allocation below --
       which is before the cap exists, so rooting the cap cannot cover it --
       and both `e->size` and `e->source` are then read out of freed memory.
       The cap dies at the enumerator's own allocation and is not a dead local
       at that point: it is parked in r->gen_cap, which sp_with_index_gen reads
       when the fiber first runs and sp_Enumerator_scan walks on every later
       collection. Rooting either one alone leaves the other. */
    SP_GC_ROOT(e);
    sp_WiCap *cap = (sp_WiCap *)sp_gc_alloc(sizeof(sp_WiCap), NULL, sp_wi_cap_scan);
    SP_GC_ROOT(cap);
    cap->src = e; cap->off = off;
    sp_Enumerator *r = sp_Enumerator_new_gen(sp_with_index_gen, cap, e->size);
    r->source = e->source;
    r->yields_pair = TRUE;
    return sp_enum_inherit_size(r, e);
  }
  sp_PolyArray *src = e ? e->items : NULL;
  sp_int n = src ? src->len : 0;
  /* Root the source enumerator (a temp `arr.each` is otherwise unreachable): the
     sp_PolyArray_new below can collect it and free src mid-loop -> use-after-free
     of src->data[i] under GC stress. Rooting `e` keeps src alive transitively --
     sp_Enumerator_scan marks e->items and the GC is non-moving. */
  SP_GC_ROOT(e);
  sp_PolyArray *out = sp_PolyArray_new(); SP_GC_ROOT(out);
  for (sp_int i = 0; i < n; i++) {
    sp_PolyArray *pair = sp_PolyArray_new(); SP_GC_ROOT(pair);
    sp_PolyArray_push(pair, src->data[i]);
    sp_PolyArray_push(pair, sp_box_int(off + i));
    sp_PolyArray_push(out, sp_box_poly_array(pair));
  }
  { sp_RbVal src_recv = e ? e->source : sp_box_nil();
    sp_Enumerator *r = sp_Enumerator_new_from_items(out); r->source = src_recv; r->yields_pair = TRUE; return sp_enum_inherit_size(r, e); }
}
sp_Enumerator *sp_Enumerator_new_gen(void (*gen)(sp_Fiber *), void *cap, sp_RbVal size) {SP_GC_ROOT_RBVAL(size);
  sp_Enumerator *e = (sp_Enumerator *)sp_gc_alloc(sizeof(sp_Enumerator), NULL, sp_Enumerator_scan);
  e->items = NULL; e->cursor = 0; e->gen = gen; e->gen_cap = cap; e->fib = NULL; e->peeked = FALSE; e->size = size; e->feed = sp_box_nil(); e->has_feed = FALSE; e->gen_result = sp_box_nil(); e->source = sp_box_nil(); e->meth = SPL("each");
  return e;
}
/* Blockless Kernel#loop: an infinite Enumerator that yields nil forever (#3236).
   The generator is internal; only sp_loop_enum is exposed (spinel_rt.h). */
static void sp_loop_gen(sp_Fiber *f) {
  (void)f;
  for (;;) sp_Fiber_yield(sp_box_nil());
}
sp_Enumerator *sp_loop_enum(void) {
  sp_Enumerator *e = sp_Enumerator_new_gen(sp_loop_gen, NULL, sp_box_nil());
  e->meth = SPL("loop");
  return e;
}

/* IO.copy_stream(src_path, dst_path): stream one file to another, byte count. */
sp_int sp_io_copy_stream(const char *src, const char *dst) {SP_GC_ROOT_STR(src);SP_GC_ROOT_STR(dst);
  FILE *in = fopen(src ? src : "", "rb");
  if (!in)
    sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ rb_sysopen - %s", src ? src : ""));
  FILE *out = fopen(dst ? dst : "", "wb");
  if (!out) { fclose(in); sp_raise_cls("Errno::ENOENT",
                 sp_sprintf("No such file or directory @ rb_sysopen - %s", dst ? dst : "")); }
  char buf[8192]; size_t got; sp_int total = 0;
  while ((got = fread(buf, 1, sizeof buf, in)) > 0) { fwrite(buf, 1, got, out); total += (sp_int)got; }
  fclose(in); fclose(out);
  return total;
}

/* Array#combination / permutation over an int array (lib-only; the recursion
   helpers stay file-static, the four entry points are declared in spinel_rt.h). */
static void sp_int_combination_recur(sp_IntArray*src,sp_int start,sp_int k,sp_IntArray*acc,sp_PtrArray*out){SP_GC_ROOT(src);SP_GC_ROOT(acc);SP_GC_ROOT(out);if(k==0){sp_IntArray*cp=sp_IntArray_new();for(sp_int i=0;i<acc->len;i++)sp_IntArray_push_o(cp,sp_IntArray_oget(acc,i));sp_PtrArray_push(out,cp);return;}for(sp_int i=start;i<=src->len-k;i++){sp_IntArray_push_o(acc,sp_IntArray_oget(src,i));sp_int_combination_recur(src,i+1,k-1,acc,out);(void)sp_IntArray_pop_o(acc);}}
sp_PtrArray*sp_IntArray_combination(sp_IntArray*a,sp_int k){SP_GC_ROOT(a);sp_PtrArray*out=sp_PtrArray_new();SP_GC_ROOT(out);if(!a||k<0||k>a->len)return out;sp_IntArray*acc=sp_IntArray_new();SP_GC_ROOT(acc);sp_int_combination_recur(a,0,k,acc,out);return out;}
static void sp_int_repeated_combination_recur(sp_IntArray*src,sp_int start,sp_int k,sp_IntArray*acc,sp_PtrArray*out){SP_GC_ROOT(src);SP_GC_ROOT(acc);SP_GC_ROOT(out);if(k==0){sp_IntArray*cp=sp_IntArray_new();for(sp_int i=0;i<acc->len;i++)sp_IntArray_push_o(cp,sp_IntArray_oget(acc,i));sp_PtrArray_push(out,cp);return;}for(sp_int i=start;i<src->len;i++){sp_IntArray_push_o(acc,sp_IntArray_oget(src,i));sp_int_repeated_combination_recur(src,i,k-1,acc,out);(void)sp_IntArray_pop_o(acc);}}
sp_PtrArray*sp_IntArray_repeated_combination(sp_IntArray*a,sp_int k){SP_GC_ROOT(a);sp_PtrArray*out=sp_PtrArray_new();SP_GC_ROOT(out);if(!a||k<0)return out;sp_IntArray*acc=sp_IntArray_new();SP_GC_ROOT(acc);sp_int_repeated_combination_recur(a,0,k,acc,out);return out;}
static void sp_int_permutation_recur(sp_IntArray*src,sp_int k,sp_IntArray*used,sp_IntArray*acc,sp_PtrArray*out){SP_GC_ROOT(src);SP_GC_ROOT(used);SP_GC_ROOT(acc);SP_GC_ROOT(out);if(k==0){sp_IntArray*cp=sp_IntArray_new();for(sp_int i=0;i<acc->len;i++)sp_IntArray_push_o(cp,sp_IntArray_oget(acc,i));sp_PtrArray_push(out,cp);return;}for(sp_int i=0;i<src->len;i++){if(used->data[used->start+i])continue;used->data[used->start+i]=1;sp_IntArray_push_o(acc,sp_IntArray_oget(src,i));sp_int_permutation_recur(src,k-1,used,acc,out);(void)sp_IntArray_pop_o(acc);used->data[used->start+i]=0;}}
static void sp_int_repeated_permutation_recur(sp_IntArray*src,sp_int k,sp_IntArray*acc,sp_PtrArray*out){SP_GC_ROOT(src);SP_GC_ROOT(acc);SP_GC_ROOT(out);if(k==0){sp_IntArray*cp=sp_IntArray_new();SP_GC_ROOT(cp);for(sp_int i=0;i<acc->len;i++)sp_IntArray_push_o(cp,sp_IntArray_oget(acc,i));sp_PtrArray_push(out,cp);return;}for(sp_int i=0;i<src->len;i++){sp_IntArray_push_o(acc,sp_IntArray_oget(src,i));sp_int_repeated_permutation_recur(src,k-1,acc,out);(void)sp_IntArray_pop_o(acc);}}
sp_PtrArray*sp_IntArray_repeated_permutation(sp_IntArray*a,sp_int k){SP_GC_ROOT(a);sp_PtrArray*out=sp_PtrArray_new();SP_GC_ROOT(out);if(!a||k<0)return out;sp_IntArray*acc=sp_IntArray_new();SP_GC_ROOT(acc);sp_int_repeated_permutation_recur(a,k,acc,out);return out;}
sp_PtrArray*sp_IntArray_permutation(sp_IntArray*a,sp_int k){SP_GC_ROOT(a);sp_PtrArray*out=sp_PtrArray_new();SP_GC_ROOT(out);if(!a||k<0||k>a->len)return out;sp_IntArray*used=sp_IntArray_new();SP_GC_ROOT(used);for(sp_int i=0;i<a->len;i++)sp_IntArray_push(used,0);sp_IntArray*acc=sp_IntArray_new();SP_GC_ROOT(acc);sp_int_permutation_recur(a,k,used,acc,out);return out;}
sp_RbVal sp_enum_gen_pull(sp_Enumerator *e) {SP_GC_ROOT(e); sp_gc_wb((void*)e);
  if (!e->fib) {
    e->fib = sp_Fiber_new(e->gen);
    sp_gc_wb((void*)e);   /* sp_Fiber_new can collect: the record made on entry is gone by here */
    if (e->gen_cap) { sp_gc_wb((void*)e->fib); e->fib->user_data = e->gen_cap; }
  }
  if (!sp_Fiber_alive(e->fib)) sp_raise_stop_iteration(e->gen_result);
  sp_RbVal feed = e->has_feed ? e->feed : sp_box_nil();
  e->has_feed = FALSE; e->feed = sp_box_nil();   /* consumed by this resume */
  sp_RbVal v = sp_Fiber_resume(e->fib, feed);
  if (!sp_Fiber_alive(e->fib)) { e->gen_result = v; sp_gc_wb((void*)e); sp_raise_stop_iteration(v); }
  return v;
}
static void sp_enum_bsearch_advance(sp_Enumerator *e) {
  if (!e->bsearch_waiting) return;
  sp_RbVal v = e->has_feed ? e->feed : sp_box_nil();
  e->has_feed = FALSE; e->feed = sp_box_nil();
  if (v.tag == SP_TAG_INT) {
    if (v.v.i == 0) { e->bsearch_result = e->items->data[e->bsearch_mid]; e->bsearch_hi = e->bsearch_mid - 1; }
    else if (v.v.i < 0) e->bsearch_hi = e->bsearch_mid - 1;
    else e->bsearch_lo = e->bsearch_mid + 1;
  }
  else if (v.tag == SP_TAG_FLT) {
    if (v.v.f == 0.0) { e->bsearch_result = e->items->data[e->bsearch_mid]; e->bsearch_hi = e->bsearch_mid - 1; }
    else if (v.v.f < 0.0) e->bsearch_hi = e->bsearch_mid - 1;
    else e->bsearch_lo = e->bsearch_mid + 1;
  }
  else if (v.tag != SP_TAG_NIL && !(v.tag == SP_TAG_BOOL && !v.v.b)) {
    e->bsearch_result = e->items->data[e->bsearch_mid];
    e->bsearch_hi = e->bsearch_mid - 1;
  }
  else e->bsearch_lo = e->bsearch_mid + 1;
  e->bsearch_waiting = FALSE;
}
static sp_RbVal sp_enum_bsearch_next(sp_Enumerator *e) {
  SP_GC_ROOT(e);
  sp_enum_bsearch_advance(e);
  if (e->bsearch_lo > e->bsearch_hi) sp_raise_stop_iteration(e->bsearch_result);
  e->bsearch_mid = e->bsearch_lo + (e->bsearch_hi - e->bsearch_lo + 1) / 2;
  e->bsearch_waiting = TRUE;
  return e->items->data[e->bsearch_mid];
}
sp_RbVal sp_Enumerator_next(sp_Enumerator *e) {SP_GC_ROOT(e);
  if (e->is_bsearch) {
    if (e->peeked) { e->peeked = FALSE; e->bsearch_waiting = TRUE; return e->peek_val; }
    return sp_enum_bsearch_next(e);
  }
  if (e->gen) {
    if (e->peeked) { e->peeked = FALSE; return e->peek_val; }
    return sp_enum_gen_pull(e);
  }
  if (e->endless && e->items && e->items->len > 0 && e->cursor >= e->items->len) e->cursor = 0;
  if (!e->items || e->cursor >= e->items->len) {
    /* (a live Enumerator keeps no items of its own: its run is its own) */
    if (SP_UNLIKELY(e->live)) return sp_enum_live_next(e);
    sp_raise_stop_iteration(e->source);
  }
  return e->items->data[e->cursor++];
}
sp_RbVal sp_Enumerator_peek(sp_Enumerator *e) {SP_GC_ROOT(e); sp_gc_wb((void*)e);
  if (e->is_bsearch) {
    if (!e->peeked) {
      sp_enum_bsearch_advance(e);
      if (e->bsearch_lo > e->bsearch_hi) sp_raise_stop_iteration(e->bsearch_result);
      e->bsearch_mid = e->bsearch_lo + (e->bsearch_hi - e->bsearch_lo + 1) / 2;
      e->peek_val = e->items->data[e->bsearch_mid]; e->peeked = TRUE;
    }
    return e->peek_val;
  }
  if (e->gen) {
    if (!e->peeked) { e->peek_val = sp_enum_gen_pull(e); sp_gc_wb((void*)e); e->peeked = TRUE; }
    return e->peek_val;
  }
  if (e->endless && e->items && e->items->len > 0 && e->cursor >= e->items->len) { sp_gc_wb((void*)e); e->cursor = 0; }
  if (!e->items || e->cursor >= e->items->len) {
    if (SP_UNLIKELY(e->live)) return sp_enum_live_step(e, TRUE);
    sp_raise_stop_iteration(e->source);
  }
  return e->items->data[e->cursor];
}
sp_PolyArray *sp_enum_values_wrap(sp_RbVal v) {SP_GC_ROOT_RBVAL(v);
  if (v.tag == SP_TAG_OBJ && v.cls_id == SP_BUILTIN_POLY_ARRAY) return (sp_PolyArray *)v.v.p;
  sp_PolyArray *a = sp_PolyArray_new(); SP_GC_ROOT(a);
  sp_PolyArray_push(a, v);
  return a;
}
sp_PolyArray *sp_Enumerator_next_values(sp_Enumerator *e) {SP_GC_ROOT(e); return sp_enum_values_wrap(sp_Enumerator_next(e)); }
sp_PolyArray *sp_Enumerator_peek_values(sp_Enumerator *e) {SP_GC_ROOT(e); return sp_enum_values_wrap(sp_Enumerator_peek(e)); }
sp_Enumerator *sp_Enumerator_rewind(sp_Enumerator *e) { sp_gc_wb((void*)e);
  if (!e) return NULL;
  if (e->gen) { e->fib = NULL; e->peeked = FALSE; e->gen_result = sp_box_nil(); }
  else { e->cursor = 0; if (SP_UNLIKELY(e->live)) sp_enum_live_rewind(e); }
  if (e->is_bsearch) { e->bsearch_lo = 0; e->bsearch_hi = e->items ? e->items->len - 1 : -1; e->bsearch_mid = -1; e->bsearch_waiting = FALSE; e->bsearch_result = sp_box_nil(); e->peeked = FALSE; }
  e->feed = sp_box_nil(); e->has_feed = FALSE;
  return e;
}
sp_RbVal sp_Enumerator_feed(sp_Enumerator *e, sp_RbVal v) {SP_GC_ROOT_RBVAL(v);SP_GC_ROOT(e); sp_gc_wb((void*)e);
  if (!e) return sp_box_nil();
  if (e->has_feed) sp_raise_cls("TypeError", (&("\xff" "feed value already set")[1]));
  e->feed = v; e->has_feed = TRUE;
  return sp_box_nil();
}
sp_PolyArray *sp_Enumerator_take(sp_Enumerator *e, sp_int n) {SP_GC_ROOT(e);
  sp_PolyArray *r = sp_PolyArray_new();
  SP_GC_ROOT(r);
  if (n <= 0) return r;
  if (e->gen) {
    sp_Fiber *f = sp_Fiber_new(e->gen);
    SP_GC_ROOT(f);
    if (e->gen_cap) { sp_gc_wb((void*)f); f->user_data = e->gen_cap; }
    for (sp_int i = 0; i < n; i++) {
      if (!sp_Fiber_alive(f)) break;
      sp_RbVal v = sp_Fiber_resume(f, sp_box_nil());
      if (!sp_Fiber_alive(f)) break;
      sp_PolyArray_push(r, v);
    }
    return r;
  }
  e = sp_enum_walk(e);   /* (a live one's walk reads a copy of its own) */
  sp_int lim = e->items ? e->items->len : 0;
  /* an argless cycle repeats its round as far as n reaches */
  if (e->endless && lim > 0) {
    for (sp_int i = 0; i < n; i++) sp_PolyArray_push(r, e->items->data[i % lim]);
    return r;
  }
  if (n < lim) lim = n;
  for (sp_int i = 0; i < lim; i++) sp_PolyArray_push(r, e->items->data[i]);
  return r;
}
sp_PolyArray *sp_Enumerator_to_a(sp_Enumerator *e) {
  SP_GC_ROOT(e);   /* the allocation below can collect it */
  sp_PolyArray *r = sp_PolyArray_new();
  SP_GC_ROOT(r);
  if (!e) return r;
  if (e->gen) {
    sp_Fiber *f = sp_Fiber_new(e->gen);
    SP_GC_ROOT(f);
    if (e->gen_cap) { sp_gc_wb((void*)f); f->user_data = e->gen_cap; }
    while (sp_Fiber_alive(f)) {
      sp_RbVal v = sp_Fiber_resume(f, sp_box_nil());
      if (!sp_Fiber_alive(f)) break;
      sp_PolyArray_push(r, v);
    }
    return r;
  }
  e = sp_enum_walk(e);
  if (e->items) for (sp_int i = 0; i < e->items->len; i++) sp_PolyArray_push(r, e->items->data[i]);
  return r;
}
void sp_sig_c_handler(int no) {
  sp_Proc *p = (no >= 0 && no < SP_SIG_MAX) ? (sp_Proc *)sp_trap_proc[no] : NULL;
  if (p) sp_trap_call(p, no);
}
void sp_sig_exit_dispatch(void) {
  sp_Proc *p = (sp_Proc *)sp_trap_proc[0];
  sp_trap_proc[0] = NULL;   /* run once */
  if (p) { sp_int slot = 0; _sp_proc_poly_args[0] = sp_box_int(0); sp_proc_call(p, 1, &slot); }
}
sp_RbVal sp_signal_trap(sp_RbVal sig, sp_RbVal handler) {SP_GC_ROOT_RBVAL(sig);SP_GC_ROOT_RBVAL(handler);
  int no = sp_signal_resolve(sig);
  if (no == SIGKILL || no == SIGSTOP)
    sp_raise_cls("Errno::EINVAL",
                 sp_sprintf("Invalid argument - SIG%s", sp_signal_signame(no)));
  /* the previous handler: a stored proc or command string; an untouched
     signal reads "DEFAULT", except EXIT whose default handler is nil (#2839) */
  sp_RbVal prev = sp_trap_proc[no] ? sp_box_proc((sp_Proc *)sp_trap_proc[no])
                : sp_trap_state[no] ? sp_box_str(sp_trap_state[no])
                : no == 0 ? sp_box_nil()
                : sp_box_str((&("\xff" "DEFAULT")[1]));
  if (handler.tag == SP_TAG_OBJ && handler.cls_id == SP_BUILTIN_PROC && handler.v.p) {
    sp_trap_proc[no] = (sp_Proc *)handler.v.p;
    sp_trap_state[no] = NULL;
    if (no == 0) { static int armed = 0; if (!armed) { armed = 1; atexit(sp_sig_exit_dispatch); } }
    else {
      /* no SA_NODEFER: the signal stays blocked while its proc runs, so a
         second delivery waits instead of nesting (sp_trap_call) */
      struct sigaction sa; memset(&sa, 0, sizeof sa);
      sa.sa_handler = sp_sig_c_handler;
      sigemptyset(&sa.sa_mask);
      sa.sa_flags = SA_RESTART;
      sigaction(no, &sa, NULL);
    }
  }
  else {
    const char *hs = (handler.tag == SP_TAG_STR && handler.v.s) ? handler.v.s : "DEFAULT";
    int ignore = strcmp(hs, "IGNORE") == 0 || strcmp(hs, "SIG_IGN") == 0;
    sp_trap_proc[no] = NULL;
    /* SYSTEM_DEFAULT reads back as itself (#2839); it installs SIG_DFL too.
       An EXIT string command clears the handler, whose read-back is nil. */
    sp_trap_state[no] = no == 0 ? NULL
                      : ignore ? (&("\xff" "IGNORE")[1])
                      : strcmp(hs, "SYSTEM_DEFAULT") == 0 ? (&("\xff" "SYSTEM_DEFAULT")[1])
                      : (&("\xff" "DEFAULT")[1]);
    if (no != 0) signal(no, ignore ? SIG_IGN : SIG_DFL);
  }
  return prev;
}
sp_int sp_process_kill1(sp_RbVal sig, sp_int pid) {SP_GC_ROOT_RBVAL(sig);
  int no = sp_signal_resolve(sig);
  if (kill((pid_t)pid, no) != 0) {
    if (errno == ESRCH) sp_raise_cls("Errno::ESRCH", sp_sprintf("No such process - %lld", (long long)pid));
    if (errno == EPERM) sp_raise_cls("Errno::EPERM", sp_sprintf("Operation not permitted - %lld", (long long)pid));
    sp_raise_cls("Errno::EINVAL", "Invalid argument");
  }
  return 1;
}
sp_RbVal sp_Enumerator_size(sp_Enumerator *e) {SP_GC_ROOT(e);
  if (!e) return sp_box_nil();
  /* the chunk family (chunk, chunk_while, slice_when, slice_before,
     slice_after) answers a Generator-backed Enumerator in CRuby, whose size is
     unknown until it is walked: nil, though the items here are a snapshot */
  if (e->gen_label) return sp_box_nil();
  if (e->size_nil) return sp_box_nil();
  /* an argless cycle is endless unless there is nothing to repeat */
  if (e->endless) return (e->items && e->items->len > 0) ? sp_box_float(1.0 / 0.0) : sp_box_int(0);
  /* These searches can stop at their first hit, so CRuby gives their
     Enumerator no size; neither gsub's nor gsub!'s Enumerator has one. */
  if (e->meth && (strcmp(e->meth, "bsearch") == 0 ||
                  strcmp(e->meth, "index") == 0 || strcmp(e->meth, "rindex") == 0 ||
                  strcmp(e->meth, "find_index") == 0 ||
                  strncmp(e->meth, "gsub(", 5) == 0 || strncmp(e->meth, "gsub!(", 6) == 0))
    return sp_box_nil();
  /* over a String handle, the String's count now */
  if (SP_UNLIKELY(e->live)) return sp_enum_live_size(e);
  if (e->items) return sp_box_int(e->items->len);
  if (e->size.tag == SP_TAG_OBJ && e->size.cls_id == SP_BUILTIN_PROC) {
    (void)sp_proc_call((sp_Proc *)e->size.v.p, 0, NULL);
    return _sp_proc_poly_ret;
  }
  return e->size;
}
sp_RbVal sp_Enumerator_size_p(void *e) { return sp_Enumerator_size((sp_Enumerator *)e); }
/* A boxed index search's or substitution's Enumerator (`a.index`,
   `s.gsub!(re)` reached through a branch): its each block picks an index
   or is the replacement, which the generic element walk does not compute,
   so say so rather than answer the receiver. One read straight off its
   call is rewritten to the block form before it gets here. */
/* The blockless collectors' Enumerators: each with a block answers what the
   collector answers (`[1, 2].map.each { |v| v * 10 }` is [10, 20]), which
   the generic walk, answering its receiver, does not compute either. */
static const char *const sp_enum_collector_meths[] = {
  "map", "collect", "flat_map", "collect_concat", "select", "filter", "filter_map",
  "reject", "find", "detect", "find_all", "sort_by", "min_by", "max_by", "minmax_by",
  "group_by", "partition", "sum", "count", "each_with_object", "inject", "reduce",
  "uniq", "chunk_while", "slice_when", "take_while", "drop_while", "tally_by",
  "map!", "collect!", "select!", "filter!", "reject!", "keep_if", "delete_if", "sort_by!",
  NULL };
void sp_enum_index_search_each_raise(void *p) {
  const char *em = ((sp_Enumerator *)p)->meth;
  int coll = 0;
  for (int i = 0; em && sp_enum_collector_meths[i]; i++)
    if (strcmp(em, sp_enum_collector_meths[i]) == 0) { coll = 1; break; }
  if (em && (coll || strcmp(em, "index") == 0 || strcmp(em, "rindex") == 0 || strcmp(em, "find_index") == 0 ||
             strncmp(em, "gsub(", 5) == 0 || strncmp(em, "gsub!(", 6) == 0))
    sp_raise_cls("NotImplementedError",
                 sp_sprintf("spinel: each on a boxed %s Enumerator is not supported", em));
}

/* ---- ENV core (StrStrHash-backed, #2832/#2842) + GC.stat + String#setbyte
   COW -- relocated from spinel_rt.h. All reach only lib-visible helpers
   (sp_StrStrHash_*, sp_str_alloc/_raw, sp_str_check_mutable in sp_alloc.h,
   SP_HEAP_LOCK/UNLOCK, sp_gc_* counters in sp_gc.h). ---- */
#include "sp_hash.h"

/* ENV.shift: remove and return the first [key, value] pair, or nil */
sp_RbVal sp_env_shift(void) {
  extern char **environ;
  if (!environ || !*environ) return sp_box_nil();
  const char *ent = *environ;
  const char *eq = strchr(ent, '=');
  size_t n = eq ? (size_t)(eq - ent) : strlen(ent);
  char *k = sp_str_alloc(n);
  memcpy(k, ent, n); k[n] = 0;
  ((unsigned char *)k)[-1] = 0xfa;
  SP_GC_ROOT_STR(k);
  const char *v = sp_env_str(eq ? eq + 1 : "");
  SP_GC_ROOT_STR(v);
  sp_PolyArray *a = sp_PolyArray_new();
  SP_GC_ROOT(a);
  sp_PolyArray_push(a, sp_box_str(k));
  sp_PolyArray_push(a, sp_box_str(v));
  unsetenv(k);
  return sp_box_poly_array(a);
}
sp_int sp_env_size(void) {
  extern char **environ;
  sp_int n = 0;
  for (char **e = environ; e && *e; e++) n++;
  return n;
}
/* A snapshot of the environment as a StrStr hash: ENV's enumeration surface
   (keys/each/select/count{...}/inspect/...) is desugared onto it, so the
   whole Hash machinery serves it (#2742). Keys/values are copied onto the
   GC string heap -- environ storage may move under setenv. */
/* ENV mutators (#2832). Each returns the fresh snapshot so the expression
   value renders like ENV does. */
sp_StrStrHash *sp_env_to_h(void) {
  extern char **environ;
  sp_StrStrHash *h = sp_StrStrHash_new();
  SP_GC_ROOT(h);
  for (char **e = environ; e && *e; e++) {
    const char *eq = strchr(*e, '=');
    if (!eq) continue;
    /* copy the VALUE first and root it: the key below is a fresh unreachable
       heap string until the set, and the value copy may GC (#2842 -- a large
       environment collected mid-loop and swept the just-built key) */
    const char *v = sp_env_str(eq + 1);
    SP_GC_ROOT_STR(v);
    size_t kl = (size_t)(eq - *e);
    char *k = sp_str_alloc_raw(kl + 1);
    memcpy(k, *e, kl); k[kl] = 0;
    sp_StrStrHash_set(h, k, v);
  }
  return h;
}
sp_StrStrHash *sp_env_clear(void) {
  extern char **environ;
  for (;;) {   /* environ shifts under unsetenv: restart until empty */
    char **e = environ;
    if (!e || !*e) break;
    const char *eq = strchr(*e, '=');
    size_t n = eq ? (size_t)(eq - *e) : strlen(*e);
    char k[512];
    if (n >= sizeof k) n = sizeof k - 1;
    memcpy(k, *e, n); k[n] = 0;
    unsetenv(k);
  }
  return sp_env_to_h();
}
/* ENV.update/merge!/replace with a string-pair hash. The pairs are stored
   in order, so the ones before a name or value CRuby rejects stay set;
   replace then deletes every variable the hash does not name, as
   sp_env_update_v does. */
sp_StrStrHash *sp_env_update_h(sp_StrStrHash *h, int replace) {
  if (h) {
    SP_GC_ROOT(h);
    for (sp_int i = 0; i < h->len; i++) {
      const char *v = sp_StrStrHash_get(h, h->order[i]);
      sp_env_chk(h->order[i], 0);
      if (v) setenv(h->order[i], sp_env_chk(v, 1), 1); else unsetenv(h->order[i]);
    }
  }
  sp_StrStrHash *env = sp_env_to_h();
  if (replace) {
    SP_GC_ROOT(env);
    for (sp_int i = 0; i < env->len; i++)
      if (!h || !sp_StrStrHash_has_key(h, env->order[i])) unsetenv(env->order[i]);
    env = sp_env_to_h();
  }
  return env;
}
/* Keys are spinel rodata literals (SPL: 0xff marker prefix) so the str-hash
   header cache's s[-1] read is in-bounds -- a bare C literal here would
   overread (and could alias a heap marker on some rodata layouts). */
struct sp_gc_stat_str_acc { size_t *b; sp_int *c; };
static void sp_gc_stat_str_cb(void *hdr, void *arg) {
  struct sp_gc_stat_str_acc *a = (struct sp_gc_stat_str_acc *)arg;
  *a->b += ((sp_str_hdr *)hdr)->size & SP_STR_SIZE_MASK; (*a->c)++;
}
sp_StrIntHash*sp_gc_stat(void){
  /* The string heap (sp_str_heap) is malloc'd separately and deliberately
     excluded from sp_gc_bytes (see sp_str_alloc). Surface its footprint so
     GC.stat can explain "RSS huge but bytes tiny" for string-heavy workloads.
     Prototype: O(n) walk; a production version maintains a running counter.
     The walk holds the heap lock: sp_str_alloc pushes onto this list under
     it from any worker, and an unlocked traversal could read a half-linked
     node. Unlock before building the hash -- sp_gc_alloc takes the same
     (non-recursive) lock. */
  size_t str_bytes=0; sp_int str_count=0;
  /* the slab strings: a bit per slot in the chunks' bitmaps, either
     generation (a racy read against the allocating workers, benign for an
     introspection stat), then the lists of the strings too large for it */
  { struct sp_gc_stat_str_acc acc = { &str_bytes, &str_count };
    sp_slab_each_string(1, 1, sp_gc_stat_str_cb, &acc); }
#ifdef SP_THREADS
  /* Per-worker lists (see sp_alloc.h): each has a single pusher, and only the
     head moves, so a snapshot walk reaches fully-linked nodes -- at worst it
     misses a just-pushed one (benign undercount for an introspection stat). */
  { int nw = sp_active_workers; if (nw < 1) nw = 1; if (nw > SP_MAX_WORKERS) nw = SP_MAX_WORKERS;
    for (int wi = 0; wi < nw; wi++) {
      for(int sub=0; sub<SP_STR_YSUB; sub++)
        for(sp_str_hdr*sh=sp_str_wslot[wi].young[sub]; sh; sh=sh->next){ str_bytes+=sh->size & SP_STR_SIZE_MASK; str_count++; }
      for(sp_str_hdr*sh=sp_str_wslot[wi].old; sh; sh=sh->next){ str_bytes+=sh->size & SP_STR_SIZE_MASK; str_count++; } } }
#else
  SP_HEAP_LOCK();
  /* Both generations: the split is an internal sweep optimization, so the
     reported footprint has to stay the whole string heap. */
  for(sp_str_hdr*sh=sp_str_heap; sh; sh=sh->next){ str_bytes+=sh->size & SP_STR_SIZE_MASK; str_count++; }
  for(sp_str_hdr*sh=sp_str_old; sh; sh=sh->next){ str_bytes+=sh->size & SP_STR_SIZE_MASK; str_count++; }
  SP_HEAP_UNLOCK();
#endif
  sp_StrIntHash*h=sp_StrIntHash_new();sp_StrIntHash_set(h,SPL("bytes"),(sp_int)SP_GC_CTR_GET(sp_gc_bytes));sp_StrIntHash_set(h,SPL("old_bytes"),(sp_int)sp_gc_old_bytes);sp_StrIntHash_set(h,SPL("threshold"),(sp_int)sp_gc_threshold);sp_StrIntHash_set(h,SPL("cycle"),(sp_int)sp_gc_cycle);sp_StrIntHash_set(h,SPL("full_runs"),(sp_int)sp_gc_full_runs);sp_StrIntHash_set(h,SPL("remembered"),(sp_int)sp_gc_nremembered);sp_StrIntHash_set(h,SPL("remembered_peak"),(sp_int)sp_gc_rem_peak);sp_StrIntHash_set(h,SPL("str_bytes"),(sp_int)str_bytes);sp_StrIntHash_set(h,SPL("str_count"),str_count);return h;}
/* String#setbyte over value-semantics strings: copy-on-write (a literal's
   bytes are static storage). The caller re-binds an lvalue receiver. */
const char *sp_str_setbyte_cow(const char *s, sp_int i, sp_int v) {SP_GC_ROOT_STR(s);
  if (!s) s = "";
  /* an explicitly frozen string (or a frozen-string-literal file's literal,
     both carry the 0xf1 marker) still raises; a HEAP string mutates in
     place so aliases observe the write (CRuby identity semantics); only a
     plain literal -- static storage, marker 0xff -- copies (#2029). */
  sp_str_check_mutable(s);
  /* NUL-safe stored length: strlen would stop at the first NUL byte, making
     every setbyte on a NUL-prefixed buffer (e.g. Array.new(n, 0).pack("C*"))
     raise IndexError. */
  sp_int n = (sp_int)sp_str_byte_len(s);
  if (i < 0) i += n;
  if (i < 0 || i >= n) {
    sp_raise_cls("IndexError", sp_sprintf("index %lld out of string", (long long)i));
    return s;
  }
  {
    unsigned char m = ((const unsigned char *)s)[-1];
    if (m == 0xfe || m == 0xfc) {
      (((sp_str_hdr *)(s - 1)) - 1)->hash = 0;  /* invalidate cached key hash */
      (((sp_str_hdr *)(s - 1)) - 1)->size &= ~SP_STR_SIZE_ASCII7;  /* and the 7-bit answer */
      ((char *)s)[i] = (char)(v & 0xff);
      return s;
    }
    if (m == 0xfd) { ((char *)s)[i] = (char)(v & 0xff); return s; }
  }
  char *r = sp_str_alloc((size_t)n);
  memcpy(r, s, (size_t)n);
  r[n] = 0;
  r[i] = (char)(v & 0xff);
  return r;
}

/* ---- Range#include?/#cover? + Range#to_s -- relocated from spinel_rt.h.
   0 optcarrot uses; reach only sp_range.h's inline core + sp_sprintf
   (resolved at final link against the generated TU). ---- */
#include "sp_range.h"

/* The caller has checked the boxed Range kind and its non-NULL payload. */
sp_RbVal sp_range_dup(sp_RbVal v, int keep_frozen) {
  switch (v.cls_id) {
    case SP_BUILTIN_RANGE: {
      sp_Range r = *(sp_Range *)v.v.p;
      if (!keep_frozen) r.unfrozen = 1;
      return sp_box_range(r);
    }
    case SP_BUILTIN_FLOAT_RANGE: {
      sp_FloatRange r = *(sp_FloatRange *)v.v.p;
      if (!keep_frozen) r.unfrozen = 1;
      return sp_box_frange(r);
    }
    case SP_BUILTIN_STR_RANGE: {
      sp_StrRange r = *(sp_StrRange *)v.v.p;   /* the handles as kept: a copy shares the endpoints */
      if (!keep_frozen) r.unfrozen = 1;
      return sp_box_srange(r);
    }
  }
  return v;
}
void sp_range_freeze(sp_RbVal v) {
  switch (v.cls_id) {
    case SP_BUILTIN_RANGE: ((sp_Range *)v.v.p)->unfrozen = 0; break;
    case SP_BUILTIN_FLOAT_RANGE: ((sp_FloatRange *)v.v.p)->unfrozen = 0; break;
    case SP_BUILTIN_STR_RANGE: ((sp_StrRange *)v.v.p)->unfrozen = 0; break;
  }
}
sp_bool sp_range_frozen(sp_RbVal v) {
  switch (v.cls_id) {
    case SP_BUILTIN_RANGE: return !((sp_Range *)v.v.p)->unfrozen;
    case SP_BUILTIN_FLOAT_RANGE: return !((sp_FloatRange *)v.v.p)->unfrozen;
    case SP_BUILTIN_STR_RANGE: return !((sp_StrRange *)v.v.p)->unfrozen;
  }
  return TRUE;
}

/* `Range#include?`/`#cover?` on the boxed (SP_TAG_OBJ cls_id
   SP_BUILTIN_RANGE) Range value. The direct sp_Range typed path
   inlines this same check via compile_range_method_expr; poly-recv
   dispatch needs the wrapper so the cls_id arm in
   emit_poly_builtin_dispatch can land on a single C expression. An
   exclusive range stops one short of `last`, so the upper bound is
   `last - excl` (excl is 0 or 1). */
sp_bool sp_range_include(sp_Range *r, sp_int x){SP_GC_ROOT(r);
  /* a beginless/endless side (nobeg/noend) clamps one side open */
  if (r->nobeg || r->noend) {
    if (r->nobeg == 0 && x < r->first) return 0;
    if (r->noend == 0 && (r->excl ? x >= r->last : x > r->last)) return 0;
    return 1;
  }
  /* a Float end: an Integer is in it when the walk reaches it */
  if (r->fe) return x >= r->first && (r->excl ? x < r->last : x <= r->last);
  /* a plain (step 1) range compares x against its bounds directly: its
     count overflows the word for a span past 2**63 ((-2**63..0) has
     2**63 + 1 members), and the empty-range test read that as empty */
  if (r->step == 0 || r->step == 1) return x >= r->first && (r->excl ? x < r->last : x <= r->last);
  if(sp_range_count(*r)<=0)return FALSE;
  sp_oint lo=sp_range_min_v(*r),hi=sp_range_max_v(*r);
  return !lo.nil && !hi.nil && lo.v<=x && x<=hi.v;
}
/* A Float is compared against the bounds as a Float, never truncated: 2.5 is
   not in 1..2. The sentinels leave their side open, as in sp_range_include. */
sp_bool sp_range_cover_f(sp_Range *r, sp_float x){
  if (x != x) return 0;   /* NaN is in no range */
  /* an Integer bound against x exactly (#7505): a double past 2^53 rounds */
  if (r->nobeg == 0 && sp_int_flt_cmp(r->first, x) > 0) return 0;
  if (r->fe) return r->fe==2?x<r->fend:x<=r->fend;
  if (r->noend) return 1;
  int c = sp_int_flt_cmp(r->last, x);
  return r->excl ? c > 0 : c >= 0;}
sp_Range sp_range_new_fend(sp_int f, sp_float e, sp_int x) {
  sp_Range r = sp_range_new(f, 0, 0);
  r.fend = e; r.fe = x ? 2 : 1;
  sp_float fl = floor(e);
  if (e != e) sp_raise_cls("ArgumentError", "bad value for range");   /* NaN compares with nothing */
  if (fl >= 9.2e18) { r.last = INTPTR_MAX; return r; }  /* past sp_int: no end to walk to */
  if (fl <= -9.2e18) { r.last = f - 1; return r; }
  r.last = (sp_int)fl;
  if (x && fl == e) r.excl = 1;                         /* 1...3.0 stops before 3 */
  return r;
}
/* Range#max of an Integer range whose end is a Float (and not empty): an
   excluded Float end has no greatest member, as CRuby says; an included
   one is the maximum, a Float an Integer slot cannot hold. */
void sp_range_fend_unsupported(const char *m) {
  sp_raise_cls("NotImplementedError", sp_sprintf("%s: this Range's end is a Float, which spinel answers here only in Integers", m));
}
void sp_range_fend_max_raise(sp_Range r) {
  if (r.fe == 2) sp_raise_cls("TypeError", "cannot exclude non Integer end value");
  sp_raise_cls("NotImplementedError", "Range#max: this Range's end is a Float, which spinel reads here as an Integer");
}
/* Render a Range for a RangeError message ("-10..1", "1...3", "-10..", "..2"). */
/* Range#inspect: as #to_s, except that a range with NO bound at either end
   names them -- CRuby prints "nil..nil", not ".." (#3670). */
const char *sp_range_inspect(sp_Range r) {
  if (r.nobeg && r.noend)
    return r.excl ? (&("\xff" "nil...nil")[1]) : (&("\xff" "nil..nil")[1]);
  return sp_range_str(r);
}
const char *sp_range_str(sp_Range r) {
  if (r.fe) return sp_sprintf("%lld%s%s", (long long)r.first, r.fe == 2 ? "..." : "..", sp_float_to_s(r.fend));
  const char *dots = r.excl ? "..." : "..";
  if (r.nobeg && r.noend) return dots;
  if (r.nobeg) return sp_sprintf("%s%lld", dots, (long long)r.last);
  if (r.noend)  return sp_sprintf("%lld%s", (long long)r.first, dots);
  return sp_sprintf("%lld%s%lld", (long long)r.first, dots, (long long)r.last);
}

/* ---- Integer leaf ops (chr/digits/bit_length/bit_range/to_s_base/opt
   variants/pow) -- relocated from spinel_rt.h. All reach only lib-visible
   helpers (sp_str_alloc_raw/sp_str_set_len/sp_int_to_s in sp_alloc.h,
   sp_utf8_encode in sp_str.h, the overflow_p trio now also in sp_alloc.h).
   ---- */

/* Integer#chr: a single byte; CRuby raises RangeError outside 0..255.
   A byte above 7-bit is BINARY, as CRuby's is (`200.chr.encoding` is
   ASCII-8BIT; only 0..127 come back on the text side). The tag is what makes
   the byte comparable to other bytes: without it, a string built from `chr`
   and one read back from a file held the same bytes and answered `==` false,
   because equal bytes are equal strings only when the encodings are (the
   rule sp_str_eq implements). Found round-tripping every byte value through
   the zlib package. */
const char*sp_int_chr(sp_int n){
  if(n<0||n>255)sp_raise_cls("RangeError",sp_sprintf("%lld out of char range",(long long)n));
  if(n>=0x80)return sp_bin_char((unsigned char)n);
  return sp_plain_char((unsigned char)n);
}
/* Integer#chr(Encoding::UTF_8): encode the codepoint as UTF-8 (1-4 bytes).
   CRuby raises RangeError for a negative/too-large codepoint and for the
   surrogate range, which UTF-8 cannot carry. */
const char*sp_int_chr_utf8(sp_int n){
  if(n<0||n>0x10FFFF)sp_raise_cls("RangeError",sp_sprintf("%lld out of char range",(long long)n));
  if(n>=0xD800&&n<=0xDFFF)sp_raise_cls("RangeError",sp_sprintf("invalid codepoint 0x%llX in UTF-8",(long long)n));
  char*s=sp_str_alloc_raw(5);char*p=s;
  if(n<0x80){*p++=(char)n;}
  else if(n<0x800){*p++=(char)(0xC0|(n>>6));*p++=(char)(0x80|(n&0x3F));}
  else if(n<0x10000){*p++=(char)(0xE0|(n>>12));*p++=(char)(0x80|((n>>6)&0x3F));*p++=(char)(0x80|(n&0x3F));}
  else{*p++=(char)(0xF0|(n>>18));*p++=(char)(0x80|((n>>12)&0x3F));*p++=(char)(0x80|((n>>6)&0x3F));*p++=(char)(0x80|(n&0x3F));}
  *p=0;sp_str_set_len(s,(size_t)(p-s));return s;
}
/* Issue #882: `"hello" << 33` should append the character with
   that codepoint, not the decimal digits. UTF-8 encode (1..4 bytes)
   and return a NUL-terminated string. */
const char *sp_int_codepoint_to_str(sp_int n) {
  /* String#<< / #concat with an out-of-range codepoint raises RangeError,
     matching CRuby ("N out of char range"). */
  if (n < 0 || n > 0x10FFFF) sp_raise_cls("RangeError", sp_sprintf("%lld out of char range", (long long)n));
  char *s = sp_str_alloc_raw(5);
  int len = sp_utf8_encode((uint32_t)n, s);
  s[len] = 0;
  sp_str_set_len(s, (size_t)len);  /* byte_len must be the encoded length, not the alloc */
  return s;
}
/* The same appended to `recv`: a BINARY receiver takes the Integer as one
   byte, 0..255, and raises RangeError past it, as CRuby's ASCII-8BIT String
   does; `"".b << 231` is [231], not the UTF-8 [195, 167] (#5538). */
const char *sp_int_codepoint_to_str_in(const char *recv, sp_int n) {
  if (recv && sp_str_is_binary(recv)) {
    if (n < 0 || n > 255) sp_raise_cls("RangeError", sp_sprintf("%lld out of char range", (long long)n));
    return sp_bin_char((unsigned char)n);
  }
  return sp_int_codepoint_to_str(n);
}
/* sp_IntArray lives in sp_array.h (hot core inline) + lib/sp_array.c
   (cold ops). The Integer methods that happen to build an IntArray stay
   here; they call the inline sp_IntArray_new / _push from sp_array.h. */
sp_IntArray*sp_int_digits(sp_int n,sp_int base){if(base<0)sp_raise_cls("ArgumentError","negative radix");if(base<2)sp_raise_cls("ArgumentError",sp_sprintf("invalid radix %lld",(long long)base));if(n<0)sp_raise_cls("Math::DomainError","out of domain");sp_IntArray*a=sp_IntArray_new();if(n==0){sp_IntArray_push(a,0);return a;}while(n>0){sp_IntArray_push(a,n%base);n/=base;}return a;}
/* Integer#bit_length: bits in the two's-complement representation excluding
   the sign bit (a negative n counts the bits of ~n). */
sp_int sp_int_bit_length(sp_int n){unsigned long long x=(n<0)?(unsigned long long)(~n):(unsigned long long)n;sp_int b=0;if(x>=1ULL<<32){b+=32;x>>=32;}if(x>=1ULL<<16){b+=16;x>>=16;}if(x>=1ULL<<8){b+=8;x>>=8;}if(x>=1ULL<<4){b+=4;x>>=4;}if(x>=1ULL<<2){b+=2;x>>=2;}if(x>=1ULL<<1){b+=1;x>>=1;}return b+(sp_int)x;}
sp_int sp_int_bit_range(sp_int n, sp_int start, sp_int len) {
  sp_int shifted;
  const sp_int w = (sp_int)(sizeof(sp_int) * 8);
  if (start >= 0) shifted = (start >= w) ? (n < 0 ? -1 : 0) : (n >> start);
  else { sp_int s = -start; shifted = (s >= w) ? 0 : (sp_int)((uintptr_t)n << s); }
  uint64_t mask = (len <= 0) ? (len == 0 ? (uint64_t)0 : ~(uint64_t)0)
                             : (len >= 64 ? ~(uint64_t)0 : (((uint64_t)1 << len) - 1));
  return (sp_int)((uint64_t)shifted & mask);
}
/* sp_int_to_s / sp_float_to_s moved to sp_alloc.h (shared so lib/sp_json.c can
   format numbers). String-interpolation of a nullable int slot: nil renders
   as the empty string (CRuby interpolates nil as ""), every other value as its
   decimal. */
const char*sp_int_interp(sp_oint n){return n.nil?sp_str_empty:sp_int_to_s(n.v);}
const char*sp_int_to_s_base(sp_int n,sp_int base){if(base<2||base>36)sp_raise_cls("ArgumentError",sp_sprintf("invalid radix %lld",(long long)base));char*b=sp_str_alloc_raw(72);char tmp[72];int i=0;int neg=0;uint64_t u;if(n<0){neg=1;u=(uint64_t)(-(n+1))+1;}
else{u=(uint64_t)n;}if(u==0){tmp[i++]='0';}
else{while(u>0){sp_int d=u%base;tmp[i++]=d<10?'0'+d:'a'+d-10;u/=base;}}int j=0;if(neg)b[j++]='-';while(i>0)b[j++]=tmp[--i];b[j]=0;sp_str_set_len(b,(size_t)j);return b;}
/* Inspect / to_s for an int? value. CRuby distinguishes the two on
   nil: `nil.to_s` is "" while `nil.inspect` is "nil". For a real
   integer they agree (Integer#to_s and #inspect are both the decimal
   form). Two wrappers keep call-site emit local. */
const char *sp_int_opt_inspect(sp_oint v) { return v.nil ? "nil" : sp_int_to_s(v.v); }
const char *sp_int_opt_to_s(sp_oint v)    { return v.nil ? "" : sp_int_to_s(v.v); }
sp_int sp_int_pow(sp_int base, sp_int exp) {
  if (exp < 0) sp_raise_cls("RangeError", "negative exponent");
  /* Exact square-and-multiply (the old pow(double) round-trip lost precision
     above 2^53 and saturated on overflow). Overflow follows the +/-/* mode:
     raise by default, wrap under SP_INT_OVERFLOW_MODE_WRAP. */
  sp_int r = 1, b = base;
  while (exp > 0) {
#ifdef SP_INT_OVERFLOW_MODE_WRAP
    if (exp & 1) r = (sp_int)((uintptr_t)r * (uintptr_t)b);
    exp >>= 1;
    if (exp) b = (sp_int)((uintptr_t)b * (uintptr_t)b);
#else
    if (exp & 1) { if (sp_int_mul_overflow_p(r, b, &r)) sp_raise_cls("RangeError", "integer overflow in **"); }
    exp >>= 1;
    if (exp) { if (sp_int_mul_overflow_p(b, b, &b)) sp_raise_cls("RangeError", "integer overflow in **"); }
#endif
  }
  return r;
}

/* ---- ARGV cache + ARGF cold ops -- relocated from spinel_rt.h. sp_argv /
   sp_argf_obj are extern (sp_argf.h), defined by the generated main(). ---- */
#include "sp_argf.h"

sp_StrArray *sp_argv_array_cache = NULL;

void *sp_main_obj = NULL;
sp_RbVal sp_main_self(void) {
  void *m = SP_ATOMIC_LOAD(&sp_main_obj, __ATOMIC_ACQUIRE);
  if (!m) {
    void *fresh = sp_gc_alloc(1, NULL, NULL);   /* sizeof(sp_Object) */
    if (SP_ATOMIC_CAS(&sp_main_obj, &m, fresh, 0, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE))
      m = fresh;   /* else another thread won; m holds its object */
  }
  return sp_box_obj(m, SP_BUILTIN_OBJECT);
}
sp_StrArray *sp_get_ARGV(void) {
  if (!sp_argv_array_cache) {
    sp_argv_array_cache = sp_StrArray_new();
    for (sp_int i = 0; i < sp_argv.len; i++) sp_StrArray_push(sp_argv_array_cache, sp_argv.data[i]);
  }
  return sp_argv_array_cache;
}
sp_StrArray *sp_loaded_features_cache = NULL;
sp_StrArray *sp_get_loaded_features(void) {
  if (!sp_loaded_features_cache) sp_loaded_features_cache = sp_StrArray_new();
  return sp_loaded_features_cache;
}
sp_StrArray *sp_load_path_cache = NULL;
sp_StrArray *sp_get_load_path(void) {
  if (!sp_load_path_cache) sp_load_path_cache = sp_StrArray_new();
  return sp_load_path_cache;
}
/* Ensure a current readable stream, or return 0 at total end of input.
   The files are the program's ARGV as it stands when ARGF needs the next
   one, taken off its front as each is opened, as CRuby's ARGF does; a file
   that does not open raises. With ARGV empty before any file, stdin. */
int sp_argf_ensure(void) {
  if (sp_argf_obj.cur) return 1;
  sp_StrArray *av = sp_get_ARGV();
  if (av->len == 0) {
    if (sp_argf_obj.started) return 0;
    sp_argf_obj.started = 1; sp_argf_obj.cur = stdin; sp_argf_obj.fname = &("\xff" "-")[1];
    return 1;
  }
  const char *fn = sp_StrArray_shift(av);
  sp_argf_obj.started = 1;
  if (!fn) sp_raise_cls("TypeError", "no implicit conversion of nil into String");
  sp_argf_obj.fname = fn;   /* marked with the ARGV globals */
  if (fn[0] == '-' && fn[1] == 0) { sp_argf_obj.cur = stdin; return 1; }
  FILE *f = fopen(fn, "r");
  if (!f) sp_file_raise_errno("rb_sysopen", fn);
  sp_argf_obj.cur = f;
  return 1;
}
const char *sp_argf_gets(void) {
  /* getline answers the line whole, however long, with its byte count: a
     NUL inside the line neither ends it nor drops what follows (#4927) */
  static char *line = NULL;
  static size_t cap = 0;
  for (;;) {
    if (!sp_argf_ensure()) return NULL;
    ssize_t n = getline(&line, &cap, sp_argf_obj.cur);
    if (n >= 0) {
      char *r = sp_str_alloc_raw((size_t)n + 1);
      memcpy(r, line, (size_t)n); r[n] = '\0';
      sp_str_set_len(r, (size_t)n);
      return r;
    }
    if (sp_argf_obj.cur && sp_argf_obj.cur != stdin) fclose(sp_argf_obj.cur);
    sp_argf_obj.cur = NULL;  /* EOF on this stream; advance on next ensure */
  }
}
const char *sp_argf_read(void) {
  sp_String *s = sp_String_new(""); SP_GC_ROOT(s);
  const char *line;
  while ((line = sp_argf_gets())) sp_String_append(s, line);
  return sp_str_dup(s->data);
}
sp_StrArray *sp_argf_readlines(void) {
  sp_StrArray *a = sp_StrArray_new(); SP_GC_ROOT(a);
  const char *line;
  while ((line = sp_argf_gets())) sp_StrArray_push(a, line);
  return a;
}
/* CRuby opens the next file to name it, so ARGV loses it here too */
const char *sp_argf_filename(void) {
  sp_argf_ensure();
  return sp_argf_obj.fname ? sp_argf_obj.fname : &("\xff" "-")[1];
}
sp_bool sp_argf_eof(void) { return !sp_argf_ensure(); }

/* ---- Float/String Range value-type ops -- relocated from spinel_rt.h.
   0 optcarrot uses; reach only sp_range.h + lib-visible sp_float_to_s/
   sp_str_inspect/sp_str_eq/sp_StrArray_from_string_range/sp_sprintf. ---- */

/* Float range (1.0..3.0). Endpoints stay sp_float, so cover?/include?/begin/end
   are exact. -HUGE_VAL / +HUGE_VAL are the beginless / endless sentinels. */
/* A NaN bound compares with nothing, so CRuby refuses a range that has one
   and another bound to compare it with; a beginless or endless one is kept. */
static void sp_frange_check(sp_float f, sp_float l, sp_int om) {
  if (!(om & SP_FRANGE_NO_BEGIN) && !(om & SP_FRANGE_NO_END) && (f != f || l != l))
    sp_raise_cls("ArgumentError", "bad value for range");
}
sp_FloatRange sp_frange_new(sp_float f, sp_float l, sp_int e) {
  sp_frange_check(f, l, 0);
  sp_FloatRange r; r.first = f; r.last = l; r.excl = e; r.omitted = 0; r.unfrozen = 0; return r;
}
/* Same, recording which bound was written as absent rather than infinite. */
sp_FloatRange sp_frange_new_o(sp_float f, sp_float l, sp_int e, sp_int om) {
  sp_frange_check(f, l, om);
  sp_FloatRange r; r.first = f; r.last = l; r.excl = e; r.omitted = om; r.unfrozen = 0; return r;
}
sp_bool sp_frange_cover(sp_FloatRange r, sp_float x) {
  /* a NaN compares with no bound (Float#<=> answers nil), so CRuby's
     cover? finds it in no Range, an endless or beginless one included;
     both tests below are false for it and let it through */
  if (isnan(x)) return 0;
  if (r.first != -HUGE_VAL && x < r.first) return 0;
  if (r.last != HUGE_VAL && (r.excl ? x >= r.last : x > r.last)) return 0;
  return 1;
}
/* ...and an Integer x, compared with the bounds exactly (#7505): converted to
   a double first, an Integer past 2^53 rounded onto a bound */
sp_bool sp_frange_cover_i(sp_FloatRange r, sp_int x) {
  if (r.first != -HUGE_VAL && sp_int_flt_cmp(x, r.first) < 0) return 0;
  if (r.last != HUGE_VAL) {
    int c = sp_int_flt_cmp(x, r.last);
    if (r.excl ? c >= 0 : c > 0) return 0;
  }
  return 1;
}
sp_bool sp_frange_eq(sp_FloatRange a, sp_FloatRange b) {
  return a.first == b.first && a.last == b.last && a.excl == b.excl;
}
const char *sp_frange_inspect(sp_FloatRange r) {
  /* an OMITTED bound prints as nothing; an explicit infinity prints itself */
  const char *lo = (r.omitted & SP_FRANGE_NO_BEGIN) ? ""
                 : (r.omitted & SP_FRANGE_INT_BEGIN) ? sp_sprintf("%lld", (long long)r.first)
                 : sp_float_to_s(r.first);
  /* the begin's text is a new String the end's can collect */
  SP_GC_ROOT_STR(lo);
  const char *hi = (r.omitted & SP_FRANGE_NO_END) ? ""
                 : (r.omitted & SP_FRANGE_INT_END) ? sp_sprintf("%lld", (long long)r.last)
                 : sp_float_to_s(r.last);
  SP_GC_ROOT_STR(hi);
  return sp_sprintf("%s%s%s", lo, r.excl ? "..." : "..", hi);
}
sp_RbVal sp_box_frange(sp_FloatRange v) {
  sp_FloatRange *p = (sp_FloatRange *)sp_gc_alloc(sizeof(sp_FloatRange), NULL, NULL);
  *p = v;
  return sp_box_obj(p, SP_BUILTIN_FLOAT_RANGE);
}
/* Float#max: the exclusive form has no greatest element (Ruby raises). */
sp_float sp_frange_max(sp_FloatRange r) {
  if (r.excl) sp_raise_cls("TypeError", "cannot exclude end value with non Integer begin value");
  return r.last;
}
/* String range ("a".."e"). The endpoints are the value; every traversal
   materializes the element array, which is how a string range behaved before
   it became a value of its own (#3064). A NULL endpoint is a nil bound: the
   range is beginless or endless. */
/* --share-strings (#8321): the Range read with each handle it keeps taken
   as its bytes are now, so a change in place to the endpoint's String
   shows through the Range. A Range without handles is answered as it is.
   An endpoint the Range keeps as a handle holds NULL in its byte field (the
   handle is its only holder, so no stale pointer is ever kept or marked);
   this fills that field with the handle's own bytes, uncopied, for a read
   that compares or formats them and keeps nothing: they are good only
   until the next change to that String. sp_srange_held is the form whose
   endpoints may be kept. */
sp_StrRange sp_srange_live(sp_StrRange r) {
  if (r.hf) r.first = sp_String_cstr((sp_String *)r.hf);
  if (r.hl) r.last = sp_String_cstr((sp_String *)r.hl);
  return r;
}
/* ...the Range with each kept endpoint read as a String of its own (a
   copy of the handle's bytes): for an answer that may keep an endpoint, an
   element of #to_a or the String #min / #max answer. */
static sp_StrRange sp_srange_held(sp_StrRange r) {
  sp_String *hf = (sp_String *)r.hf, *hl = (sp_String *)r.hl;
  SP_GC_ROOT(hf); SP_GC_ROOT(hl);
  if (hf) r.first = sp_str_from_bytes(sp_String_cstr(hf), (size_t)sp_String_length(hf));
  const char *f = r.first;
  SP_GC_ROOT_STR(f);
  if (hl) r.last = sp_str_from_bytes(sp_String_cstr(hl), (size_t)sp_String_length(hl));
  return r;
}
sp_StrRange sp_srange_new(const char *f, const char *l, sp_int e) {
  sp_StrRange r; r.first = f; r.last = l; r.excl = e; r.unfrozen = 0; r.sym = 0; r.hf = NULL; r.hl = NULL; return r;
}
sp_StrArray *sp_srange_to_a(sp_StrRange r) {
  r = sp_srange_held(r);
  SP_GC_ROOT_SRANGE(r);
  if (!r.first) sp_raise_cls("TypeError", "can't iterate from NilClass");
  if (!r.last) sp_raise_cls("RangeError", "cannot convert endless range to an array");
  return sp_StrArray_from_string_range(r.first, r.last, r.excl);
}
/* Range#first(n) and Range#take(n) on a String Range: the first n members,
   walked by succ and stopped at n, so an endless range (last NULL) answers
   without being converted to an array. first of a beginless range is the
   RangeError CRuby names; take, which iterates, the TypeError of the walk. */
typedef struct { sp_StrArray *a; sp_int n; } sp_srange_take_st;
static int sp_srange_take_push(const char *m, void *arg) {
  sp_srange_take_st *st = (sp_srange_take_st *)arg;
  sp_StrArray_push(st->a, m);
  return st->a->len >= st->n;
}
sp_StrArray *sp_srange_first_n(sp_RbVal box, sp_int n, int take) {
  SP_GC_ROOT_RBVAL(box);
  sp_StrRange r = sp_srange_live(*(sp_StrRange *)box.v.p);
  const char *cur = r.first, *last = r.last;
  SP_GC_ROOT_STR(cur); SP_GC_ROOT_STR(last);
  if (n < 0) sp_raise_cls("ArgumentError", take ? "attempt to take negative size" : "negative array size (or size too big)");
  if (!cur) {
    if (take) sp_raise_cls("TypeError", "can't iterate from NilClass");
    sp_raise_cls("RangeError", "cannot get the first element of beginless range");
  }
  sp_StrArray *a = sp_StrArray_new();
  SP_GC_ROOT(a);
  if (n == 0) return a;
  if (last) {
    sp_srange_take_st st = { a, n };
    sp_str_upto_each(cur, last, r.excl, sp_srange_take_push, &st);
    return a;
  }
  for (; a->len < n; cur = sp_str_succ(cur)) sp_StrArray_push(a, sp_str_from_bytes(cur, sp_str_byte_len(cur)));
  return a;
}
sp_bool sp_srange_eq(sp_StrRange a, sp_StrRange b) {
  a = sp_srange_live(a); b = sp_srange_live(b);
  return a.excl == b.excl && a.sym == b.sym && sp_str_eq(a.first, b.first) && sp_str_eq(a.last, b.last);
}
/* #include? / #member?: whether the walk String#upto takes meets x, as
   CRuby's rb_str_include_range_p, stopping at the first equal member;
   CRuby refuses to answer for a beginless or endless range. */
static int sp_srange_include_i(const char *m, void *arg) {
  const char **v = (const char **)arg;
  if (!sp_str_eq(m, *v)) return 0;
  *v = NULL;
  return 1;
}
sp_bool sp_srange_include(sp_StrRange r, const char *x) {
  r = sp_srange_live(r);
  SP_GC_ROOT_SRANGE(r);
  if (!r.first || !r.last)
    sp_raise_cls("TypeError", "cannot determine inclusion in beginless/endless ranges");
  if (!x) return 0;
  const char *v = x;
  SP_GC_ROOT_STR(v);
  sp_str_upto_each(r.first, r.last, r.excl, sp_srange_include_i, &v);
  return v == NULL;
}
/* #cover? / #=== compare lexicographically, no materialization. */
sp_bool sp_srange_cover(sp_StrRange r, const char *x) {
  r = sp_srange_live(r);
  if (!x) return 0;
  if (r.first && strcmp(x, r.first) < 0) return 0;
  if (r.last) { int d = strcmp(x, r.last); if (r.excl ? d >= 0 : d > 0) return 0; }
  return 1;
}
/* #min / #max with no block, as CRuby's range_min / range_max: an open
   side raises, an empty range (the begin past the end, or at it with the
   end excluded) is nil, and an excluded end walks the members for the
   least or greatest, since a String end cannot be stepped back from. NULL
   is nil. */
static const char *sp_srange_walk_extreme(sp_StrRange r, int greatest) {
  sp_StrArray *a = sp_srange_to_a(r); SP_GC_ROOT(a);
  const char *best = NULL; SP_GC_ROOT_STR(best);
  for (sp_int i = 0; i < sp_StrArray_length(a); i++) {
    const char *s = sp_StrArray_get(a, i);
    if (!best || (greatest ? strcmp(s, best) > 0 : strcmp(s, best) < 0)) best = s;
  }
  return best;
}
const char *sp_srange_min_v(sp_StrRange r) {
  r = sp_srange_held(r);
  if (!r.first) sp_raise_cls("RangeError", "cannot get the minimum of beginless range");
  if (r.excl) {
    if (!r.last) sp_raise_cls("RangeError", "cannot get the minimum of endless range with custom comparison method");
    return sp_srange_walk_extreme(r, 0);
  }
  if (r.last && strcmp(r.first, r.last) > 0) return NULL;
  return r.first;
}
const char *sp_srange_max_v(sp_StrRange r) {
  r = sp_srange_held(r);
  if (!r.last) sp_raise_cls("RangeError", "cannot get the maximum of endless range");
  if (r.excl) {
    if (!r.first) sp_raise_cls("RangeError", "cannot get the maximum of beginless range with custom comparison method");
    return sp_srange_walk_extreme(r, 1);
  }
  if (r.first && strcmp(r.first, r.last) > 0) return NULL;
  return r.last;
}
const char *sp_srange_to_s(sp_StrRange r) {
  r = sp_srange_live(r);
  SP_GC_ROOT_SRANGE(r);
  return sp_sprintf("%s%s%s", r.first ? r.first : sp_str_empty,
                    r.excl ? "..." : "..", r.last ? r.last : sp_str_empty);
}
/* The begin's inspect is a new String the end's inspect can collect, and
   the caller's range is a by-value pair nothing may root (#8322): both
   ends and the first answer are held here. */
const char *sp_srange_inspect(sp_StrRange r) {
  r = sp_srange_live(r);
  SP_GC_ROOT(r.hf); SP_GC_ROOT(r.hl);
  const char *f = r.first, *l = r.last;
  SP_GC_ROOT_STR(f); SP_GC_ROOT_STR(l);
  /* a Range of Symbols shows its ends as Symbols (:a..:c) */
  const char *(*show)(const char *) = r.sym ? sp_sym_inspect_name : sp_str_inspect;
  const char *lo = f ? show(f) : sp_str_empty;
  SP_GC_ROOT_STR(lo);
  const char *hi = l ? show(l) : sp_str_empty;
  SP_GC_ROOT_STR(hi);
  return sp_sprintf("%s%s%s", lo, r.excl ? "..." : "..", hi);
}
/* A boxed String range holds its two endpoint strings: the box marks them,
   and they are rooted while it is allocated. With no scanner the endpoints
   were swept under a live range, and a `("a1".."z1")` read back as
   `"".."t1"` once a collection had reused them (kw_splat_struct_data_arg_order
   on the 32-bit target). */
static void sp_srange_scan(void *p) {
  sp_StrRange *r = (sp_StrRange *)p;
  if (r->first) sp_mark_string(r->first);
  if (r->last) sp_mark_string(r->last);
  if (r->hf) sp_gc_mark(r->hf);
  if (r->hl) sp_gc_mark(r->hl);
}
sp_RbVal sp_box_srange(sp_StrRange v) {
  const char *f = v.first, *l = v.last;
  void *hf = v.hf, *hl = v.hl;
  SP_GC_ROOT_STR(f); SP_GC_ROOT_STR(l); SP_GC_ROOT(hf); SP_GC_ROOT(hl);
  sp_StrRange *p = (sp_StrRange *)sp_gc_alloc(sizeof(sp_StrRange), NULL, sp_srange_scan);
  *p = v;
  return sp_box_obj(p, SP_BUILTIN_STR_RANGE);
}

/* An endless String Range (last NULL) walked as it is read: String#succ from
   the begin, stepping `step` successors at a time, one fresh String per value,
   through the fiber-generator path (the String Range's mirror of
   sp_endless_range_gen), so #next, #first(n) and a lazy chain over it need no
   member Array, which an endless range cannot make. The capture holds the
   begin, which its scan marks. */
typedef struct { const char *first; sp_int step; } sp_endless_srange_cap;
static void sp_endless_srange_cap_scan(void *p) {
  sp_endless_srange_cap *cap = (sp_endless_srange_cap *)p;
  if (cap->first) sp_mark_string(cap->first);
}
static void sp_endless_srange_gen(sp_Fiber *f) {
  sp_endless_srange_cap *cap = (sp_endless_srange_cap *)f->user_data;
  const char *cur = cap->first;
  SP_GC_ROOT_STR(cur);
  for (;;) {
    sp_Fiber_yield(sp_box_str(sp_str_from_bytes(cur, sp_str_byte_len(cur))));
    cur = sp_str_succ_n(cur, cap->step);
  }
}
/* The Enumerator over the boxed endless String Range `box`, stepping `step`
   members at a time; it reports `box` as its source. */
sp_Enumerator *sp_srange_endless_enum(sp_RbVal box, sp_int step) {
  SP_GC_ROOT_RBVAL(box);
  /* the begin as it is now (a copy, under --share-strings: the walk outlives
     the handle's bytes) is held across the capture's allocation */
  const char *first = sp_srange_held(*(sp_StrRange *)box.v.p).first;
  SP_GC_ROOT_STR(first);
  if (!first) sp_raise_cls("TypeError", "can't iterate from NilClass");
  sp_endless_srange_cap *cap = (sp_endless_srange_cap *)sp_gc_alloc(sizeof *cap, NULL, sp_endless_srange_cap_scan);
  SP_GC_ROOT(cap);
  cap->first = first; cap->step = step;
  sp_Enumerator *e = sp_Enumerator_new_gen(sp_endless_srange_gen, cap, sp_box_nil());
  e->source = box; e->has_src = TRUE;   /* it inspects as the Range's own */
  e->size_nil = TRUE;   /* and has no size, as a String Range's own is nil */
  return e;
}
/* Range#step(n) and Range#%(n) on a String Range without a block: an
   Enumerator over every n-th member. A bounded range's stepped members are
   materialized; an endless one's follow by succ (sp_srange_endless_enum).
   `label` is the name the Enumerator inspects with ("step" or "%"). The Range
   is boxed first and held, for the Enumerator to report as its source. */
sp_Enumerator *sp_srange_stepped_enum(sp_RbVal src, sp_int n, const char *label) {
  SP_GC_ROOT_STR(label);
  SP_GC_ROOT_RBVAL(src);
  sp_StrRange r = sp_srange_held(*(sp_StrRange *)src.v.p);
  SP_GC_ROOT_STR(r.first); SP_GC_ROOT_STR(r.last);
  if (n <= 0 && r.last) {
    sp_srange_to_a(r);   /* a beginless range raises its TypeError first */
    sp_raise_cls("ArgumentError", "step can't be 0");
  }
  sp_Enumerator *e;
  if (r.last) {
    sp_StrArray *all = sp_srange_to_a(r);
    SP_GC_ROOT(all);
    sp_StrArray *v = sp_StrArray_new();
    SP_GC_ROOT(v);
    for (sp_int i = 0; i < sp_StrArray_length(all); i += n) sp_StrArray_push(v, sp_StrArray_get(all, i));
    e = sp_Enumerator_new_from_items(sp_StrArray_to_poly_fmt(v));
  }
  else {
    if (n <= 0) sp_raise_cls("ArgumentError", "step can't be 0");
    e = sp_srange_endless_enum(src, n);
  }
  SP_GC_ROOT(e);
  return sp_enum_with_src(e, src, sp_sprintf("%s(%lld)", label, (long long)n));
}

/* ---- Float leaf ops (opt_inspect/opt_to_s/denominator/numerator/
   to_i_checked) -- relocated from spinel_rt.h. 0 optcarrot uses; reach
   only lib-visible sp_float_to_s (sp_alloc.h)/
   sp_float_to_rational (sp_format.h)/sp_raise_cls/sp_sprintf. ---- */

/* float? (nullable float) counterparts: a non-nil value formats exactly
   like a plain Float (delegates to sp_float_to_s), nil renders "nil"
   (inspect) / "" (to_s). */
const char *sp_float_opt_inspect(sp_ofloat v) { return v.nil ? "nil" : sp_float_to_s(v.v); }
const char *sp_float_opt_to_s(sp_ofloat v)    { return v.nil ? "" : sp_float_to_s(v.v); }
/* Float#numerator / #denominator. A non-finite Float has no rational form, so
   CRuby answers the value itself and 1 rather than converting (#3011). */
sp_int sp_float_denominator(sp_float f) {
  if (isnan(f) || isinf(f)) return 1;
  return sp_float_to_rational(f).den;
}
sp_RbVal sp_float_numerator(sp_float f) {
  if (isnan(f) || isinf(f)) return sp_box_float(f);
  return sp_box_int(sp_float_to_rational(f).num);
}
/* Float#to_i whose integer value escapes int64: CRuby promotes to Bignum;
   until the promotion plan covers statically-int results (#2024), raise
   loudly instead of saturating silently. NaN/Inf raise FloatDomainError. */
sp_int sp_float_to_i_checked_slow(sp_float f) {
  if (isnan(f) || isinf(f)) sp_raise_cls("FloatDomainError", isnan(f) ? "NaN" : f > 0 ? "Infinity" : "-Infinity");
  if (f >= -(sp_float)INTPTR_MIN || f < (sp_float)INTPTR_MIN)  /* exact at either sp_int width */
    sp_raise_cls("RangeError", "float out of Integer range (Bignum promotion pending)");
  return (sp_int)f;
}

void sp_float_arg_range_error(sp_float f) {
  if (!isfinite(f))
    sp_raise_cls("RangeError", sp_sprintf("float %s out of range of integer",
                 isnan(f) ? "NaN" : f > 0 ? "Inf" : "-Inf"));
  sp_raise_cls("RangeError", sp_sprintf("float %.10g out of range of integer", f));
}

/* ---- Box helpers (0 optcarrot uses) -- relocated from spinel_rt.h. ---- */

/* box a sp_Bigint* into a poly slot (heterogeneous container element, or a
   promote-mode overflow result). */
extern int sp_bigint_mag_u64(sp_Bigint *b, uint64_t *out);   /* 1 iff |b| < 2^64 */
/* Ruby has ONE Integer: a value small enough for the inline representation
   IS the inline one, whoever computed it. Every bigint operation used to box
   its result as a Bignum whatever its size, so `big & 0xffff_ffff`, and
   equally `big * 0` and `big - (big - 7)`, answered a Bignum holding 0, 7 or
   a 32-bit mask -- right when printed or compared, and refused by every
   consumer that decides on the tag: IO::Buffer's u32 lane called such a
   value "bignum too big to convert into 'unsigned int'" (#4594). Normalize
   on the way into the poly slot, the same range test sp_box_i64 makes, so
   the tag says what the value is. INTPTR_MIN stays a Bignum: the inline
   representation spells it nil. */
sp_RbVal sp_box_bigint(sp_Bigint *b) {
  uint64_t mag;
  if (b && sp_bigint_mag_u64(b, &mag) && mag <= (uint64_t)INTPTR_MAX) {
    sp_int v = (sp_int)mag;
    return sp_box_int(sp_bigint_sign(b) < 0 ? -v : v);
  }
  sp_RbVal r; r.tag = SP_TAG_BIGINT; r.cls_id = 0; r.v.p = b; return r;
}
int64_t sp_unbox_i64(sp_RbVal v) {
  if (v.tag == SP_TAG_INT) return (int64_t)v.v.i;
  if (v.tag == SP_TAG_BIGINT) return sp_bigint_to_int((sp_Bigint *)v.v.p);
  if (v.tag == SP_TAG_FLT) return (int64_t)v.v.f;
  return 0;
}
sp_RbVal sp_box_i64(int64_t v) {
  if (v >= (int64_t)INTPTR_MIN && v <= (int64_t)INTPTR_MAX) return sp_box_int((sp_int)v);
  return sp_box_bigint(sp_bigint_new_int(v));
}
sp_RbVal sp_box_encoding(sp_Encoding e) { sp_RbVal r; r.tag = SP_TAG_ENCODING; r.cls_id = 0; r.v.s = sp_encoding_name(e); return r; }
/* Encoding.find(name) with a name known at run time: an Encoding answers
   itself, a name or alias the encoding it names (case-insensitively, as
   CRuby), "external" / "locale" / "filesystem" UTF-8 and "internal" nil;
   anything else is CRuby's ArgumentError. */
static const char *const sp_encoding_names[][2] = {
#include "sp_encoding_names.h"
  { NULL, NULL } };
sp_RbVal sp_encoding_find(sp_RbVal v) {
  if (v.tag == SP_TAG_ENCODING) return v;
  if (v.tag != SP_TAG_STR) {
    const char *cn = v.tag == SP_TAG_NIL ? "nil" : v.tag == SP_TAG_INT ? "Integer"
                   : v.tag == SP_TAG_FLT ? "Float" : v.tag == SP_TAG_SYM ? "Symbol"
                   : v.tag == SP_TAG_BOOL ? (v.v.b ? "true" : "false") : "Object";
    sp_raise_cls("TypeError", sp_sprintf("no implicit conversion of %s into String", cn));
  }
  const char *n = v.v.s;
  if (!strcasecmp(n, "external") || !strcasecmp(n, "locale") || !strcasecmp(n, "filesystem"))
    return sp_box_encoding((sp_Encoding){ "UTF-8" });
  if (!strcasecmp(n, "internal")) return sp_box_nil();
  for (int i = 0; sp_encoding_names[i][0]; i++)
    if (!strcasecmp(n, sp_encoding_names[i][0])) return sp_box_encoding((sp_Encoding){ sp_encoding_names[i][1] });
  sp_raise_cls("ArgumentError", sp_sprintf("unknown encoding name - %s", n));
  return sp_box_nil();
}
/* Encoding.list: an Encoding for every name it may answer, in CRuby's order */
static const char *const sp_encoding_list_names[] = {
#include "sp_encoding_list.h"
  NULL };
sp_PolyArray *sp_encoding_list(void) {
  sp_PolyArray *a = sp_PolyArray_new();
  SP_GC_ROOT(a);
  for (int i = 0; sp_encoding_list_names[i]; i++)
    sp_PolyArray_push(a, sp_box_encoding((sp_Encoding){ sp_encoding_list_names[i] }));
  return a;
}
/* force_encoding with an Encoding or a name known only at run time: 1 for
   ASCII-8BIT, 0 for UTF-8 or US-ASCII, -1 for an encoding spinel has no tag
   for. A bad argument raises as CRuby's does. */
int sp_force_encoding_mode(sp_RbVal enc) {
  sp_RbVal e = sp_encoding_find(enc);
  const char *n = e.tag == SP_TAG_ENCODING ? e.v.s : NULL;
  if (!n) return -1;
  if (!strcmp(n, "ASCII-8BIT")) return 1;
  if (!strcmp(n, "UTF-8") || !strcmp(n, "US-ASCII")) return 0;
  return -1;
}
/* The encoding a set_encoding argument names, of the two a String can
   have: 1 UTF-8 (US-ASCII is UTF-8 here, and so is nil, the default
   external), 2 ASCII-8BIT, -1 another encoding, -2 a "BOM|" one, 0 a name
   no encoding has. `*nm` is the name. */
static int sp_io_enc_side(sp_RbVal v, const char *s, const char **nm) {
  const char *n = NULL;
  if (s) {
    if (!strncasecmp(s, "BOM|", 4)) { *nm = s; return -2; }
    if (!strcasecmp(s, "external") || !strcasecmp(s, "locale") || !strcasecmp(s, "filesystem")) n = "UTF-8";
    for (int i = 0; !n && sp_encoding_names[i][0]; i++)
      if (!strcasecmp(s, sp_encoding_names[i][0])) n = sp_encoding_names[i][1];
    if (!n) { *nm = s; return 0; }
  }
  else if (v.tag == SP_TAG_NIL) n = "UTF-8";
  else if (v.tag == SP_TAG_STR) return sp_io_enc_side(v, v.v.s, nm);
  else n = sp_encoding_find(v).v.s;   /* an Encoding, or CRuby's TypeError */
  *nm = n;
  if (!strcmp(n, "ASCII-8BIT")) return 2;
  return !strcmp(n, "UTF-8") || !strcmp(n, "US-ASCII") ? 1 : -1;
}
/* IO#set_encoding(ext [, int]), or "ext:int". The external encoding is the
   one a read with no length and getc answer (sp_File_reads_binary); a write
   puts out the String's bytes as they are, which is CRuby's write too
   unless the encoding is a third one. So UTF-8, US-ASCII and ASCII-8BIT
   work, and an internal encoding that asks for no conversion: nil, the
   external one, or any under ASCII-8BIT, which CRuby ignores. A third
   encoding, a conversion or a "BOM|" one is NotImplementedError: spinel has
   no third encoding to tag a read with or to transcode a write into, and
   does not strip a byte order mark. A name no encoding has is CRuby's
   warning, and stands for none, as in CRuby: an external one is then the
   default (UTF-8), or the internal one passed beside it, read as it is. */
sp_File *sp_File_set_encoding(sp_File *f, sp_RbVal ext, sp_RbVal in) {
  SP_GC_ROOT(f); SP_GC_ROOT_RBVAL(ext); SP_GC_ROOT_RBVAL(in);
  SP_IO_OPEN(f);
  char eb[64];
  const char *es = NULL, *is = NULL, *en, *inn;
  if (ext.tag == SP_TAG_STR && in.tag == SP_TAG_NIL && strchr(ext.v.s, ':')) {
    const char *colon = strchr(ext.v.s, ':');
    snprintf(eb, sizeof eb, "%.*s", (int)(colon - ext.v.s), ext.v.s);
    es = eb; is = colon + 1;
  }
  int e = sp_io_enc_side(ext, es, &en);
  if (e == 0 && !es && in.tag != SP_TAG_NIL) {
    fprintf(stderr, "warning: Unsupported encoding %s ignored\n", en);
    ext = in; in = sp_box_nil();
    e = sp_io_enc_side(ext, NULL, &en);
  }
  if (e == 0) { fprintf(stderr, "warning: Unsupported encoding %s ignored\n", en); e = 1; en = "UTF-8"; }
  if (e == -2)
    sp_raise_cls("NotImplementedError", sp_sprintf("IO#set_encoding to %s: spinel does not strip a byte order mark", en));
  if (e < 0)
    sp_raise_cls("NotImplementedError", sp_sprintf("IO#set_encoding to %s: spinel's Strings are UTF-8 or ASCII-8BIT", en));
  if (is || in.tag != SP_TAG_NIL) {
    int i = sp_io_enc_side(in, is, &inn);
    if (i == 0) fprintf(stderr, "warning: Unsupported encoding %s ignored\n", inn);
    else if (e != 2 && strcmp(inn, en))
      sp_raise_cls("NotImplementedError", sp_sprintf("IO#set_encoding converting reads from %s to %s: spinel does not transcode", en, inn));
  }
  f->ext_enc = (unsigned char)e;
  return f;
}
sp_RbVal sp_box_nullable_str(const char *v) { return v ? sp_box_str(v) : sp_box_nil(); }
/* An opaque foreign/FFI pointer: boxed with SP_BUILTIN_FOREIGN_PTR so the
   collector skips it (it is not a sp_gc_alloc allocation). NULL -> nil. */
sp_RbVal sp_box_foreign_ptr(void *p) { return p ? sp_box_obj(p, SP_BUILTIN_FOREIGN_PTR) : sp_box_nil(); }
/* a compiled Regexp value (mrb_regexp_pattern *): untraced, program-lifetime */
sp_RbVal sp_box_regexp(void *p) { return p ? sp_box_obj(p, SP_BUILTIN_REGEX) : sp_box_nil(); }
sp_RbVal sp_box_sym_array(void *p)   { return sp_box_obj(p, SP_BUILTIN_SYM_ARRAY); }
sp_RbVal sp_box_ptr_array(void *p)   { return sp_box_obj(p, SP_BUILTIN_PTR_ARRAY); }
sp_RbVal sp_box_method(void *p)      { return sp_box_obj(p, SP_BUILTIN_METHOD); }
/* Complex / Rational are wider value types (two components); like sp_Range they
   heap-copy when crossing into a poly slot. No internal pointers, so no scan. */
sp_RbVal sp_box_complex(sp_Complex v) {
  sp_Complex *p = (sp_Complex *)sp_gc_alloc(sizeof(sp_Complex), NULL, NULL);
  *p = v;
  return sp_box_obj(p, SP_BUILTIN_COMPLEX);
}
sp_RbVal sp_box_rational(sp_Rational v) {
  sp_Rational *p = (sp_Rational *)sp_gc_alloc(sizeof(sp_Rational), NULL, NULL);
  *p = v;
  return sp_box_obj(p, SP_BUILTIN_RATIONAL);
}
/* Same heap-box rationale as sp_Range: sp_Time is 12+ bytes (tv_sec +
   tv_nsec), wider than sp_RbVal's 8-byte union. No internal pointers
   so no scanner is needed. */
sp_RbVal sp_box_time(sp_Time v) {
  sp_Time *p = (sp_Time *)sp_gc_alloc(sizeof(sp_Time), NULL, NULL);
  *p = v;
  return sp_box_obj(p, SP_BUILTIN_TIME);
}
/* Boxing for the unboxed sp_Tms value (a rescue expression merges it into a
   nullable slot, #3132): heap-copy like sp_box_frange. */
sp_RbVal sp_box_tms(sp_Tms v) {
  sp_Tms *p = (sp_Tms *)sp_gc_alloc(sizeof(sp_Tms), NULL, NULL);
  *p = v;
  return sp_box_obj(p, SP_BUILTIN_TMS);
}
sp_RbVal sp_box_openstruct(sp_OpenStruct *o){ return sp_box_obj(o, SP_BUILTIN_OPENSTRUCT); }

/* ---- More cold String/StrArray ops -- relocated from spinel_rt.h. ---- */
#include "sp_re.h"   /* mrb_regexp_pattern/spinel_re_exec for sp_str_re_match_p_at */

/* respond_to? on a poly value that turns out to hold a BUILTIN. The compile
   time fold emits a cls_id check against the user classes defining the name,
   which necessarily answers false for a builtin member of the union -- yet
   Array really does respond to :each. Answer the core builtin surface here,
   keyed off the runtime class name so every Array variant shares one list.
   Deliberately conservative: an unlisted name answers false rather than
   guessing, which is also what an undispatchable method would do. */
sp_bool sp_str_in_list(const char *m, const char *const *list) {
  for (int i = 0; list[i]; i++) if (strcmp(m, list[i]) == 0) return 1;
  return 0;
}
/* String#index / #rindex return a boxed nil for not-found, boxed
   int for found. Issue #532: typed-int slot can't represent CRuby's
   nil-vs-real-index distinction in-band; widening the result type
   to sp_RbVal at the call site lets `pos.nil?` and `puts pos.inspect`
   work via the standard poly-tag dispatch. The -1 sentinel comes
   from the underlying sp_str_*_index helpers; we widen here at the
   boxing layer so existing call sites that want the raw int still
   work via `sp_str_index` directly. */
sp_RbVal sp_str_index_poly(const char *s, const char *sub) {SP_GC_ROOT_STR(s);SP_GC_ROOT_STR(sub); sp_int n = sp_str_index(s, sub); return n < 0 ? sp_box_nil() : sp_box_int(n); }
sp_RbVal sp_str_index_from_poly(const char *s, const char *sub, sp_int start) {SP_GC_ROOT_STR(s);SP_GC_ROOT_STR(sub); sp_int n = sp_str_index_from(s, sub, start); return n < 0 ? sp_box_nil() : sp_box_int(n); }
sp_RbVal sp_str_rindex_poly(const char *s, const char *sub) {SP_GC_ROOT_STR(s);SP_GC_ROOT_STR(sub); sp_int n = sp_str_rindex(s, sub); return n < 0 ? sp_box_nil() : sp_box_int(n); }
sp_PolyArray *sp_str_lines_poly(const char *s) {SP_GC_ROOT_STR(s);
  sp_StrArray *ls = sp_str_lines(s); SP_GC_ROOT(ls);
  sp_PolyArray *a = sp_PolyArray_new(); SP_GC_ROOT(a);
  if (ls) {
    sp_int len = sp_StrArray_length(ls);
    for (sp_int i = 0; i < len; i++) {
      sp_PolyArray_push(a, sp_box_str(sp_StrArray_get(ls, i)));
    }
  }
  return a;
}
/* String#match?(/re/, pos) -- pos is a codepoint index (CRuby semantics),
   unlike Regexp#match?(str, pos) which uses byte offset. Convert the
   codepoint index to a byte offset before dispatching to spinel_re_exec. */
sp_bool sp_str_re_match_p_at(mrb_regexp_pattern *pat, const char *str, sp_int cpos) {SP_GC_ROOT_STR(str);
  sp_int cl = sp_str_length(str);
  if (cpos < 0) cpos += cl;
  if (cpos < 0 || cpos > cl) return FALSE;
  size_t boff = sp_utf8_byte_offset(str, cpos);
  /* the subject's own length and mode, as sp_re_match_p reads them: strlen
     stopped at an embedded NUL, and a binary subject matched as UTF-8 */
  int64_t slen = (int64_t)sp_str_byte_len(str);
  int caps[2];
  return spinel_re_exec(pat, str, slen, (sp_int)boff, caps, 2, sp_str_is_binary(str)) > 0;
}
/* Issue #910: sub(string, hash) -- literal-substring pattern
   with a hash replacement. Replaces only the first match. */
const char *sp_str_sub_str_str_hash(const char *str, const char *pat, sp_StrStrHash *h) {SP_GC_ROOT_STR(pat);SP_GC_ROOT(h);SP_GC_ROOT_STR(str);
  if (!str || !pat) return str;
  size_t slen = sp_str_byte_len(str), plen = sp_str_byte_len(pat);
  const char *found = sp_bytestr(str, slen, pat, plen);
  if (!found) { if (sp_re_track_last) sp_re_clear_last_match(); return str; }
  size_t before = (size_t)(found - str);
  if (sp_re_track_last) sp_re_set_lit_match(str, (sp_int)before, (sp_int)(before + plen));
  const char *rep = (h && sp_StrStrHash_has_key(h, pat)) ? sp_StrStrHash_get(h, pat) : &("\xff" "")[1];
  size_t rlen = sp_str_byte_len(rep);
  size_t rest = slen - before - plen;
  size_t total = before + rlen + rest;
  char *out = sp_str_alloc_raw(total + 1);
  memcpy(out, str, before);
  memcpy(out + before, rep, rlen);
  memcpy(out + before + rlen, found + plen, rest);
  out[total] = 0;
  sp_str_set_len(out, total);
  return out;
}
/* gsub(string, hash): every occurrence of the literal pattern replaced by
   the hash's value for it ("" when absent or nil), $~ the last occurrence.
   An empty pattern matches at every character boundary -- every byte of a
   binary String -- as CRuby's does. */
const char *sp_str_gsub_str_str_hash(const char *str, const char *pat, sp_StrStrHash *h) {SP_GC_ROOT_STR(pat);SP_GC_ROOT(h);SP_GC_ROOT_STR(str);
  if (!str || !pat) return str;
  size_t slen = sp_str_byte_len(str), plen = sp_str_byte_len(pat);
  const char *rep = (h && sp_StrStrHash_has_key(h, pat)) ? sp_StrStrHash_get(h, pat) : &("\xff" "")[1];
  if (!rep) rep = &("\xff" "")[1];
  SP_GC_ROOT_STR(rep);
  size_t rlen = sp_str_byte_len(rep), n = 0;
  int bin = sp_str_is_binary(str);
  if (plen == 0) { for (size_t i = 0; i < slen; i++) if (bin || ((unsigned char)str[i] & 0xC0) != 0x80) n++; n++; }
  else for (const char *q = sp_bytestr(str, slen, pat, plen); q; q = sp_bytestr(q + plen, slen - (size_t)(q + plen - str), pat, plen)) n++;
  if (n == 0) { if (sp_re_track_last) sp_re_clear_last_match(); return str; }
  size_t total = slen + n * rlen - (plen ? n * plen : 0);
  char *out = sp_str_alloc_raw(total + 1);
  /* the answer is held across `$~`'s allocations at the end */
  SP_GC_ROOT_STR(out);
  size_t o = 0, last = 0;
  if (plen == 0) {
    for (size_t i = 0; i < slen; i++) {
      if (bin || ((unsigned char)str[i] & 0xC0) != 0x80) { memcpy(out + o, rep, rlen); o += rlen; last = i; }
      out[o++] = str[i];
    }
    memcpy(out + o, rep, rlen); o += rlen; last = slen;
  }
  else {
    const char *p = str;
    for (const char *q = sp_bytestr(p, slen, pat, plen); q; q = sp_bytestr(p, slen - (size_t)(p - str), pat, plen)) {
      memcpy(out + o, p, (size_t)(q - p)); o += (size_t)(q - p);
      memcpy(out + o, rep, rlen); o += rlen;
      last = (size_t)(q - str);
      p = q + plen;
    }
    memcpy(out + o, p, slen - (size_t)(p - str)); o += slen - (size_t)(p - str);
  }
  out[o] = 0;
  sp_str_set_len(out, o);
  if (sp_re_track_last) sp_re_set_lit_match(str, (sp_int)last, (sp_int)(last + plen));
  return out;
}
/* Array#sum with a String initial value: concatenation fold ("abc" from
   ["a","b","c"].sum("")), CRuby's + on each element. */
const char *sp_StrArray_sum_str(sp_StrArray *a, const char *init) {SP_GC_ROOT(a);SP_GC_ROOT_STR(init);
  size_t n = init ? sp_str_byte_len(init) : 0;
  if (a) for (sp_int i = 0; i < a->len; i++) if (a->data[i]) {
    size_t len = sp_str_byte_len(a->data[i]);
    if (len > SIZE_MAX - n) sp_oom_die();
    n += len;
  }
  char *r = sp_str_alloc(n); size_t o = 0;
  if (init) { o = sp_str_byte_len(init); memcpy(r, init, o); }
  if (a) for (sp_int i = 0; i < a->len; i++) if (a->data[i]) { size_t l = sp_str_byte_len(a->data[i]); memcpy(r + o, a->data[i], l); o += l; }
  r[o] = 0; sp_str_set_len(r, o); return r;
}
sp_RbVal sp_StrArray_uniq_bangq(sp_StrArray *a) {SP_GC_ROOT(a);
  if (!a) return sp_box_nil();
  sp_int n = a->len;
  sp_StrArray_uniq_bang(a);
  return a->len != n ? sp_box_str_array(a) : sp_box_nil();
}
/* Array#join for float arrays -- each element via the Ruby-faithful
   sp_float_to_s ("1.0", not "1"). Mirrors sp_IntArray_join exactly: build in a
   malloc buffer, return an sp_str_alloc'd copy. (Not sp_String#data, whose owner
   isn't GC-rooted across the return.) sp_float_to_s's result is copied
   immediately, before the next call can reuse its buffer. */
sp_bool sp_StrArray_eq(sp_StrArray*a,sp_StrArray*b){SP_GC_ROOT(a);SP_GC_ROOT(b);if(!a||!b)return a==b;if(a->len!=b->len)return FALSE;for(sp_int i=0;i<a->len;i++)if(!sp_str_eq(a->data[i],b->data[i]))return FALSE;return TRUE;}

/* ---- Complex ops / class-frozen bitmap -- relocated from spinel_rt.h. ---- */

/* An Integer-classed (fl bit clear) whole component boxes as an Integer;
   anything else keeps the Float class. The INTPTR guard mirrors
   sp_complex_mag: casting an out-of-range double to sp_int is UB. */
sp_RbVal sp_complex_comp_v(sp_float v, int is_f) {
  if (!is_f && v >= -(sp_float)INTPTR_MAX && v <= (sp_float)INTPTR_MAX && v == (sp_float)(sp_int)v)
    return sp_box_int((sp_int)v);
  return sp_box_float(v);
}
/* CRuby Complex#abs: Integer only via the zero-component shortcut (|other|)
   on an all-Integer complex; hypot is always a Float. #abs2 is Integer iff
   both components are Integer-classed. */
sp_RbVal sp_complex_abs_v(sp_Complex a) {
  if (a.fl == 0 && a.im == 0) return sp_complex_comp_v(a.re < 0 ? -a.re : a.re, 0);
  if (a.fl == 0 && a.re == 0) return sp_complex_comp_v(a.im < 0 ? -a.im : a.im, 0);
  return sp_box_float(sp_complex_abs(a));
}
sp_RbVal sp_complex_abs2_v(sp_Complex a) {
  sp_float v = sp_complex_abs2(a);
  if (a.fl == 0) return sp_complex_comp_v(v, 0);
  return sp_box_float(v);
}
unsigned char sp_class_frozen_map[4096];
void sp_class_freeze_id(sp_int cls_id) {
  sp_int ix = cls_id >= 0 ? cls_id : (3900 - cls_id);
  if (ix >= 0 && ix < 4096) sp_class_frozen_map[ix] = 1;
}
sp_bool sp_class_frozen_id(sp_int cls_id) {
  sp_int ix = cls_id >= 0 ? cls_id : (3900 - cls_id);
  return (ix >= 0 && ix < 4096) ? (sp_bool)sp_class_frozen_map[ix] : 0;
}

/* ---- Round helpers / typed-array frozen-check / IO.pipe / sysopen --
   relocated from spinel_rt.h. ---- */

/* Float#round(half:) tie-breaking: :even is banker's rounding (rint under
   the default FE_TONEAREST), :down rounds ties toward zero. (:up is the
   plain round().) */
double sp_round_half_even(double x) { return rint(x); }
double sp_round_half_down(double x) { return x >= 0 ? ceil(x - 0.5) : floor(x + 0.5); }
/* Frozen flag of a builtin array, matching what sp_*Array_splice check (the
   struct field, which the promote path would otherwise bypass by building a new
   array, and which lets us check frozen up front before any GC root is live). */
int sp_typed_arr_frozen(sp_RbVal v) {
  switch (v.cls_id) {
    case SP_BUILTIN_INT_ARRAY: return ((sp_IntArray *)v.v.p)->frozen;
    case SP_BUILTIN_FLT_ARRAY: return ((sp_FloatArray *)v.v.p)->frozen;
    case SP_BUILTIN_STR_ARRAY: return ((sp_StrArray *)v.v.p)->frozen;
    case SP_BUILTIN_POLY_ARRAY: return ((sp_PolyArray *)v.v.p)->frozen;
    case SP_BUILTIN_PTR_ARRAY: return (int)((sp_PtrArray *)v.v.p)->frozen;
    default: return 0;
  }
}
/* IO.pipe -> [reader, writer] handles (#2815) */
sp_PolyArray *sp_io_pipe(void) {
  int fds[2];
  if (sp_io_make_pipe(fds) != 0) sp_raise_cls("IOError", "pipe failed");
  sp_PolyArray *a = sp_PolyArray_new();
  SP_GC_ROOT(a);
  sp_PolyArray_push(a, sp_box_obj(sp_io_fdopen(fds[0], SPL("r")), SP_BUILTIN_IO));
  { sp_File *wf = sp_io_fdopen(fds[1], SPL("w"));
    /* CRuby documents the write end as sync: a write reaches the descriptor
       at once, so a reader on the other end (or an IO.select on it) sees the
       bytes without a flush (#4263). */
    if (wf) { wf->sync_on = 1; setvbuf(wf->fp, NULL, _IONBF, 0); }
    sp_PolyArray_push(a, sp_box_obj(wf, SP_BUILTIN_IO)); }
  return a;
}
/* IO.for_fd(fd, mode): wrap a descriptor the program already owns. autoclose
   false leaves the fd open when the handle is collected, which is the point of
   the call -- the fd usually belongs to something else. */
sp_File *sp_io_for_fd(sp_int fd, const char *mode, sp_bool autoclose) {SP_GC_ROOT_STR(mode);
  if (fd < 0 || fcntl((int)fd, F_GETFD) < 0)
    sp_raise_cls("Errno::EBADF", "Bad file descriptor");
  /* No mode given: derive it from the descriptor's own access mode, as
     CRuby does -- the old fixed "r" default made fdopen fail outright on a
     write-only fd (a sysopen'd O_WRONLY FIFO, #4208). */
  /* The derived mode must be a marked literal: sp_io_fdopen_ex keeps the
     pointer as f->mode and the collector reads its marker byte for as long
     as the handle lives, so a stack buffer here was a dangling pointer once
     this frame returned (seen as heap corruption under SPINEL_GC_MINOR=0). */
  if (!mode || !*mode) mode = sp_io_fd_mode((int)fd);
  /* autoclose:false wraps a dup(2) of the fd: close/fin then flush and
     close only the dup, and the caller's descriptor stays open -- the
     no_autoclose flag alone was set and never read, so io.close closed the
     fd anyway (#4208). #fileno still answers the caller's own fd. The dup
     shares the file description, so offset and status flags stay one. */
  if (!autoclose) {
    int d = dup((int)fd);
    if (d < 0) sp_raise_cls("SystemCallError", sp_sprintf("dup(2) failed for fd %d", (int)fd));
    sp_File *f = sp_io_fdopen_ex(d, mode && *mode ? mode : SPL("r"), 0);
    if (f) { f->no_autoclose = 1; f->fno_plus1 = (int)fd + 1; }
    return f;
  }
  sp_File *f = sp_io_fdopen_ex((int)fd, mode && *mode ? mode : SPL("r"), 0);
  return f;
}

/* The readiness family and IO.select both run on select(2), which is what
   CRuby's IO.select is: its exceptfds set is the only portable spelling of
   "priority". poll(2)'s POLLPRI is not -- macOS raises it for ordinary readable
   data on a pipe, so a pipe carrying "x" reported itself priority-readable.
   `kind` is 0 read / 1 write / 2 priority / 3 read|write, kept numeric so the
   generated TU does not have to pull in the flag headers. A negative timeout
   blocks. Each answers the handle itself when ready and nil on timeout. */
static void sp_io_sel_timeout(double timeout, struct timeval *tv, struct timeval **tvp) {
  if (timeout < 0) { *tvp = NULL; return; }
  tv->tv_sec = (time_t)timeout;
  tv->tv_usec = (suseconds_t)((timeout - (double)tv->tv_sec) * 1000000.0);
  *tvp = tv;
}
#ifdef SP_THREADS
/* Under the threaded runtime a timed single-fd wait parks the green thread
   (sp_sched_wait_io_timeout) instead of sitting in select(2): select blocks
   the OS worker for the whole timeout, and once every worker is pinned by a
   waiter the thread that would make the fd ready cannot run, so every waiter
   times out. Priority (exceptfds) stays on select -- poll's POLLPRI is not the
   same thing (see below) -- and so does a zero timeout, which is a peek. */
static short sp_io_park_events(sp_int kind) {
  return kind == 0 ? POLLIN : kind == 1 ? POLLOUT : kind == 3 ? (POLLIN | POLLOUT) : 0;
}
static double sp_io_now(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}
#endif
sp_File *sp_io_wait_events(sp_File *f, double timeout, sp_int kind) {SP_GC_ROOT(f);
  SP_IO_OPEN(f);
  int fd = fileno(f->fp);
#ifdef SP_THREADS
  if (sp_io_park_events(kind) && timeout != 0.0) {
    extern int sp_sched_wait_io_timeout(int fd, short events, double timeout_s);
    return sp_sched_wait_io_timeout(fd, sp_io_park_events(kind), timeout) ? f : NULL;
  }
#endif
  /* Readiness on ONE descriptor is a poll, not a select. select(2) cannot name
     a descriptor at or past FD_SETSIZE, and the range check that enforced that
     stood in FRONT of the park above -- which polls and has no such bound --
     so a wait on fd 1024 raised instead of waiting. A server with two
     descriptors per connection lost every connection past ~450, silently,
     because the thread died before it could close the socket (#4314).
     PRIORITY (kind 2) stays on select: poll's POLLPRI is not the same thing,
     and reports readiness on macOS where select does not. */
  if (kind != 2) {
    struct pollfd pf;
    pf.fd = fd; pf.revents = 0;
    pf.events = (short)((kind == 0 || kind == 3 ? POLLIN : 0) |
                        (kind == 1 || kind == 3 ? POLLOUT : 0));
    int ms = timeout < 0.0 ? -1 : (int)(timeout * 1000.0 + 0.5);
    int n;
    do { n = poll(&pf, 1, ms); } while (n < 0 && errno == EINTR);
    if (n < 0) sp_raise_cls("IOError", "select failed");
    return n > 0 ? f : NULL;
  }
  if (fd >= FD_SETSIZE) sp_raise_cls("IOError", "file descriptor out of range");
  fd_set rs, ws, es;
  FD_ZERO(&rs); FD_ZERO(&ws); FD_ZERO(&es);
  FD_SET(fd, &es);
  struct timeval tv, *tvp;
  sp_io_sel_timeout(timeout, &tv, &tvp);
  int n;
  do { n = select(fd + 1, &rs, &ws, &es, tvp); } while (n < 0 && errno == EINTR);
  if (n < 0) sp_raise_cls("IOError", "select failed");
  return n > 0 ? f : NULL;
}

/* IO.select(read, write, error, timeout) -> [ready_read, ready_write,
   ready_error], or nil when the timeout expires first. A nil array stands for
   "watch nothing", so all three nil is just a sleep. */
sp_File *(*sp_user_to_io_hook)(sp_RbVal) = NULL;
static sp_File *sp_select_io_of(sp_RbVal v) {
  if (v.tag == SP_TAG_OBJ && v.cls_id == SP_BUILTIN_IO && v.v.p) return (sp_File *)v.v.p;
  /* A user object that answers #to_io names the handle to wait on -- CRuby
     waits on wrappers this way, and a TLS socket is one. */
  if (v.tag == SP_TAG_OBJ && v.cls_id >= 0 && sp_user_to_io_hook) {
    sp_File *f = sp_user_to_io_hook(v);
    if (f) return f;
  }
  sp_raise_cls("TypeError",
               sp_sprintf("no implicit conversion of %s into IO",
                          (v.tag == SP_TAG_OBJ && v.cls_id >= 0 && sp_obj_cls_name_fn)
                            ? sp_obj_cls_name_fn(v.cls_id) : "nil"));
  return NULL;
}
/* A read-set IO stdio has already buffered input for is readable whatever
   its descriptor says: a #gets took the next line with the one it returned,
   and the descriptor can be empty. CRuby answers such an IO at once, beside
   whatever else is ready right now (rb_io_read_pending). */
static int sp_select_pending(sp_RbVal v) {
  sp_File *f = sp_select_io_of(v);
  return f && f->fp && !f->closed && sp_io_stdio_buffered(f->fp) > 0;
}
sp_RbVal sp_io_select(sp_PolyArray *rd, sp_PolyArray *wr, sp_PolyArray *er, double timeout) {
  sp_PolyArray *src[3] = { rd, wr, er };
  sp_int pending = 0;
  for (sp_int i = 0; rd && i < rd->len; i++) pending += sp_select_pending(rd->data[i]);
  if (pending) timeout = 0.0;
  /* No PRIORITY set: this is a poll, and then no descriptor is out of range.
     select(2) cannot name one at or past FD_SETSIZE, and a server holding two
     descriptors per connection crosses that at a few hundred connections
     (#4314). An error set keeps select below, because poll's POLLPRI is not
     the same thing -- it reports readiness on macOS where select does not. */
  if (!er || er->len == 0) {
    sp_int nrd = rd ? rd->len : 0, nwr = wr ? wr->len : 0;
    sp_int nfd = nrd + nwr;
#ifdef SP_THREADS
    /* One IO and a real timeout still parks instead of polling: a poll here
       would hold the OS worker for the whole timeout (see sp_io_wait_events). */
    if (nfd == 1 && timeout != 0.0) {
      extern int sp_sched_wait_io_timeout(int fd, short events, double timeout_s);
      int g1 = nrd ? 0 : 1;
      sp_RbVal io1 = src[g1]->data[0];
      sp_File *f1 = sp_select_io_of(io1);
      SP_IO_OPEN(f1);
      if (!sp_sched_wait_io_timeout(fileno(f1->fp), g1 == 0 ? POLLIN : POLLOUT, timeout))
        return sp_box_nil();
      sp_PolyArray *one1 = sp_PolyArray_new();
      SP_GC_ROOT(one1);
      for (int k = 0; k < 3; k++) {
        sp_PolyArray *part = sp_PolyArray_new();
        if (k == g1) sp_PolyArray_push(part, io1);
        sp_PolyArray_push(one1, sp_box_poly_array(part));
      }
      return sp_box_poly_array(one1);
    }
#endif
    struct pollfd *pfs = (struct pollfd *)calloc((size_t)(nfd > 0 ? nfd : 1), sizeof(struct pollfd));
    if (!pfs) sp_raise_cls("NoMemoryError", "failed to allocate poll set");
    sp_int k = 0;
    for (int g = 0; g < 2; g++) {
      sp_int n = src[g] ? src[g]->len : 0;
      for (sp_int i = 0; i < n; i++) {
        sp_File *f = sp_select_io_of(src[g]->data[i]);
        if (!f || !f->fp || f->closed) { free(pfs); sp_io_raise_closed(); }
        pfs[k].fd = fileno(f->fp);
        pfs[k].events = (short)(g == 0 ? POLLIN : POLLOUT);
        pfs[k].revents = 0;
        k++;
      }
    }
    int ms = timeout < 0.0 ? -1 : (int)(timeout * 1000.0 + 0.5);
    int pn;
#ifdef SP_THREADS
    /* Several handles park the same way one does: the thread waits through
       the scheduler for any of them and its OS worker runs other threads
       meanwhile. A poll here sat in the kernel on the worker, which capped a
       server's connections at SPINEL_WORKERS and, since a worker in a syscall
       never reaches a safepoint, held up every collection for as long as the
       wait lasted -- forever, on two quiet sockets (#4528). The readiness
       itself is read back by a zero-timeout poll: what is ready right now. */
    if (nfd > 1 && ms != 0) {
      extern int sp_sched_wait_io_set(struct pollfd *set, int n, double timeout_s);
      double until = timeout < 0.0 ? 0.0 : sp_io_now() + timeout;
      for (;;) {
        double left = timeout < 0.0 ? -1.0 : until - sp_io_now();
        if (timeout >= 0.0 && left < 0.0) left = 0.0;
        if (!sp_sched_wait_io_set(pfs, (int)nfd, left)) { pn = 0; break; }
        do { pn = poll(pfs, (nfds_t)nfd, 0); } while (pn < 0 && errno == EINTR);
        if (pn != 0) break;   /* ready (or an error to report): read back below */
        if (timeout >= 0.0 && sp_io_now() >= until) break;   /* woken at the deadline */
      }
    }
    else
#endif
    do { pn = poll(pfs, (nfds_t)nfd, ms); } while (pn < 0 && errno == EINTR);
    if (pn < 0) { free(pfs); sp_raise_cls("IOError", "select failed"); }
    if (pn == 0 && !pending) { free(pfs); return sp_box_nil(); }
    /* Read back by DESCRIPTOR, not by entry. One IO can appear twice in a call
       -- a wrapper answering #to_io beside the IO itself -- and then two
       entries carry the same fd. Linux sets revents on both; macOS sets it on
       one, so an entry-wise readback dropped the other and answered a shorter
       array there than here (CRuby answers both).
       The ready descriptors are collected once, and only an entry that came
       back with nothing consults them -- so a call where nothing is ready
       (the common one, and the one a server makes in a loop) does no scanning
       at all, and neither does one where everything is. */
    int *hot = (int *)malloc(sizeof(int) * (size_t)(nfd > 0 ? nfd : 1));
    sp_int nhot = 0;
    if (hot) for (sp_int i = 0; i < nfd; i++) if (pfs[i].revents) hot[nhot++] = pfs[i].fd;
    sp_PolyArray *out2 = sp_PolyArray_new();
    SP_GC_ROOT(out2);
    sp_int base = 0;
    for (int g = 0; g < 3; g++) {
      sp_PolyArray *part = sp_PolyArray_new();
      sp_int n = (g < 2 && src[g]) ? src[g]->len : 0;
      for (sp_int i = 0; i < n; i++) {
        int ready = pfs[base + i].revents != 0 || (g == 0 && pending && sp_select_pending(src[g]->data[i]));
        if (!ready && hot)
          for (sp_int h = 0; h < nhot && !ready; h++)
            if (hot[h] == pfs[base + i].fd) ready = 1;
        if (ready) sp_PolyArray_push(part, src[g]->data[i]);
      }
      base += n;
      sp_PolyArray_push(out2, sp_box_poly_array(part));
    }
    free(hot);
    free(pfs);
    return sp_box_poly_array(out2);
  }
  fd_set sets[3];
  int maxfd = -1;
  for (int g = 0; g < 3; g++) {
    FD_ZERO(&sets[g]);
    sp_int n = src[g] ? src[g]->len : 0;
    for (sp_int i = 0; i < n; i++) {
      sp_File *f = sp_select_io_of(src[g]->data[i]);
      SP_IO_OPEN(f);
      int fd = fileno(f->fp);
      if (fd >= FD_SETSIZE) sp_raise_cls("IOError", "file descriptor out of range");
      FD_SET(fd, &sets[g]);
      if (fd > maxfd) maxfd = fd;
    }
  }
#ifdef SP_THREADS
  {
    sp_int nrd = rd ? rd->len : 0, nwr = wr ? wr->len : 0, ner = er ? er->len : 0;
    if (nrd + nwr == 1 && ner == 0 && timeout != 0.0) {
      extern int sp_sched_wait_io_timeout(int fd, short events, double timeout_s);
      int g = nrd ? 0 : 1;
      sp_RbVal io = src[g]->data[0];
      sp_File *f = sp_select_io_of(io);
      if (!sp_sched_wait_io_timeout(fileno(f->fp), g == 0 ? POLLIN : POLLOUT, timeout)) return sp_box_nil();
      sp_PolyArray *one = sp_PolyArray_new();
      SP_GC_ROOT(one);
      for (int k = 0; k < 3; k++) {
        sp_PolyArray *part = sp_PolyArray_new();
        if (k == g) sp_PolyArray_push(part, io);
        sp_PolyArray_push(one, sp_box_poly_array(part));
      }
      return sp_box_poly_array(one);
    }
  }
#endif
  struct timeval tv, *tvp;
  sp_io_sel_timeout(timeout, &tv, &tvp);
  int n;
  do { n = select(maxfd + 1, &sets[0], &sets[1], &sets[2], tvp); } while (n < 0 && errno == EINTR);
  if (n < 0) sp_raise_cls("IOError", "select failed");
  if (n == 0 && !pending) return sp_box_nil();
  sp_PolyArray *out = sp_PolyArray_new();
  SP_GC_ROOT(out);
  for (int g = 0; g < 3; g++) {
    sp_PolyArray *part = sp_PolyArray_new();
    sp_int cnt = src[g] ? src[g]->len : 0;
    for (sp_int i = 0; i < cnt; i++) {
      sp_File *f = sp_select_io_of(src[g]->data[i]);
      if (f && f->fp && (FD_ISSET(fileno(f->fp), &sets[g]) || (g == 0 && pending && sp_select_pending(src[g]->data[i]))))
        sp_PolyArray_push(part, src[g]->data[i]);
    }
    sp_PolyArray_push(out, sp_box_poly_array(part));
  }
  return sp_box_poly_array(out);
}

sp_int sp_io_sysopen(const char *path, sp_int flags, sp_int perm) {SP_GC_ROOT_STR(path);
  /* flags are CRuby's File::Constants (O_* on this platform); 0 is O_RDONLY.
     They were dropped at codegen and every sysopen was O_RDONLY -- a FIFO
     opened for writing hung waiting for a writer of its own (#4206). */
  int fd = open(path ? path : "", (int)flags, (mode_t)(perm ? perm : 0666));
  if (fd < 0) {
    const char *cls = errno == ENOENT ? "Errno::ENOENT"
                    : errno == ENXIO  ? "Errno::ENXIO"
                    : errno == EACCES ? "Errno::EACCES"
                    : errno == EEXIST ? "Errno::EEXIST"
                    : errno == EINVAL ? "Errno::EINVAL" : "SystemCallError";
    sp_raise_cls(cls, sp_sprintf("%s @ rb_sysopen - %s", strerror(errno), path ? path : ""));
  }
  return (sp_int)fd;
}

/* ---- Kernel#sleep -- relocated from spinel_rt.h. 0 optcarrot uses;
   sp_sched_sleep already lib-visible (sp_sched.h, included transitively
   via sp_io.h/sp_time.h -> check explicitly below). ---- */
#include "sp_sched.h"

/* Kernel#sleep with sub-second precision. Argument is seconds as a
   double so `sleep(0.5)` actually waits 500ms; the legacy `sleep((unsigned)0.5)`
   cast truncated to 0 and returned immediately. POSIX uses
   nanosleep(); Windows uses Sleep() (milliseconds). Negative or NaN
   inputs no-op. */
void sp_sleep(sp_float s) {
  if (!(s > 0.0)) return;
#ifdef SP_THREADS
  /* Scheduler-aware: park the green thread and free its OS worker for others; a
     monitor thread wakes it after the duration (see lib/sp_sched.c). */
  sp_sched_sleep((double)s);
#else
  struct timespec req;
  req.tv_sec = (time_t)s;
  req.tv_nsec = (long)((s - (double)req.tv_sec) * 1e9);
  if (req.tv_nsec < 0) req.tv_nsec = 0;
  if (req.tv_nsec >= 1000000000L) req.tv_nsec = 999999999L;
  while (nanosleep(&req, &req) == -1 && errno == EINTR) {}
#endif
}

/* A bare Kernel#sleep: until Thread#wakeup. With no threads nothing can
   wake it, so it sleeps for good, as CRuby's does. */
void sp_sleep_forever(void) {
#ifdef SP_THREADS
  sp_sched_sleep_forever();
#else
  for (;;) pause();
#endif
}

/* ---- BigRational box/scan/format ops -- relocated from spinel_rt.h.
   0 optcarrot uses. ---- */
#include "sp_str.h"   /* sp_str_concat for brat_to_s/inspect */

void sp_brat_scan(void *p) {
  sp_BigRational *r = (sp_BigRational *)p;
  if (r->num) sp_gc_mark(r->num);
  if (r->den) sp_gc_mark(r->den);
}
/* Construct a reduced big Rational: normalize the sign onto the numerator and
   divide out the gcd. den must be non-zero (callers pass a literal or a checked
   value). */
sp_RbVal sp_box_brat(sp_Bigint *num, sp_Bigint *den) {
  /* Five allocations run between reading these two and storing them in the
     object that will finally hold them -- the sign flip, the gcd, the two
     divisions and the BigRational itself -- and until that last store nothing
     but these locals refers to them. Rooting the SLOTS covers the
     reassignments too, since the root is the address. Unrooted, a big
     Rational read back as (0/0) and the arithmetic died inside the mark
     walker under SPINEL_GC_STRESS=1. */
  SP_GC_ROOT(num); SP_GC_ROOT(den);
  if (sp_bigint_sign(den) < 0) { num = sp_bigint_sub(sp_bigint_new_int(0), num); den = sp_bigint_sub(sp_bigint_new_int(0), den); }
  sp_Bigint *g = sp_bigint_gcd(num, den);
  SP_GC_ROOT(g);
  if (sp_bigint_sign(g) != 0) { num = sp_bigint_div(num, g); den = sp_bigint_div(den, g); }
  sp_BigRational *p = (sp_BigRational *)sp_gc_alloc(sizeof(sp_BigRational), NULL, sp_brat_scan);
  p->num = num; p->den = den;
  return sp_box_obj(p, SP_BUILTIN_BIG_RATIONAL);
}
/* Rational#to_i / #floor / #ceil / #round on a Bignum-numerator Rational.
   Every one of these used to go through sp_brat_to_f and a cast to sp_int:
   past the machine word the cast saturates, and a negative value lands on
   INTPTR_MIN -- which IS the nil sentinel, so Rational(-(2**70), 3).to_i
   answered nil rather than a number. The quotient is exact in bigint.
   sp_box_brat keeps the denominator positive, so the sign is the
   numerator's, and both operands below are non-negative where that matters
   (sp_bigint_div floors, which is only the same as truncating then). */
sp_Bigint *sp_brat_trunc_b(sp_BigRational *r) {        /* toward zero */
  sp_Bigint *n = r->num; SP_GC_ROOT(n);
  sp_Bigint *d = r->den; SP_GC_ROOT(d);
  sp_Bigint *z = sp_bigint_new_int(0); SP_GC_ROOT(z);
  int neg = sp_bigint_sign(n) < 0;
  sp_Bigint *a = n; SP_GC_ROOT(a);
  if (neg) a = sp_bigint_sub(z, n);
  sp_Bigint *q = sp_bigint_div(a, d); SP_GC_ROOT(q);
  return neg ? sp_bigint_sub(z, q) : q;
}
sp_Bigint *sp_brat_floor_b(sp_BigRational *r) {        /* toward -infinity */
  return sp_bigint_div(r->num, r->den);                /* mpz_mdiv already floors */
}
sp_Bigint *sp_brat_ceil_b(sp_BigRational *r) {         /* toward +infinity */
  sp_Bigint *d = r->den; SP_GC_ROOT(d);
  sp_Bigint *z = sp_bigint_new_int(0); SP_GC_ROOT(z);
  sp_Bigint *n = sp_bigint_sub(z, r->num); SP_GC_ROOT(n);
  sp_Bigint *q = sp_bigint_div(n, d); SP_GC_ROOT(q);
  return sp_bigint_sub(z, q);
}
sp_Bigint *sp_brat_round_b(sp_BigRational *r) {        /* nearest, half away from zero */
  sp_Bigint *n = r->num; SP_GC_ROOT(n);
  sp_Bigint *d = r->den; SP_GC_ROOT(d);
  sp_Bigint *z = sp_bigint_new_int(0); SP_GC_ROOT(z);
  sp_Bigint *one = sp_bigint_new_int(1); SP_GC_ROOT(one);
  int neg = sp_bigint_sign(n) < 0;
  sp_Bigint *a = n; SP_GC_ROOT(a);
  if (neg) a = sp_bigint_sub(z, n);
  sp_Bigint *q = sp_bigint_div(a, d); SP_GC_ROOT(q);
  sp_Bigint *qd = sp_bigint_mul(q, d); SP_GC_ROOT(qd);
  sp_Bigint *rem = sp_bigint_sub(a, qd); SP_GC_ROOT(rem);
  sp_Bigint *dbl = sp_bigint_add(rem, rem); SP_GC_ROOT(dbl);
  if (sp_bigint_cmp(dbl, d) >= 0) q = sp_bigint_add(q, one);
  return neg ? sp_bigint_sub(z, q) : q;
}

/* Lift a bignum (or an int) to a big Rational num/1. */
sp_RbVal sp_brat_from_bigint(sp_Bigint *n) {SP_GC_ROOT(n);   /* the denominator below allocates */
  return sp_box_brat(n, sp_bigint_new_int(1));
}
void sp_addrinfo_scan(void *p) {
  sp_Addrinfo *a = (sp_Addrinfo *)p;
  if (a->ip) sp_mark_string((void *)a->ip);
  if (a->afname) sp_mark_string((void *)a->afname);
}
sp_RbVal sp_box_addrinfo(sp_Addrinfo *v) { return sp_box_obj(v, SP_BUILTIN_ADDRINFO); }
sp_RbVal sp_box_sockopt(sp_SockOpt *v) { return sp_box_obj(v, SP_BUILTIN_SOCKOPT); }
sp_SockOpt *sp_sockopt_new(sp_int family, sp_int level, sp_int optname, sp_int value) {
  sp_SockOpt *o = (sp_SockOpt *)sp_gc_alloc(sizeof(sp_SockOpt), NULL, NULL);
  o->family = family; o->level = level; o->optname = optname; o->value = value;
  return o;
}
const char *sp_sockopt_inspect(sp_SockOpt *o) {SP_GC_ROOT(o);
  if (!o) return sp_sprintf("nil");
  return sp_sprintf("#<Socket::Option: INET %lld %lld %lld>",
                    (long long)o->level, (long long)o->optname, (long long)o->value);
}
/* Addrinfo.tcp / .udp / .ip / .unix, and the endpoint behind #local_address /
   #remote_address. `stype` is SOCK_STREAM / SOCK_DGRAM, 0 for a bare address. */
sp_Addrinfo *sp_addrinfo_new(const char *ip, sp_int port, sp_int stype, sp_int is_unix) {SP_GC_ROOT_STR(ip);
  sp_Addrinfo *a = (sp_Addrinfo *)sp_gc_alloc(sizeof(sp_Addrinfo), NULL, sp_addrinfo_scan);
  a->ip = NULL; a->afname = NULL;
  SP_GC_ROOT(a);
  /* each sprintf can collect and promote the rooted object, so each store
     takes the barrier after the allocation it stores: one barrier after
     both was cleared by the second's collection, which freed the first */
  const char *s = sp_sprintf("%s", ip ? ip : "");
  sp_gc_wb((void *)a); a->ip = s;
  int v6 = !is_unix && ip && strchr(ip, ':') != NULL;
  s = sp_sprintf("%s", is_unix ? "AF_UNIX" : v6 ? "AF_INET6" : "AF_INET");
  sp_gc_wb((void *)a); a->afname = s;
  a->afamily = is_unix ? AF_UNIX : v6 ? AF_INET6 : AF_INET;
  a->port = port;
  a->socktype = stype;
  a->protocol = 0;
  return a;
}
const char *sp_addrinfo_inspect(sp_Addrinfo *a) {SP_GC_ROOT(a);
  if (!a) return sp_sprintf("nil");
  if (strcmp(a->afname, "AF_UNIX") == 0) return sp_sprintf("#<Addrinfo: %s SOCK_STREAM>", a->ip);
  const char *st = a->socktype == SOCK_DGRAM ? " UDP"
                 : a->socktype == SOCK_STREAM ? " TCP" : "";
  if (strcmp(a->afname, "AF_INET6") == 0)
    return sp_sprintf("#<Addrinfo: [%s]:%lld%s>", a->ip, (long long)a->port, st);
  return sp_sprintf("#<Addrinfo: %s:%lld%s>", a->ip, (long long)a->port, st);
}
const char *sp_brat_to_s(sp_BigRational *r) {SP_GC_ROOT(r);
  /* Each text is a fresh string-heap string that nothing but its local refers
     to across an allocation: the numerator's while the denominator's is
     converted, the denominator's while the inner concat builds "num/". A
     collection landing in either window swept that text, and the Rational
     read back as "/1" or "3/" on a plain build. sp_str_concat roots its own
     arguments, so these two locals are the only bare holds. */
  const char *ns = sp_bigint_to_s(r->num);
  SP_GC_ROOT_STR(ns);
  const char *ds = sp_bigint_to_s(r->den);
  SP_GC_ROOT_STR(ds);
  return sp_str_concat(sp_str_concat(ns, SPL("/")), ds);
}
const char *sp_brat_inspect(sp_BigRational *r) {SP_GC_ROOT(r);
  return sp_str_concat(sp_str_concat(SPL("("), sp_brat_to_s(r)), SPL(")"));
}
sp_float sp_brat_to_f(sp_BigRational *r) {SP_GC_ROOT(r);
  return sp_bigint_to_double(r->num) / sp_bigint_to_double(r->den);
}

/* ---- Marshal.dump/load helpers -- relocated from spinel_rt.h. 0 optcarrot
   uses. ---- */

/* Marshal implementation moved to lib/sp_marshal.c. These small wrappers give
   the standalone serializer construction primitives that need spinel_rt.h
   types; sp_tu_init (codegen) installs them into sp_marshal_v along with the
   generated sym_intern / obj_dump / obj_load. */
sp_RbVal sp_marv_arr_new(void) { return sp_box_poly_array(sp_PolyArray_new()); }
void sp_marv_arr_push(sp_RbVal a, sp_RbVal v) {SP_GC_ROOT_RBVAL(a);SP_GC_ROOT_RBVAL(v); sp_PolyArray_push((sp_PolyArray *)a.v.p, v); }
sp_RbVal sp_marv_box_complex(sp_float re, sp_float im) { sp_Complex c; c.re = re; c.im = im; return sp_box_complex(c); }
sp_RbVal sp_marv_box_rational(sp_int n, sp_int d) { return sp_box_rational(sp_rational_new(n, d)); }
void sp_marv_raise(const char *cls, const char *msg) {SP_GC_ROOT_STR(msg); sp_raise_cls(cls, msg); }

/* ---- Regexp gsub/sub-with-Hash + Signal/Interrupt exception ctors --
   relocated from spinel_rt.h. 0 optcarrot uses. ---- */
#include "sp_exc.h"

/* String#gsub(regex, hash) -- per-match hash lookup form. CRuby's
 * semantics: each matched substring is looked up as a key in the
 * hash; the value (if present) is the replacement, otherwise the
 * matched substring is dropped (CRuby returns "", not the match).
 * Used by html_escape / json_escape idioms (gsub(/[&<>]/, ESCAPES)). */
const char *sp_re_gsub_str_str_hash(mrb_regexp_pattern *pat, const char *str, sp_StrStrHash *h) {SP_GC_ROOT_STR(str);SP_GC_ROOT(h);
  int64_t slen = (int64_t)sp_str_byte_len(str);
 /* malloc scratch (realloc-safe); exact-sized string emitted below. */
  /* a short subject (an attribute being escaped, the common call) builds on
     the stack: the malloc was one of the two a page render made per escape */
  char out_sb[512];
  size_t cap = (slen * 2) + 64; char *out = cap <= sizeof out_sb ? out_sb : (char *)malloc(cap); size_t olen = 0;
  int64_t pos = 0; int caps[64];
  int lastcaps[64], lastn = 0;   /* the last match, for `$~` */
  #define GSH_GROW(need) do { size_t _nc = (need); \
    if (out == out_sb) { char *_o = (char *)malloc(_nc); memcpy(_o, out, olen); out = _o; } \
    else out = (char *)realloc(out, _nc); \
    cap = _nc; } while (0)
  while (pos <= slen) {
    int n = spinel_re_exec(pat, str, slen, pos, caps, 64, 0);
    if (n <= 0 || caps[0] < 0) break;
    if (sp_re_track_last) { lastn = n > 64 ? 64 : n; memcpy(lastcaps, caps, sizeof(int) * (size_t)lastn); }
    size_t before = caps[0] - pos;
    int mlen = caps[1] - caps[0];
    /* Lay a 0xff (rodata-literal) marker byte right before the transient key
       so sp_str_hash's s[-1] read is in-bounds and routes to the plain
       (non-caching) path -- this buffer has no sp_str_hdr to cache into. */
    char keybuf[65]; keybuf[0] = (char)0xff;
    char *kbuf = mlen + 1 < (int)sizeof(keybuf) ? keybuf : (char *)malloc(mlen + 2);
    if (kbuf != keybuf) kbuf[0] = (char)0xff;
    char *key = kbuf + 1;
    memcpy(key, str + caps[0], mlen);
    key[mlen] = 0;
    /* A miss takes the hash's DEFAULT, not the empty string: CRuby looks the
       match up with #[], so `Hash.new("?")` substitutes "?" (#3555). The
       default is nil for a plain hash, which renders empty as before. */
    const char *rep = sp_StrStrHash_get(h, memchr(key, 0, (size_t)mlen) ? sp_str_from_bytes(key, (size_t)mlen) : key);
    if (!rep) rep = &("\xff" "")[1];
    size_t rlen = sp_str_byte_len(rep);
    if (olen + before + rlen >= cap) GSH_GROW(((olen + before + rlen) * 2) + 64);
    memcpy(out + olen, str + pos, before); olen += before;
    memcpy(out + olen, rep, rlen); olen += rlen;
    if (kbuf != keybuf) free(kbuf);
    if (caps[0] == caps[1]) {
 /* Zero-width match: keep the source char at this position and step
    past it (see sp_re_gsub for the rationale). */
      if (caps[1] < slen) {
        if (olen + 1 >= cap) GSH_GROW((olen * 2) + 64);
        out[olen++] = str[caps[1]];
      }
      pos = caps[1] + 1;
    }
else {
      pos = caps[1];
    }
  }
  if (pos < slen) {
    size_t rest = slen - pos;
    if (olen + rest >= cap) GSH_GROW(olen + rest + 1);
    memcpy(out + olen, str + pos, rest); olen += rest;
  }
  #undef GSH_GROW
  if (sp_re_track_last) sp_re_set_last_match(pat, str, lastcaps, lastn);
  char *res = sp_str_alloc(olen);
  memcpy(res, out, olen);
  if (out != out_sb) free(out);
  return res;
}
/* Issue #910: sub(regex, hash) -- same lookup semantics as
   sp_re_gsub_str_str_hash but only the first match. */
const char *sp_re_sub_str_str_hash(mrb_regexp_pattern *pat, const char *str, sp_StrStrHash *h) {SP_GC_ROOT(h);SP_GC_ROOT_STR(str);
  int64_t slen = (int64_t)sp_str_byte_len(str);
  int caps[64];
  int n = spinel_re_exec(pat, str, slen, 0, caps, 64, 0);
  if (n <= 0 || caps[0] < 0) { if (sp_re_track_last) sp_re_clear_last_match(); return str; }
  int mlen = caps[1] - caps[0];
  /* 0xff marker before the transient key: keeps sp_str_hash's s[-1] read
     in-bounds and on the non-caching path (no sp_str_hdr behind this buffer). */
  char keybuf[65]; keybuf[0] = (char)0xff;
  char *kbuf = mlen + 1 < (int)sizeof(keybuf) ? keybuf : (char *)malloc(mlen + 2);
  if (kbuf != keybuf) kbuf[0] = (char)0xff;
  char *key = kbuf + 1;
  memcpy(key, str + caps[0], mlen);
  key[mlen] = 0;
  /* a missing key answers the hash's DEFAULT, which is what Hash.new("?")
     exists for; hard-coding "" dropped it (#3824) */
  const char *rep = h ? sp_StrStrHash_get(h, memchr(key, 0, (size_t)mlen) ? sp_str_from_bytes(key, (size_t)mlen) : key) : &("\xff" "")[1];
  if (!rep) rep = &("\xff" "")[1];
  size_t rlen = sp_str_byte_len(rep);
  size_t rest = slen - caps[1];
  size_t total = caps[0] + rlen + rest;
  if (sp_re_track_last) sp_re_set_last_match(pat, str, caps, n);
  char *out = sp_str_alloc_raw(total + 1);
  memcpy(out, str, caps[0]);
  memcpy(out + caps[0], rep, rlen);
  memcpy(out + caps[0] + rlen, str + caps[1], rest);
  out[total] = 0;
  sp_str_set_len(out, total);
  if (kbuf != keybuf) free(kbuf);
  return out;
}
/* msg: an explicit second argument overrides the SIG<name> message (only the
   Integer-signal form accepts one, matching CRuby); NULL keeps the default. */
sp_Exception *sp_signal_exc_new_m(sp_RbVal sig, const char *msg) {SP_GC_ROOT_RBVAL(sig);SP_GC_ROOT_STR(msg);
  if (msg && sig.tag != SP_TAG_INT)
    sp_raise_cls("ArgumentError", "wrong number of arguments");
  int no = sp_signal_resolve(sig);
  const char *nm = sp_signal_signame(no);
  sp_Exception *e = sp_exc_new("SignalException",
                               msg ? msg : sp_sprintf("SIG%s", nm ? nm : "?"));
  SP_GC_ROOT(e);
  e->xkey = sp_box_int((sp_int)no);
  return e;
}
sp_Exception *sp_signal_exc_new(sp_RbVal sig) {SP_GC_ROOT_RBVAL(sig);
  return sp_signal_exc_new_m(sig, NULL);
}
/* An exception nothing rescued that is a signal's: the process ends by that
   signal, as CRuby's does, so its parent reads 130 for an Interrupt. */
void sp_exc_resignal(const char *cls, const char *msg) {
  int no = !strcmp(cls, "Interrupt") ? SIGINT
         : (!strcmp(cls, "SignalException") && msg && !strcmp(msg, "SIGTERM")) ? SIGTERM : 0;
  if (!no) return;
  fflush(NULL);   /* the buffered output exit() would have written */
  signal(no, SIG_DFL);
  raise(no);
}
sp_Exception *sp_interrupt_new(const char *msg) {SP_GC_ROOT_STR(msg);
  sp_Exception *e = sp_exc_new("Interrupt", (msg && msg[0]) ? msg : "Interrupt");
  SP_GC_ROOT(e);
  e->xkey = sp_box_int((sp_int)SIGINT);
  return e;
}

/* ---- FFI array data / array-kind length / sp_Class unbox -- relocated
   from spinel_rt.h. 0 optcarrot uses. ---- */

/* FFI array hand-off from a POLY slot: dispatch on the RUNTIME storage kind.
   A poly value may hold any array variant -- an int array that poly-collapsed
   still boxes an sp_IntArray (cls_id INT_ARRAY), and reinterpreting its .v.p
   as sp_PolyArray* read garbage lengths and marshalled NULL (the toy LoRA
   flatline). nil passes as NULL (the C idiom for an absent array); any other
   runtime kind raises loudly rather than silently handing the callee NULL. */
const int64_t *sp_ffi_int_array_data(sp_RbVal v) {SP_GC_ROOT_RBVAL(v);
  if (v.tag == SP_TAG_OBJ && v.cls_id == SP_BUILTIN_INT_ARRAY)
    return sp_IntArray_ffi_data((sp_IntArray *)v.v.p);
  if (v.tag == SP_TAG_OBJ && v.cls_id == SP_BUILTIN_POLY_ARRAY)
    return sp_PolyArray_ffi_int_data((sp_PolyArray *)v.v.p);
  if (v.tag == SP_TAG_NIL) return (const int64_t *)0;
  sp_raise_cls("TypeError", "no implicit conversion into an FFI :int_array");
  return (const int64_t *)0;  /* unreached */
}
const double *sp_ffi_float_array_data(sp_RbVal v) {SP_GC_ROOT_RBVAL(v);
  if (v.tag == SP_TAG_OBJ && v.cls_id == SP_BUILTIN_FLT_ARRAY)
    return sp_FloatArray_ffi_data((sp_FloatArray *)v.v.p);
  if (v.tag == SP_TAG_OBJ && v.cls_id == SP_BUILTIN_POLY_ARRAY)
    return sp_PolyArray_ffi_float_data((sp_PolyArray *)v.v.p);
  if (v.tag == SP_TAG_NIL) return (const double *)0;
  sp_raise_cls("TypeError", "no implicit conversion into an FFI :float_array");
  return (const double *)0;  /* unreached */
}
/* FFI array hand-off. Concrete arrays expose their element storage zero-copy
   (sp_int/sp_float are int64/double on 64-bit targets). A poly_array can't
   be punned -- its ->data is sp_RbVal[] (boxed) -- so unbox element-wise into
   a fresh GC-tracked buffer (sp_gc_alloc_nogc: no collection mid-build, so a
   sibling array arg's buffer can't be swept; freed at a later GC). */
const int64_t *sp_PolyArray_ffi_int_data(sp_PolyArray *a) {SP_GC_ROOT(a);
  if (!a || a->len <= 0) return (const int64_t *)0;
  int64_t *buf = (int64_t *)sp_gc_alloc_nogc((size_t)a->len * sizeof(int64_t), NULL, NULL);
  for (sp_int i = 0; i < a->len; i++) buf[i] = (int64_t)a->data[i].v.i;
  return buf;
}
const double *sp_PolyArray_ffi_float_data(sp_PolyArray *a) {SP_GC_ROOT(a);
  if (!a || a->len <= 0) return (const double *)0;
  double *buf = (double *)sp_gc_alloc_nogc((size_t)a->len * sizeof(double), NULL, NULL);
  for (sp_int i = 0; i < a->len; i++) buf[i] = (double)a->data[i].v.f;
  return buf;
}
/* Element count of an array-kind value, or -1 if `el` is not an array (a
   non-object, a user object, a hash, etc.). Lets assoc/rassoc skip non-array
   and too-short pairs without indexing them, so a `nil` search key cannot
   spuriously match an out-of-bounds (nil) read. */
sp_int sp_array_kind_len(sp_RbVal el) {
  if (el.tag != SP_TAG_OBJ || !el.v.p) return -1;
  switch (el.cls_id) {
    case SP_BUILTIN_INT_ARRAY:
    case SP_BUILTIN_SYM_ARRAY:  return ((sp_IntArray *)el.v.p)->len;
    case SP_BUILTIN_FLT_ARRAY:  return ((sp_FloatArray *)el.v.p)->len;
    case SP_BUILTIN_STR_ARRAY:  return ((sp_StrArray *)el.v.p)->len;
    case SP_BUILTIN_POLY_ARRAY: return ((sp_PolyArray *)el.v.p)->len;
    case SP_BUILTIN_PTR_ARRAY:  return ((sp_PtrArray *)el.v.p)->len;
    default: return -1;
  }
}
sp_Class sp_unbox_class(sp_RbVal v) {
  if (v.tag != SP_TAG_CLASS) return SP_CLASS_NIL;
  if (v.cls_id == SP_CLASS_BY_NAME) { sp_Class c = {-1, v.v.s}; return c; }
  { sp_Class c = {(sp_int)v.cls_id}; return c; }
}

/* The nil of a nullable slot on the RIGHT of an arithmetic operator: the
   coercion failure CRuby reports from Integer#+ / Float#+ (the left side's
   nil is NoMethodError, raised by sp_nil_recv through sp_oint_val). */
SP_NORETURN void sp_raise_nil_opnd(const char *cls) {SP_GC_ROOT_STR(cls);
  sp_raise_cls("TypeError", sp_sprintf("nil can't be coerced into %s", cls));
}

/* A comparison whose operand is nil: nil on the LEFT has no `<`, and nil on
   the right is the Comparable failure CRuby reports from Integer#< /
   Float#< (#4567). */
SP_NORETURN void sp_raise_nil_cmp(int left_nil, const char *op, const char *cls) {SP_GC_ROOT_STR(op);SP_GC_ROOT_STR(cls);
  if (left_nil)
    sp_raise_cls("NoMethodError", sp_sprintf("undefined method '%s' for nil", op));
  sp_raise_cls("ArgumentError", sp_sprintf("comparison of %s with nil failed", cls));
}

/* A nil that reached a strict Integer argument slot through an `Integer?`
   variable. The literal `s[nil]` already raised this from the emitter; the
   slot's nil is the same nil, so it gets the same message (#4896). CRuby
   words it by the conversion the slot makes: 0 rb_num2long's, 1
   rb_convert_type's (and NUM2SIZET's), 2 NUM2OFFT's, an IO offset (rb_num2long's wording where off_t is a long, rb_num2ll's
   where it is wider: a 32-bit build, macOS). */
SP_NORETURN void sp_raise_nil_to_int(int of_wording) {
  sp_raise_cls("TypeError", of_wording == 2 ? (sizeof(off_t) == sizeof(long) ? "no implicit conversion from nil to integer"
                                                                              : "no implicit conversion from nil")
                            : of_wording ? "no implicit conversion of nil into Integer"
                                         : "no implicit conversion from nil to integer");
}

/* A nil that reached a strict Float argument slot */
SP_NORETURN void sp_raise_nil_to_float(void) {
  sp_raise_cls("TypeError", "can't convert nil into Float");
}

SP_NORETURN void sp_raise_nil_float_op(int left_nil, const char *op) {SP_GC_ROOT_STR(op);
  if (left_nil)
    sp_raise_cls("NoMethodError", sp_sprintf("undefined method '%s' for nil", op));
  sp_raise_cls("TypeError", "nil can't be coerced into Float");
}

/* `Queue#freeze` raises rather than freezing: a frozen queue could never be
   pushed to again, so Ruby refuses it outright. Names the receiver the way
   CRuby's message does, so a SizedQueue reports as one. */
SP_NORETURN void sp_raise_cannot_freeze(const char *cls, void *p) {
  sp_raise_cls("TypeError",
               sp_sprintf("cannot freeze #<%s:0x%016llx>", cls ? cls : "Object",
                          (unsigned long long)(uintptr_t)p));
}

/* ---- String#encode(dst [, src] [, invalid:, undef:, replace:]) ----
   The runtime models two encodings, UTF-8 and ASCII-8BIT (docs: the encoding
   model), so a transcode is one of four pairs. Same-encoding: the bytes,
   scrubbed only under invalid: :replace, as CRuby does. Binary to UTF-8, and
   UTF-8 to binary: every byte >= 0x80 (every non-ASCII character) has no
   mapping, which is Encoding::UndefinedConversionError naming the byte or the
   code point, or the replacement under undef: :replace. The replacement
   defaults to U+FFFD for a UTF-8 target and "?" otherwise, as CRuby's does.
   A name the model does not know (ISO-8859-1, UTF-16) is left as the bytes,
   which is what every earlier spinel answered for the whole method (#4439). */
static int sp_enc_kind(sp_RbVal e, int dflt) {   /* 1 UTF-8, 2 binary, 0 unknown */
  const char *n = NULL;
  if (e.tag == SP_TAG_STR || e.tag == SP_TAG_ENCODING) n = e.v.s;
  else return dflt;
  if (!n) return dflt;
  if (!strcasecmp(n, "UTF-8") || !strcasecmp(n, "UTF8")) return 1;
  if (!strcasecmp(n, "ASCII-8BIT") || !strcasecmp(n, "BINARY")) return 2;
  return 0;
}
static int sp_enc_kw_replace(sp_RbVal v) {   /* `invalid: :replace` / `undef: :replace` */
  return v.tag == SP_TAG_SYM && sp_sym_name_fn && sp_sym_name_fn((sp_sym)v.v.i) &&
         !strcmp(sp_sym_name_fn((sp_sym)v.v.i), "replace");
}
const char *sp_str_encode(const char *s, sp_RbVal dst, sp_RbVal src,
                          sp_RbVal invalid, sp_RbVal undef, sp_RbVal replace) {
  SP_GC_ROOT_STR(s); SP_GC_ROOT_RBVAL(dst); SP_GC_ROOT_RBVAL(src); SP_GC_ROOT_RBVAL(replace);
  if (!s) sp_nil_recv("encode");
  int from = sp_enc_kind(src, sp_str_is_binary(s) ? 2 : 1);
  int to = sp_enc_kind(dst, 1);
  /* encode answers a new String even where nothing changes, as CRuby's */
  if (!from || !to) return sp_str_dup(s);
  const char *repl = (replace.tag == SP_TAG_STR && replace.v.s) ? replace.v.s : NULL;
  SP_GC_ROOT_STR(repl);
  if (from == to) {
    if (from == 1 && sp_enc_kw_replace(invalid)) return sp_str_scrub_utf8(s, repl);
    return sp_str_dup(s);
  }
  /* binary <-> UTF-8: the ASCII bytes carry over, nothing else does */
  size_t bl = sp_str_byte_len(s);
  int undef_replace = sp_enc_kw_replace(undef);
  const char *dflt = to == 1 ? "\xEF\xBF\xBD" : "?";
  const char *r = repl ? repl : dflt;
  size_t rl = repl ? sp_str_byte_len(repl) : strlen(r);
  size_t cap = bl + 1, o = 0;
  char *out = (char *)malloc(cap);
  if (!out) sp_oom_die();
  for (size_t i = 0; i < bl; ) {
    unsigned char b = (unsigned char)s[i];
    size_t w = 1;
    if (b < 0x80) { if (o + 1 >= cap) { cap *= 2; out = (char *)realloc(out, cap); if (!out) sp_oom_die(); } out[o++] = (char)b; i++; continue; }
    if (from == 1) { w = (size_t)sp_utf8_advance(s + i); if (w == 0 || i + w > bl) w = 1; }
    if (!undef_replace) {
      char what[64];
      if (from == 2) snprintf(what, sizeof what, "\"\\x%02X\"", b);
      else {
        unsigned cp = 0;
        if (w == 1) cp = b;
        else if (w == 2) cp = ((b & 0x1Fu) << 6) | ((unsigned char)s[i+1] & 0x3Fu);
        else if (w == 3) cp = ((b & 0x0Fu) << 12) | (((unsigned char)s[i+1] & 0x3Fu) << 6) | ((unsigned char)s[i+2] & 0x3Fu);
        else cp = ((b & 0x07u) << 18) | (((unsigned char)s[i+1] & 0x3Fu) << 12) | (((unsigned char)s[i+2] & 0x3Fu) << 6) | ((unsigned char)s[i+3] & 0x3Fu);
        snprintf(what, sizeof what, "U+%04X", cp);
      }
      free(out);
      sp_raise_cls("Encoding::UndefinedConversionError",
                   sp_sprintf("%s from %s to %s", what, from == 2 ? "ASCII-8BIT" : "UTF-8",
                              to == 2 ? "ASCII-8BIT" : "UTF-8"));
    }
    while (o + rl + 1 >= cap) { cap *= 2; out = (char *)realloc(out, cap); if (!out) sp_oom_die(); }
    memcpy(out + o, r, rl); o += rl;
    i += w;
  }
  char *res = sp_str_alloc_raw(o + 1);
  memcpy(res, out, o); res[o] = 0; sp_str_set_len(res, o);
  free(out);
  if (to == 2) sp_str_mark_binary(res);
  return res;
}

/* ---- Warning module: category flags (Warning[] / Warning[]=) ----
   CRuby's defaults with no -W flag: only :experimental starts on. Kernel#warn
   consults these through sp_warning_enabled when a literal `category:` is
   given, so `Warning[:deprecated] = true` really un-suppresses those. */
static const char *const sp_warn_cats[] = {
  "deprecated", "experimental", "performance", "strict_unused_block", NULL
};
static sp_bool sp_warn_flags[4] = { 0, 1, 0, 0 };

static int sp_warning_cat_idx(const char *cat) {
  for (int i = 0; sp_warn_cats[i]; i++)
    if (strcmp(cat, sp_warn_cats[i]) == 0) return i;
  return -1;
}
sp_bool sp_warning_aref(const char *cat) {
  int i = sp_warning_cat_idx(cat);
  if (i < 0) sp_raise_cls("ArgumentError", sp_sprintf("unknown category: %s", cat));
  return sp_warn_flags[i];
}
void sp_warning_aset(const char *cat, sp_bool v) {
  int i = sp_warning_cat_idx(cat);
  if (i < 0) sp_raise_cls("ArgumentError", sp_sprintf("unknown category: %s", cat));
  sp_warn_flags[i] = v;
}
/* Kernel#warn's guard: an unknown name answers "print it" (the category
   validity is the caller's ArgumentError, raised before this is consulted). */
sp_bool sp_warning_enabled(const char *cat) {
  int i = sp_warning_cat_idx(cat);
  return i < 0 ? 1 : sp_warn_flags[i];
}
/* Warning.warn: the message as-is (no newline appended), to stderr. */
void sp_warning_warn(const char *msg) {
  if (msg) fputs(msg, stderr);
}

/* FrozenError for a store into a frozen Array: the receiver is staged for
   FrozenError#receiver and its inspect ends the message, as CRuby's
   "can't modify frozen Array: [1, 2]" does (#4924). */
void sp_raise_frozen_array_rv(sp_RbVal v) {
  SP_GC_ROOT_RBVAL(v);
  const char *msg = &("\xff" "can't modify frozen Array")[1];
  if (sp_poly_inspect_fn) {
    const char *ins = sp_poly_inspect_fn(v); SP_GC_ROOT_STR(ins);
    msg = sp_str_concat(&("\xff" "can't modify frozen Array: ")[1], ins);
  }
  SP_GC_ROOT_STR(msg);
  sp_exc_stage_recv(v);
  sp_raise_cls("FrozenError", msg);
}
